from __future__ import annotations

import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


def _legacy_version(install_dir: Path) -> str:
    try:
        text = (install_dir / "stellar" / "config.py").read_text(encoding="utf-8")
    except Exception:
        return ""
    match = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', text)
    return match.group(1) if match else ""


def apply_update_code(payload_root: Path, install_dir: Path) -> Path:
    """1.9.14 及更早版本只有 stellar 包，这里转交给新的 darkitten 实现。"""
    payload_root = Path(payload_root).resolve()
    install_dir = Path(install_dir).resolve()
    legacy_version = _legacy_version(install_dir)
    if str(payload_root) not in sys.path:
        sys.path.insert(0, str(payload_root))
    from darkitten.updater import apply_update_code as apply_new

    backup = apply_new(payload_root, install_dir)
    if legacy_version and backup.name.startswith("backup-unknown-"):
        renamed = backup.with_name(
            backup.name.replace("backup-unknown-", f"backup-{legacy_version}-", 1)
        )
        try:
            backup.rename(renamed)
            backup = renamed
        except Exception:
            pass

    legacy = install_dir / "stellar"
    if legacy.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = install_dir / "updates" / f"legacy-stellar-{stamp}"
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(legacy), str(target))
        except Exception:
            shutil.rmtree(legacy, ignore_errors=True)
    return backup
