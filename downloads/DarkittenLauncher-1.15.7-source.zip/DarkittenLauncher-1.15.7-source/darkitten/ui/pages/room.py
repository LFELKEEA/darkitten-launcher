from __future__ import annotations

import re
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from ...sakura import (
    SAKURA_MC_DOCS,
    SAKURA_PANEL,
    ROOM_TUNNEL_NAME,
    SakuraError,
    SakuraNode,
    SakuraTunnel,
    SakuraUser,
    SakuraTunnelProcess,
    cleanup_room_configs,
    decode_room_input,
    detect_game_lan_ports,
    normalize_room_code,
    preferred_lan_port,
    remove_tunnel_config,
)
from ...mods import list_mods
from ...room_sync import RoomManifest, RoomSyncError, decode_manifest
from ...social import INVITE_PREFIX, SocialError, parse_invite
from ...workers import (
    LanPortWorker,
    RoomInviteWorker,
    SakuraLoginWorker,
    SakuraRoomWorker,
)
from ...worlds import scan_worlds
from .. import icons
from ..dialogs import ConfirmDialog, NoticeDialog
from ..easytier_panel import EasyTierPanel
from ..mod_sync_dialog import ModSyncDialog
from ..widgets import (
    Card,
    ChibiCompanion,
    SegmentedControl,
    badge,
    colors,
    hline,
    icon_button,
    repolish,
)

STATUS_COLORS = {
    "muted": ("muted", ""),
    "busy": ("accent", ""),
    "success": ("green", ""),
    "warning": ("orange", ""),
    "error": ("red", ""),
}


class RoomPage(QWidget):
    def __init__(self, main, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.main = main
        self._token = ""
        self._user: SakuraUser | None = None
        self._nodes: dict[int, SakuraNode] = {}
        self._tunnels: list[SakuraTunnel] = []
        self._login_worker: SakuraLoginWorker | None = None
        self._room_worker: SakuraRoomWorker | None = None
        self._invite_worker: RoomInviteWorker | None = None
        self._invite_manifest: RoomManifest | None = None
        self._invite_room_code = ""
        self._pending_token = ""
        self._tunnel_process: SakuraTunnelProcess | None = None
        self._room_payload: dict | None = None
        self._closing = False
        self._busy = False
        self._auto_login_attempted = False
        self._notice_shown = False
        self._lan_worker: LanPortWorker | None = None
        self._lan_port = 0
        self._auto_create_pending = False
        self._auto_room_flow = False
        self._quick_world_id = ""
        self._lan_warning_shown = False
        self._quick_session_key = ""
        self._lan_timer = QTimer(self)
        self._lan_timer.setInterval(2500)
        self._lan_timer.timeout.connect(self._poll_lan_port)
        self._decoded_address = ""
        self._host_status_kind = "muted"
        self._guest_status_kind = "muted"
        cleanup_room_configs()
        self._build()
        self._restore_token()
        self._sync_versions()
        self.main.versions_changed.connect(self._sync_versions)
        self.main.selection_changed.connect(self._sync_selection)
        self.main.game_state_changed.connect(self._on_game_state)
        self._on_game_state(self.main.game_running)

    # ------------------------------------------------------------------
    # 界面构建

    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        container = QWidget()
        scroll.setWidget(container)
        outer.addWidget(scroll)

        layout = QVBoxLayout(container)
        layout.setContentsMargins(22, 18, 22, 22)
        layout.setSpacing(14)

        header = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(2)
        title = QLabel("猫猫联机窝")
        title.setObjectName("PageTitle")
        sub = QLabel(
            "内置 P2P 直连与樱花穿透：房主开房间，朋友输入房间号就能直接进入。"
        )
        sub.setObjectName("Muted")
        sub.setWordWrap(True)
        titles.addWidget(title)
        titles.addWidget(sub)
        header.addLayout(titles, 1)
        header.addWidget(ChibiCompanion(60, "room"), 0, Qt.AlignTop)

        builtin_badge = badge("双模式联机 · 内置", "blue")
        header.addWidget(builtin_badge, 0, Qt.AlignTop)
        docs_btn = QPushButton("联机文档")
        docs_btn.setObjectName("Ghost")
        docs_btn.setCursor(Qt.PointingHandCursor)
        docs_btn.setIcon(icons.icon("external", colors()["text2"], 15))
        docs_btn.clicked.connect(lambda: self._open_url(SAKURA_MC_DOCS))
        header.addWidget(docs_btn, 0, Qt.AlignTop)
        layout.addLayout(header)

        mode_row = QHBoxLayout()
        mode_row.setSpacing(8)
        self.mode_tabs = SegmentedControl()
        self.mode_tabs.add_item("P2P 直连", "p2p")
        self.mode_tabs.add_item("樱花穿透", "sakura")
        self.mode_tabs.changed.connect(self._switch_mode)
        mode_row.addWidget(self.mode_tabs)
        mode_row.addStretch(1)
        layout.addLayout(mode_row)

        self.mode_stack = QStackedWidget()
        self.easytier_panel = EasyTierPanel(self.main, self)
        self.mode_stack.addWidget(self.easytier_panel)

        sakura_page = QWidget()
        sakura_layout = QVBoxLayout(sakura_page)
        sakura_layout.setContentsMargins(0, 0, 0, 0)
        sakura_layout.setSpacing(14)
        sakura_layout.addWidget(self._build_quick_card())
        columns = QHBoxLayout()
        columns.setSpacing(14)
        self.host_card = self._build_host_card()
        self.guest_card = self._build_guest_card()
        columns.addWidget(self.host_card, 3)
        columns.addWidget(self.guest_card, 2)
        sakura_layout.addLayout(columns, 1)
        sakura_layout.addWidget(self._build_info_card())
        sakura_layout.addStretch(1)
        self.mode_stack.addWidget(sakura_page)
        layout.addWidget(self.mode_stack, 1)
        self._switch_mode("p2p")

    def _build_quick_card(self) -> QWidget:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("一键联机")
        title.setObjectName("H2")
        header.addWidget(title)
        header.addWidget(badge("选择存档 · 自动建房", "purple"))
        header.addStretch(1)
        self.quick_badge = badge("待命", "gray")
        header.addWidget(self.quick_badge)
        layout.addLayout(header)

        sub = QLabel(
            "选一个游戏版本和单人存档，启动器会启动游戏；"
            "Minecraft 1.20 及以上会直接进入该存档。"
            "在游戏里按 Esc → 对局域网开放后，会自动检测端口并创建房间。"
        )
        sub.setObjectName("Tiny")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        row = QHBoxLayout()
        row.setSpacing(8)
        version_label = QLabel("版本")
        version_label.setStyleSheet("font-weight: 600;")
        row.addWidget(version_label)
        self.quick_version_combo = QComboBox()
        self.quick_version_combo.setMinimumWidth(190)
        self.quick_version_combo.currentIndexChanged.connect(
            lambda _: self._sync_quick_saves()
        )
        row.addWidget(self.quick_version_combo, 1)

        save_label = QLabel("存档")
        save_label.setStyleSheet("font-weight: 600;")
        row.addWidget(save_label)
        self.quick_save_combo = QComboBox()
        self.quick_save_combo.setMinimumWidth(250)
        row.addWidget(self.quick_save_combo, 2)
        self.quick_refresh_btn = icon_button("refresh", "刷新存档列表")
        self.quick_refresh_btn.clicked.connect(self._sync_quick_saves)
        row.addWidget(self.quick_refresh_btn)
        layout.addLayout(row)

        action_row = QHBoxLayout()
        action_row.setSpacing(8)
        self.quick_start_btn = QPushButton("启动存档并创建房间")
        self.quick_start_btn.setObjectName("Primary")
        self.quick_start_btn.setCursor(Qt.PointingHandCursor)
        self.quick_start_btn.setIcon(icons.icon("bolt", "#FFFFFF", 16))
        self.quick_start_btn.clicked.connect(self.quick_start)
        action_row.addWidget(self.quick_start_btn)
        self.quick_server_btn = QPushButton("改用专用服务端")
        self.quick_server_btn.setObjectName("Ghost")
        self.quick_server_btn.setCursor(Qt.PointingHandCursor)
        self.quick_server_btn.setToolTip(
            "专用服务端可以关闭正版验证，在“服务器 → 公网联机”里设置。"
        )
        self.quick_server_btn.clicked.connect(self._open_server_page)
        action_row.addWidget(self.quick_server_btn)
        action_row.addStretch(1)
        layout.addLayout(action_row)

        lan_row = QHBoxLayout()
        lan_row.setSpacing(6)
        lan_row.addWidget(badge("需要模组", "orange"))
        lan_label = QLabel("官方局域网默认只允许正版玩家进入")
        lan_label.setObjectName("Tiny")
        lan_label.setWordWrap(True)
        lan_label.setToolTip(
            "Minecraft 官方的“对局域网开放”默认开启正版验证，"
            "离线/非正版玩家会被拒绝。需要房主安装联机模组并关闭正版验证。"
        )
        lan_row.addWidget(lan_label, 1)
        self.quick_mod_btn = QPushButton("安装联机模组")
        self.quick_mod_btn.setObjectName("Soft")
        self.quick_mod_btn.setCursor(Qt.PointingHandCursor)
        self.quick_mod_btn.clicked.connect(lambda: self._install_lan_mod())
        lan_row.addWidget(self.quick_mod_btn)
        self.quick_mod_help_btn = QPushButton("安装步骤")
        self.quick_mod_help_btn.setObjectName("Ghost")
        self.quick_mod_help_btn.setCursor(Qt.PointingHandCursor)
        self.quick_mod_help_btn.clicked.connect(self._show_lan_mod_help)
        lan_row.addWidget(self.quick_mod_help_btn)
        self.quick_mod_page_btn = QPushButton("模组页面")
        self.quick_mod_page_btn.setObjectName("Ghost")
        self.quick_mod_page_btn.setCursor(Qt.PointingHandCursor)
        self.quick_mod_page_btn.clicked.connect(
            lambda: self._open_url("https://modrinth.com/mod/mcwifipnp")
        )
        lan_row.addWidget(self.quick_mod_page_btn)
        layout.addLayout(lan_row)

        self.quick_status = QLabel("选择版本与存档后，一键启动并建房。")
        self.quick_status.setObjectName("Tiny")
        self.quick_status.setWordWrap(True)
        layout.addWidget(self.quick_status)

        hint = QLabel(
            "官方“对局域网开放”默认开启正版验证，只允许正版账户加入。"
            "如果朋友使用离线/非正版客户端，房主需要先安装 LAN World Plug-n-Play"
            "（mcwifipnp）等自定义局域网模组，并在开放局域网时把“正版验证”设为关闭；"
            "也可以点“改用专用服务端”，在服务端的公网联机页关闭正版验证。"
        )
        hint.setObjectName("Tiny")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        return card

    def _build_host_card(self) -> QWidget:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 15, 18, 15)
        layout.setSpacing(9)

        header = QHBoxLayout()
        title = QLabel("开房间")
        title.setObjectName("H2")
        header.addWidget(title)
        header.addStretch(1)
        self.host_badge = badge("未连接", "gray")
        header.addWidget(self.host_badge)
        layout.addLayout(header)

        sub = QLabel(
            "填写樱花穿透访问密钥，创建一条 TCP 隧道指向游戏的局域网端口。"
        )
        sub.setObjectName("Tiny")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        token_row = QHBoxLayout()
        token_row.setSpacing(6)
        self.token_edit = QLineEdit()
        self.token_edit.setPlaceholderText("樱花穿透访问密钥")
        self.token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_edit.setClearButtonEnabled(True)
        self.token_edit.returnPressed.connect(lambda: self.login_sakura())
        token_row.addWidget(self.token_edit, 1)

        self.show_token_btn = QPushButton("显示")
        self.show_token_btn.setObjectName("Ghost")
        self.show_token_btn.setFixedWidth(48)
        self.show_token_btn.setCursor(Qt.PointingHandCursor)
        self.show_token_btn.clicked.connect(self._toggle_token_visibility)
        token_row.addWidget(self.show_token_btn)

        self.connect_btn = QPushButton("验证并连接")
        self.connect_btn.setObjectName("Soft")
        self.connect_btn.setCursor(Qt.PointingHandCursor)
        self.connect_btn.clicked.connect(lambda: self.login_sakura())
        token_row.addWidget(self.connect_btn)
        layout.addLayout(token_row)

        links = QHBoxLayout()
        links.setSpacing(4)
        hint = QLabel("密钥使用 Windows DPAPI 加密保存，只发送给樱花穿透官方接口。")
        hint.setObjectName("Tiny")
        hint.setWordWrap(True)
        links.addWidget(hint, 1)
        panel_btn = QPushButton("获取密钥")
        panel_btn.setObjectName("Ghost")
        panel_btn.setCursor(Qt.PointingHandCursor)
        panel_btn.setIcon(icons.icon("external", colors()["text2"], 13))
        panel_btn.clicked.connect(lambda: self._open_url(SAKURA_PANEL))
        links.addWidget(panel_btn, 0, Qt.AlignTop)
        layout.addLayout(links)

        self.account_line = QLabel("尚未连接樱花穿透账户。")
        self.account_line.setObjectName("Tiny")
        self.account_line.setWordWrap(True)
        layout.addWidget(self.account_line)
        layout.addWidget(hline())

        port_row = QHBoxLayout()
        port_row.setSpacing(8)
        port_label = QLabel("局域网端口")
        port_label.setStyleSheet("font-weight: 600;")
        port_row.addWidget(port_label)
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(25565)
        self.port_spin.setFixedWidth(108)
        self.port_spin.setToolTip("游戏内“对局域网开放”后显示的端口")
        port_row.addWidget(self.port_spin)
        self.detect_btn = QPushButton("检测游戏端口")
        self.detect_btn.setObjectName("Soft")
        self.detect_btn.setCursor(Qt.PointingHandCursor)
        self.detect_btn.clicked.connect(self.detect_port)
        port_row.addWidget(self.detect_btn)
        port_row.addStretch(1)
        layout.addLayout(port_row)

        port_hint = QLabel(
            "进入单人游戏后按 Esc → 对局域网开放。只有房主需要保持游戏和房间开启。"
        )
        port_hint.setObjectName("Tiny")
        port_hint.setWordWrap(True)
        layout.addWidget(port_hint)

        node_row = QHBoxLayout()
        node_row.setSpacing(8)
        node_label = QLabel("穿透节点")
        node_label.setStyleSheet("font-weight: 600;")
        node_row.addWidget(node_label)
        self.node_combo = QComboBox()
        self.node_combo.setMinimumWidth(240)
        self.node_combo.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        node_row.addWidget(self.node_combo, 1)
        self.node_refresh = icon_button("refresh", "刷新节点列表")
        self.node_refresh.clicked.connect(lambda: self.login_sakura(silent=True))
        node_row.addWidget(self.node_refresh)
        layout.addLayout(node_row)

        node_hint = QLabel(
            "熟人联机可选普通节点；如果要公开宣传服务器，必须选择带“多线”标记的专用节点。"
        )
        node_hint.setObjectName("Tiny")
        node_hint.setWordWrap(True)
        layout.addWidget(node_hint)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        self.create_btn = QPushButton("创建房间")
        self.create_btn.setObjectName("Primary")
        self.create_btn.setCursor(Qt.PointingHandCursor)
        self.create_btn.setIcon(icons.icon("bolt", "#FFFFFF", 16))
        self.create_btn.clicked.connect(self.create_room)
        buttons.addWidget(self.create_btn)

        self.close_btn = QPushButton("关闭房间")
        self.close_btn.setObjectName("Danger")
        self.close_btn.setCursor(Qt.PointingHandCursor)
        self.close_btn.clicked.connect(self.close_room)
        self.close_btn.setVisible(False)
        buttons.addWidget(self.close_btn)
        buttons.addStretch(1)
        layout.addLayout(buttons)

        self.host_status = QLabel("填写访问密钥后即可创建房间。")
        self.host_status.setObjectName("Tiny")
        self.host_status.setWordWrap(True)
        layout.addWidget(self.host_status)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6)
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        self.result_box = self._build_result_box()
        layout.addWidget(self.result_box)
        layout.addWidget(self._build_log_box())
        return card

    def _build_result_box(self) -> QWidget:
        box = QFrame()
        box.setObjectName("SoftCard")
        box.setAttribute(Qt.WA_StyledBackground, True)
        box.setVisible(False)
        layout = QVBoxLayout(box)
        layout.setContentsMargins(14, 11, 14, 11)
        layout.setSpacing(4)

        caption = QLabel("房间号")
        caption.setObjectName("Tiny")
        layout.addWidget(caption)

        code_row = QHBoxLayout()
        code_row.setSpacing(8)
        self.room_code_label = QLabel("—")
        self.room_code_label.setStyleSheet(
            "font-size: 24px; font-weight: 800; letter-spacing: 2px;"
        )
        self.room_code_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        code_row.addWidget(self.room_code_label, 1)
        self.copy_code_btn = QPushButton("复制房间号")
        self.copy_code_btn.setObjectName("Primary")
        self.copy_code_btn.setCursor(Qt.PointingHandCursor)
        self.copy_code_btn.setIcon(icons.icon("copy", "#FFFFFF", 14))
        self.copy_code_btn.clicked.connect(self._copy_room_code)
        code_row.addWidget(self.copy_code_btn)

        self.copy_invite_btn = QPushButton("好友邀请卡")
        self.copy_invite_btn.setObjectName("Soft")
        self.copy_invite_btn.setCursor(Qt.PointingHandCursor)
        self.copy_invite_btn.setIcon(icons.icon("users", colors()["accent"], 14))
        self.copy_invite_btn.setToolTip(
            "复制带房间号的邀请卡，好友导入后可以直接进入房间"
        )
        self.copy_invite_btn.clicked.connect(self._copy_invite_card)
        code_row.addWidget(self.copy_invite_btn)
        layout.addLayout(code_row)

        self.room_address_label = QLabel("")
        self.room_address_label.setObjectName("Tiny")
        self.room_address_label.setWordWrap(True)
        self.room_address_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.room_address_label)

        addr_row = QHBoxLayout()
        addr_row.setSpacing(6)
        self.room_detail_label = QLabel("")
        self.room_detail_label.setObjectName("Tiny")
        self.room_detail_label.setWordWrap(True)
        addr_row.addWidget(self.room_detail_label, 1)
        self.copy_address_btn = QPushButton("复制地址")
        self.copy_address_btn.setObjectName("Ghost")
        self.copy_address_btn.setCursor(Qt.PointingHandCursor)
        self.copy_address_btn.setIcon(icons.icon("copy", colors()["text2"], 13))
        self.copy_address_btn.clicked.connect(self._copy_host_address)
        addr_row.addWidget(self.copy_address_btn)
        layout.addLayout(addr_row)
        return box

    def _build_log_box(self) -> QWidget:
        self.log_box = QPlainTextEdit()
        self.log_box.setObjectName("SoftLog")
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumBlockCount(400)
        self.log_box.setFixedHeight(92)
        self.log_box.setPlaceholderText("内置 frpc 的连接日志会显示在这里")
        self.log_box.setVisible(False)
        return self.log_box

    def _build_guest_card(self) -> QWidget:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 15, 18, 15)
        layout.setSpacing(9)

        header = QHBoxLayout()
        title = QLabel("加入房间")
        title.setObjectName("H2")
        header.addWidget(title)
        header.addStretch(1)
        no_account = badge("无需樱花账号", "green")
        header.addWidget(no_account)
        layout.addLayout(header)

        sub = QLabel("粘贴房主发来的房间号，选择相同版本后直接启动游戏。")
        sub.setObjectName("Tiny")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        code_caption = QLabel("房间号")
        code_caption.setStyleSheet("font-weight: 600;")
        layout.addWidget(code_caption)

        code_row = QHBoxLayout()
        code_row.setSpacing(6)
        self.code_edit = QLineEdit()
        self.code_edit.setPlaceholderText("XXXXX-XXXX-XXXXX")
        self.code_edit.setClearButtonEnabled(True)
        # 好友邀请卡可能携带上百 KB 的 Mod 清单，先完整接收再解析。
        self.code_edit.setMaxLength(200_000)
        self.code_edit.textChanged.connect(self._update_code_preview)
        self.code_edit.editingFinished.connect(self._format_code_field)
        self.code_edit.returnPressed.connect(self.join_room)
        code_row.addWidget(self.code_edit, 1)
        paste_btn = icon_button("copy", "从剪贴板粘贴房间号")
        paste_btn.clicked.connect(self._paste_code)
        code_row.addWidget(paste_btn)
        layout.addLayout(code_row)

        self.code_hint = QLabel("也可以直接粘贴 host:port 形式的服务器地址。")
        self.code_hint.setObjectName("Tiny")
        self.code_hint.setWordWrap(True)
        layout.addWidget(self.code_hint)
        layout.addWidget(hline())

        version_caption = QLabel("游戏版本")
        version_caption.setStyleSheet("font-weight: 600;")
        layout.addWidget(version_caption)
        self.version_combo = QComboBox()
        self.version_combo.setMinimumWidth(220)
        layout.addWidget(self.version_combo)

        version_hint = QLabel("必须和房主使用相同版本；模组、整合包也需要一致。")
        version_hint.setObjectName("Tiny")
        version_hint.setWordWrap(True)
        layout.addWidget(version_hint)

        self.sync_mods_btn = QPushButton("同步房主 Mod")
        self.sync_mods_btn.setObjectName("Soft")
        self.sync_mods_btn.setCursor(Qt.PointingHandCursor)
        self.sync_mods_btn.setIcon(icons.icon("users", colors()["accent"], 15))
        self.sync_mods_btn.setToolTip(
            "读取邀请卡里的 Mod 清单，补齐当前版本缺少的 Mod"
        )
        self.sync_mods_btn.clicked.connect(self._open_mod_sync)
        layout.addWidget(self.sync_mods_btn)

        self.join_btn = QPushButton("启动游戏并进入")
        self.join_btn.setObjectName("Primary")
        self.join_btn.setCursor(Qt.PointingHandCursor)
        self.join_btn.setIcon(icons.icon("play", "#FFFFFF", 16))
        self.join_btn.clicked.connect(self.join_room)
        layout.addWidget(self.join_btn)

        self.copy_decode_btn = QPushButton("仅复制服务器地址")
        self.copy_decode_btn.setObjectName("Ghost")
        self.copy_decode_btn.setCursor(Qt.PointingHandCursor)
        self.copy_decode_btn.setIcon(icons.icon("copy", colors()["text2"], 14))
        self.copy_decode_btn.clicked.connect(self._copy_guest_address)
        layout.addWidget(self.copy_decode_btn)

        self.guest_status = QLabel("房主创建房间后，把房间号发给你即可。")
        self.guest_status.setObjectName("Tiny")
        self.guest_status.setWordWrap(True)
        layout.addWidget(self.guest_status)

        layout.addStretch(1)
        note = QLabel(
            "正版/离线账户都可以加入。若服务器开启了正版验证，请先在设置里登录 Microsoft 账户。"
        )
        note.setObjectName("Tiny")
        note.setWordWrap(True)
        layout.addWidget(note)
        return card

    def _build_info_card(self) -> QWidget:
        card = Card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("联机须知")
        title.setObjectName("H2")
        header.addWidget(title)
        header.addWidget(badge("仅限熟人联机", "orange"))
        header.addStretch(1)
        tunnel_btn = QPushButton("隧道规则")
        tunnel_btn.setObjectName("Ghost")
        tunnel_btn.setCursor(Qt.PointingHandCursor)
        tunnel_btn.clicked.connect(lambda: self._open_url(SAKURA_MC_DOCS))
        header.addWidget(tunnel_btn)
        layout.addLayout(header)

        self._step_numbers: list[QLabel] = []
        steps = QHBoxLayout()
        steps.setSpacing(10)
        step_data = [
            ("1", "房主开放世界", "进入单人游戏，按 Esc → 对局域网开放，记下端口。"),
            ("2", "创建房间", "连接樱花穿透，检测端口并创建，把房间号发给朋友。"),
            ("3", "朋友直接进入", "粘贴房间号，选择相同版本，启动后自动连接。"),
        ]
        for number, step_title, step_desc in step_data:
            box = QFrame()
            box.setObjectName("SoftCard")
            box.setAttribute(Qt.WA_StyledBackground, True)
            box_layout = QVBoxLayout(box)
            box_layout.setContentsMargins(12, 10, 12, 10)
            box_layout.setSpacing(3)
            top = QHBoxLayout()
            top.setSpacing(7)
            number_label = QLabel(number)
            number_label.setAlignment(Qt.AlignCenter)
            number_label.setFixedSize(20, 20)
            number_label.setStyleSheet(
                f"background: {colors()['accent_soft']}; color: {colors()['accent']};"
                "border-radius: 10px; font-size: 10px; font-weight: 800;"
            )
            self._step_numbers.append(number_label)
            top.addWidget(number_label)
            step_name = QLabel(step_title)
            step_name.setStyleSheet("font-weight: 700; font-size: 12px;")
            top.addWidget(step_name)
            top.addStretch(1)
            box_layout.addLayout(top)
            desc = QLabel(step_desc)
            desc.setObjectName("Tiny")
            desc.setWordWrap(True)
            box_layout.addWidget(desc)
            steps.addWidget(box, 1)
        layout.addLayout(steps)

        warning_box = QFrame()
        warning_box.setObjectName("SoftCard")
        warning_box.setAttribute(Qt.WA_StyledBackground, True)
        warning_layout = QHBoxLayout(warning_box)
        warning_layout.setContentsMargins(11, 8, 11, 8)
        warning_layout.setSpacing(8)
        warn_icon = QLabel()
        warn_icon.setPixmap(icons.pixmap("warning", colors()["orange"], 17))
        warning_layout.addWidget(warn_icon, 0, Qt.AlignTop)
        warning = QLabel(
            "房间号只适合朋友之间联机。若在论坛、群聊或视频平台公开宣传，"
            "必须使用带“多线”标记的公开游戏节点，否则可能被樱花穿透封号；"
            "免费账户还有流量、隧道数和实名认证限制。"
        )
        warning.setObjectName("Tiny")
        warning.setWordWrap(True)
        warning_layout.addWidget(warning, 1)
        layout.addWidget(warning_box)
        return card

    # ------------------------------------------------------------------
    # 状态与主题

    def _open_server_page(self) -> None:
        switch = getattr(self.main, "switch_page", None)
        if callable(switch):
            switch("server")
            return
        self.toast("请先在左侧打开“服务器”页", "info")

    def _switch_mode(self, mode: str) -> None:
        if not hasattr(self, "mode_stack"):
            return
        index = 0 if str(mode) == "p2p" else 1
        self.mode_stack.setCurrentIndex(index)
        if index == 0 and hasattr(self, "easytier_panel"):
            self.easytier_panel.on_show()

    def _set_status(self, label: QLabel, text: str, kind: str = "muted") -> None:
        c = colors()
        key = STATUS_COLORS.get(kind, STATUS_COLORS["muted"])[0]
        label.setStyleSheet(
            f"color: {c[key]}; font-size: 11px; background: transparent;"
        )
        label.setText(text)
        if label is self.host_status:
            self._host_status_kind = kind
        elif label is self.guest_status:
            self._guest_status_kind = kind

    def _set_badge(self, label: QLabel, text: str, kind: str) -> None:
        label.setText(text)
        label.setProperty("badge", kind)
        repolish(label)

    def refresh_theme(self) -> None:
        self._set_status(
            self.host_status, self.host_status.text(), self._host_status_kind
        )
        self._set_status(
            self.guest_status, self.guest_status.text(), self._guest_status_kind
        )
        if hasattr(self, "easytier_panel"):
            self.easytier_panel.refresh_theme()
        self.create_btn.setIcon(icons.icon("bolt", "#FFFFFF", 16))
        if hasattr(self, "quick_start_btn"):
            self.quick_start_btn.setIcon(icons.icon("bolt", "#FFFFFF", 16))
        self.join_btn.setIcon(icons.icon("play", "#FFFFFF", 16))
        self.copy_code_btn.setIcon(icons.icon("copy", "#FFFFFF", 14))
        for button in (self.copy_address_btn, self.copy_decode_btn):
            button.setIcon(icons.icon("copy", colors()["text2"], 13))
        for label in getattr(self, "_step_numbers", []):
            label.setStyleSheet(
                f"background: {colors()['accent_soft']}; color: {colors()['accent']};"
                "border-radius: 10px; font-size: 10px; font-weight: 800;"
            )
        for label in self.findChildren(QLabel):
            if label.property("badge"):
                repolish(label)

    def _restore_token(self) -> None:
        token = self.main.config.sakura_access_token
        if not token:
            return
        self._token = token
        self.token_edit.setText(token)
        self.token_edit.setCursorPosition(len(token))
        self.token_edit.setPlaceholderText("已保存访问密钥（已加密）")
        self._set_status(
            self.host_status, "已保存访问密钥，切换到本页时自动连接。", "muted"
        )
        self.connect_btn.setText("重新验证")

    def _toggle_token_visibility(self) -> None:
        if self.token_edit.echoMode() == QLineEdit.EchoMode.Password:
            self.token_edit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.show_token_btn.setText("隐藏")
        else:
            self.token_edit.setEchoMode(QLineEdit.EchoMode.Password)
            self.show_token_btn.setText("显示")

    def on_show(self) -> None:
        self._sync_versions()
        if hasattr(self, "easytier_panel"):
            self.easytier_panel.on_show()
        if (
            not self._auto_login_attempted
            and self._token
            and self._user is None
            and not self._busy
        ):
            self._auto_login_attempted = True
            QTimer.singleShot(120, lambda: self.login_sakura(silent=True))

    # ------------------------------------------------------------------
    # 樱花账户

    def login_sakura(self, silent: bool = False) -> None:
        if self._busy:
            return
        if self._tunnel_process is not None:
            self.toast("请先关闭当前房间，再更换访问密钥。", "info")
            return
        token = self.token_edit.text().strip() or self._token
        if not token:
            self._set_status(
                self.host_status, "请先填写樱花穿透访问密钥。", "error"
            )
            return
        self._pending_token = token
        self._busy = True
        self.connect_btn.setEnabled(False)
        self.connect_btn.setText("正在验证…")
        self.create_btn.setEnabled(False)
        self.node_refresh.setEnabled(False)
        self._set_status(self.host_status, "正在验证访问密钥并读取节点…", "busy")
        worker = SakuraLoginWorker(token, self)
        self._login_worker = worker
        worker.ready.connect(
            lambda payload, error, w=worker, s=silent: self._login_ready(
                w, payload, error, s
            )
        )
        worker.start()

    def _login_ready(
        self,
        worker: SakuraLoginWorker,
        payload,
        error: str,
        silent: bool = False,
    ) -> None:
        if self._login_worker is not worker:
            return
        self._login_worker = None
        self._busy = False
        self.connect_btn.setEnabled(True)
        self.node_refresh.setEnabled(True)
        if error or not isinstance(payload, dict):
            self.connect_btn.setText("验证并连接")
            self._set_status(
                self.host_status, error or "无法读取樱花穿透账户。", "error"
            )
            self.toast(error or "樱花穿透连接失败", "error")
            if self._auto_create_pending:
                self._auto_create_pending = False
                self._auto_room_flow = False
                self._set_quick_status(
                    f"樱花穿透连接失败：{error or '请检查访问密钥'}", "error"
                )
                self._set_badge(self.quick_badge, "待命", "gray")
            self._sync_controls()
            return

        user: SakuraUser = payload["user"]
        self._user = user
        self._nodes = payload["nodes"]
        self._tunnels = payload["tunnels"]
        self._token = self._pending_token
        old_token = self.main.config.sakura_access_token
        if old_token and old_token != self._token:
            self.main.config.sakura_tunnel_id = 0
        self.main.config.set_sakura_token(self._token)
        self.main.config.save()
        self.token_edit.setText(self._token)
        self.token_edit.setCursorPosition(len(self._token))
        self.token_edit.setPlaceholderText("已保存访问密钥（已加密）")
        self.connect_btn.setText("重新验证")
        self._set_badge(self.host_badge, "已连接", "green")
        self._populate_nodes()

        details = [
            f"已连接 · {user.name or '樱花账户'}",
            user.realname_text,
            user.traffic_text,
        ]
        if user.speed:
            details.append(f"限速 {user.speed}")
        if user.tunnel_limit:
            details.append(f"隧道 {len(self._tunnels)}/{user.tunnel_limit}")
        self.account_line.setText(" · ".join(details))
        if not user.realname:
            self._set_status(
                self.host_status,
                "账户尚未实名认证，创建隧道可能被拒绝，请到樱花穿透面板完成认证。",
                "warning",
            )
        else:
            self._set_status(
                self.host_status, "账户已连接，可以创建房间。", "success"
            )
        self._sync_controls()
        if self._auto_create_pending:
            self._auto_create_pending = False
            QTimer.singleShot(0, lambda: self.create_room(auto=True))
            return
        if not silent:
            self.toast("樱花穿透账户已连接", "success")

    def _populate_nodes(self) -> None:
        current_id = self._selected_node_id()
        if not current_id:
            current_id = self.main.config.sakura_node_id
        preferred_tunnel = self._existing_room_tunnel()
        if preferred_tunnel and preferred_tunnel.node in self._nodes:
            current_id = preferred_tunnel.node

        self.node_combo.blockSignals(True)
        self.node_combo.clear()
        self.node_combo.addItem("自动选择节点", 0)
        nodes = [
            node
            for node in self._nodes.values()
            if node.selectable and node.host
        ]
        nodes.sort(key=lambda node: (node.public_game, node.vip, not node.mainland, node.name))
        for node in nodes[:200]:
            self.node_combo.addItem(node.label, node.id)
            index = self.node_combo.count() - 1
            tip = node.description or ""
            if node.host:
                tip = (tip + "\n" if tip else "") + f"节点地址：{node.host}"
            self.node_combo.setItemData(index, tip, Qt.ToolTipRole)
        if current_id:
            index = self.node_combo.findData(current_id)
            if index >= 0:
                self.node_combo.setCurrentIndex(index)
        self.node_combo.blockSignals(False)
        if not nodes:
            self._set_status(
                self.host_status,
                "没有可用节点，请稍后刷新，或到樱花穿透面板检查节点状态。",
                "error",
            )

    def _selected_node_id(self) -> int:
        data = self.node_combo.currentData()
        try:
            return int(data or 0)
        except (TypeError, ValueError):
            return 0

    def _existing_room_tunnel(self) -> SakuraTunnel | None:
        preferred = self.main.config.sakura_tunnel_id
        if preferred:
            for tunnel in self._tunnels:
                if tunnel.id == preferred and tunnel.type == "tcp":
                    return tunnel
        candidates = [
            tunnel
            for tunnel in self._tunnels
            if tunnel.name.startswith(ROOM_TUNNEL_NAME) and tunnel.type == "tcp"
        ]
        return max(candidates, key=lambda item: item.id) if candidates else None

    # ------------------------------------------------------------------
    # 一键联机

    def _sync_quick_versions(self) -> None:
        if not hasattr(self, "quick_version_combo"):
            return
        versions = list(self.main.game_version_summaries())
        current = self.quick_version_combo.currentData() or self.main.selected_version
        self.quick_version_combo.blockSignals(True)
        self.quick_version_combo.clear()
        for summary in versions:
            kind = summary.loader or summary.type_name or ""
            display = self.main.config.version_name(summary.id) or summary.id
            label = f"{display} · {kind}" if kind else display
            self.quick_version_combo.addItem(label, summary.id)
            if display != summary.id:
                index = self.quick_version_combo.count() - 1
                self.quick_version_combo.setItemData(
                    index, f"内部版本：{summary.id}", Qt.ToolTipRole
                )
        if versions:
            index = self.quick_version_combo.findData(current)
            if index < 0:
                index = 0
            self.quick_version_combo.setCurrentIndex(index)
        else:
            self.quick_version_combo.addItem("未安装游戏版本", "")
        self.quick_version_combo.blockSignals(False)
        self._sync_quick_saves()

    def _sync_quick_saves(self) -> None:
        if not hasattr(self, "quick_save_combo"):
            return
        version_id = str(self.quick_version_combo.currentData() or "")
        current = self._quick_world_id or self.quick_save_combo.currentData()
        worlds = []
        if version_id:
            try:
                worlds = scan_worlds(
                    Path(self.main.config.version_game_path(version_id))
                )
            except OSError:
                worlds = []
        self.quick_save_combo.blockSignals(True)
        self.quick_save_combo.clear()
        if not worlds:
            self.quick_save_combo.addItem(
                "这个版本还没有存档" if version_id else "请先安装游戏版本", ""
            )
            self._quick_world_id = ""
        else:
            for world in worlds:
                label = (
                    f"{world.name} · {world.mode_text} · "
                    f"{world.last_played_text}"
                )
                self.quick_save_combo.addItem(label, world.folder.name)
            index = self.quick_save_combo.findData(current)
            self.quick_save_combo.setCurrentIndex(index if index >= 0 else 0)
            self._quick_world_id = str(
                self.quick_save_combo.currentData() or ""
            )
        self.quick_save_combo.blockSignals(False)
        self._sync_controls()

    LAN_AUTH_MOD_KEYS = (
        "mcwifipnp",
        "customlan",
        "custom-lan",
        "offlinelan",
        "easylan",
        "lanserverproperties",
        "lan-server-properties",
    )

    def _lan_auth_mod_installed(self, version_id: str) -> bool:
        if not version_id:
            return False
        try:
            mods = list_mods(Path(self.main.config.mods_path(version_id)))
        except Exception:
            return False
        for mod in mods:
            name = mod.filename.lower().replace("_", "-")
            if any(key in name for key in self.LAN_AUTH_MOD_KEYS):
                return True
        return False

    def ensure_lan_auth_mod(self, version_id: str) -> bool:
        """提醒房主安装能关闭正版验证的联机模组。

        返回 False 表示用户选择先去安装，调用方应停止本次启动。
        """
        if self._lan_warning_shown or self._lan_auth_mod_installed(version_id):
            return True
        dialog = ConfirmDialog(
            self,
            "官方局域网默认只允许正版玩家",
            "Minecraft 官方的“对局域网开放”默认开启正版验证，"
            "离线/非正版朋友会被拒绝进入。",
            primary_text="安装联机模组",
            secondary_text="仍然继续",
            icon_name="users",
            icon_color=colors()["orange"],
            details=(
                "推荐安装 LAN World Plug-n-Play（mcwifipnp）："
                "开放局域网时把“正版验证”设为关闭，就能让离线玩家加入。\n"
                "也可以点“改用专用服务端”，在服务端的公网联机页关闭正版验证。"
            ),
        )
        self._lan_warning_shown = True
        if dialog.exec():
            self._install_lan_mod(version_id)
            return False
        return True

    def _install_lan_mod(self, version_id: str | None = None) -> None:
        from ..mod_dialog import ModBrowserDialog

        version_id = str(version_id or self.quick_version_combo.currentData() or "")
        if version_id and version_id != self.main.selected_version:
            self.main.home_page.select_version(version_id)
        hit = {
            "project_id": "mcwifipnp",
            "slug": "mcwifipnp",
            "title": "LAN World Plug-n-Play (mcwifipnp)",
            "source": "modrinth",
            "source_label": "Modrinth",
            "content_type": "mod",
            "description": (
                "在“对局域网开放”界面里开关正版验证、端口、"
                "最大玩家数和 PVP，支持 Fabric / Forge / NeoForge。"
            ),
            "project_url": "https://modrinth.com/mod/mcwifipnp",
            "categories": [],
            "downloads": 0,
            "icon_url": "",
        }
        ModBrowserDialog(self.main, hit).exec()
        refresh = getattr(self.main, "_refresh_download_chip", None)
        if callable(refresh):
            refresh()

    def _show_lan_mod_help(self) -> None:
        NoticeDialog(
            self,
            "非正版玩家怎么进局域网",
            "Minecraft 官方的“对局域网开放”默认开启正版验证，"
            "只允许正版账户加入。\n\n"
            "1. 点“安装联机模组”，在打开的页面里选择当前游戏版本，"
            "下载并安装 LAN World Plug-n-Play（mcwifipnp）。\n"
            "2. 启动游戏进入存档，按 Esc → 对局域网开放。\n"
            "3. 在开放局域网的界面里，把“正版验证（Online Mode）”"
            "设为“禁用”，再点“开放局域网”。\n"
            "4. 回到启动器，点“检测游戏端口”，或等待一键联机自动建房。\n\n"
            "也可以安装 OfflineLAN（仅 Fabric）或 Custom LAN（Fabric/Quilt，"
            "部分版本）。如果不想装模组，可以点“改用专用服务端”，"
            "在服务端的“公网联机”页关闭正版验证。\n\n"
            "注意：关闭正版验证后，任何知道地址的人都能尝试加入，"
            "请只把房间号发给认识的朋友。",
            icon_name="users",
        ).exec()

    def quick_start(self) -> None:
        if self.main.launch_active:
            self.toast("游戏正在启动，请稍候", "info")
            return
        version_id = str(self.quick_version_combo.currentData() or "")
        world_id = str(self.quick_save_combo.currentData() or "")
        if not version_id or not world_id:
            self._set_quick_status("请先选择游戏版本和存档。", "error")
            return
        if self._tunnel_process is not None or self._room_payload is not None:
            self.toast("房间已经开启，请先关闭当前房间。", "info")
            return

        token = self.token_edit.text().strip() or self._token
        if not token:
            self._set_quick_status(
                "一键联机需要樱花穿透访问密钥，请先在下方“开房间”里填写。",
                "error",
            )
            return
        if not self.ensure_lan_auth_mod(version_id):
            return

        existing = self.main.find_game_session(version_id)
        if existing is not None:
            # 这个版本已经在运行，直接复用它等待对局域网开放，不再开第二个进程。
            self._quick_session_key = existing.key
            self._quick_world_id = world_id
            self._auto_room_flow = True
            self._lan_port = 0
            self._set_quick_status(
                "这个版本已经在运行。请在游戏里按 Esc → 对局域网开放，"
                "启动器会自动检测端口并建房。",
                "busy",
            )
            self._set_badge(self.quick_badge, "等待端口", "blue")
            self._lan_timer.start()
            self._sync_controls()
            return

        self._quick_world_id = world_id
        self._auto_room_flow = True
        self._lan_port = 0
        self._set_quick_status(
            f"正在启动 {version_id}。进入存档后按 Esc → 对局域网开放，"
            "启动器会自动检测端口并建房。",
            "busy",
        )
        self._set_badge(self.quick_badge, "启动中", "blue")
        if version_id != self.main.selected_version:
            self.main.home_page.select_version(version_id)
        self._quick_session_key = self.main.launch_selected(quick_world=world_id)
        if not self._quick_session_key:
            self._auto_room_flow = False
            self._set_quick_status("启动没有完成，请查看启动器提示。", "error")
            self._set_badge(self.quick_badge, "待命", "gray")
            return
        self._lan_timer.start()
        self._sync_controls()

    def _poll_lan_port(self) -> None:
        if self._closing:
            self._lan_timer.stop()
            return
        if self._room_payload is not None or self._tunnel_process is not None:
            self._lan_timer.stop()
            return
        if self._quick_session_key:
            process = self.main.session_process(self._quick_session_key)
            if process is None:
                if not self.main.launch_active:
                    # 自己启动的那个游戏已经退出，停止自动建房。
                    self._quick_session_key = ""
                    self._lan_timer.stop()
                    if self._auto_room_flow:
                        self._auto_room_flow = False
                        self._set_badge(self.quick_badge, "待命", "gray")
                        self._set_quick_status(
                            "启动的游戏已经退出，一键联机已停止。", "muted"
                        )
                return
        else:
            if not self.main.game_running:
                return
            process = self.main.game_process
        if self._lan_worker is not None:
            return
        pid = int(getattr(process, "pid", 0) or 0) if process else 0
        if not pid:
            return
        worker = LanPortWorker(pid, self)
        self._lan_worker = worker
        worker.ready.connect(
            lambda ports, w=worker: self._lan_ready(w, ports)
        )
        worker.start()

    def _lan_ready(self, worker: LanPortWorker, ports) -> None:
        if worker is not self._lan_worker:
            return
        self._lan_worker = None
        if self._closing:
            return
        values = [int(port) for port in (ports or []) if int(port or 0) > 0]
        if not values:
            if self._auto_room_flow:
                self._set_quick_status(
                    "游戏已启动。进入存档后按 Esc → 对局域网开放，"
                    "启动器会自动检测端口并建房。",
                    "busy",
                )
            return
        port = preferred_lan_port(values)
        if port == self._lan_port:
            return
        self._lan_port = port
        self.port_spin.setValue(port)
        self._lan_timer.stop()
        self._set_quick_status(
            f"已检测到局域网端口 {port}，正在创建房间…", "busy"
        )
        self._set_badge(self.quick_badge, "建房中", "blue")
        self._set_status(
            self.host_status, f"已检测到游戏端口 {port}，正在创建房间…", "busy"
        )
        self._ensure_account_then_create()

    def _ensure_account_then_create(self) -> None:
        if self._closing:
            return
        if self._tunnel_process is not None or self._room_payload is not None:
            return
        if self._busy or self._room_worker is not None:
            QTimer.singleShot(1500, self._ensure_account_then_create)
            return
        if self._user is None:
            token = self.token_edit.text().strip() or self._token
            if not token:
                self._auto_room_flow = False
                self._set_quick_status(
                    "检测到端口，但还没有樱花穿透访问密钥。"
                    "请在下方填写密钥后再点一次“创建房间”。",
                    "error",
                )
                self._set_badge(self.quick_badge, "待命", "gray")
                return
            self._auto_create_pending = True
            self.login_sakura(silent=True)
            return
        self._notice_shown = True
        self.create_room(auto=True)

    def _set_quick_status(self, text: str, kind: str = "muted") -> None:
        if not hasattr(self, "quick_status"):
            return
        c = colors()
        key = STATUS_COLORS.get(kind, STATUS_COLORS["muted"])[0]
        self.quick_status.setStyleSheet(
            f"color: {c[key]}; font-size: 11px; background: transparent;"
        )
        self.quick_status.setText(text)

    # ------------------------------------------------------------------
    # 主机流程

    def detect_port(self) -> None:
        process = None
        if self._quick_session_key:
            process = self.main.session_process(self._quick_session_key)
        process = process or self.main.game_process
        pid = process.pid if process and self.main.game_running else 0
        if not pid:
            self._set_status(
                self.host_status,
                "游戏还没有运行。请先启动游戏，并在单人游戏里“对局域网开放”。",
                "warning",
            )
            return
        ports = detect_game_lan_ports(pid)
        if not ports:
            self._set_status(
                self.host_status,
                "没有检测到游戏监听端口。请先在游戏里对局域网开放，再点一次检测。",
                "warning",
            )
            return
        port = preferred_lan_port(ports)
        self.port_spin.setValue(port)
        others = [str(item) for item in ports if item != port]
        text = f"已检测到游戏端口 {port}，可以创建房间。"
        if others:
            text += f"（其他监听端口：{', '.join(others[:4])}）"
        self._set_status(self.host_status, text, "success")

    def create_room(self, auto: bool = False) -> None:
        if self._busy:
            return
        if self._user is None:
            self._set_status(
                self.host_status, "请先验证并连接樱花穿透访问密钥。", "error"
            )
            self._auto_room_flow = False
            self._set_quick_status("请先验证樱花穿透访问密钥。", "error")
            return
        if self.token_edit.text().strip() != self._token:
            self._set_status(
                self.host_status,
                "访问密钥已修改，请先点击“验证并连接”再创建房间。",
                "warning",
            )
            self._auto_room_flow = False
            self._set_quick_status(
                "访问密钥已修改，请先点击“验证并连接”。", "warning"
            )
            return
        if self._tunnel_process is not None or self._room_payload is not None:
            self.toast("房间已经开启，请先关闭当前房间。", "info")
            return
        port = int(self.port_spin.value())
        node_id = self._selected_node_id()
        if not self._notice_shown and not auto:
            dialog = ConfirmDialog(
                self,
                "创建联机房间",
                "房间号适合朋友之间私下联机。创建后会占用一条樱花穿透隧道。",
                primary_text="仅熟人联机，继续",
                secondary_text="取消",
                icon_name="users",
                icon_color=colors()["green"],
                details=(
                    "如果你的服务器会发布到论坛、群聊、服务器列表或视频平台，"
                    "必须使用带“多线”标记的公开游戏节点，否则可能违反樱花穿透规则并被封号。"
                    "房主需要保持游戏、启动器和房间全程开启。"
                ),
            )
            if not dialog.exec():
                return
            self._notice_shown = True

        self._busy = True
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.log_box.clear()
        self.log_box.setVisible(True)
        self._set_status(
            self.host_status, "正在准备隧道与内置 frpc…", "busy"
        )
        self._set_badge(self.host_badge, "准备中", "blue")
        self._sync_controls()

        worker = SakuraRoomWorker(
            self._token,
            port,
            node_id=node_id,
            preferred_tunnel_id=self.main.config.sakura_tunnel_id,
            frpc_path=self.main.config.sakura_frpc_path,
            parent=self,
            avoid_tunnel_id=self.main.config.sakura_server_tunnel_id,
        )
        self._room_worker = worker
        worker.progress.connect(
            lambda value, message, w=worker: self._room_progress(w, value, message)
        )
        worker.log_line.connect(
            lambda line, w=worker: self._room_log(w, line)
        )
        worker.ready.connect(
            lambda payload, error, w=worker: self._room_ready(w, payload, error)
        )
        worker.failed.connect(
            lambda error, w=worker: self._room_failed(w, error)
        )
        worker.start()

    def _room_progress(
        self, worker: SakuraRoomWorker, value: int, message: str
    ) -> None:
        if self._room_worker is not worker:
            return
        self.progress.setValue(value)
        self._set_status(self.host_status, message, "busy")

    def _room_log(self, worker: SakuraRoomWorker, line: str) -> None:
        if self._room_worker is not worker:
            return
        self._append_log(line)

    def _append_log(self, line: str) -> None:
        text = str(line or "")
        if not text:
            return
        if self._token:
            text = text.replace(self._token, "***")
        text = re.sub(
            r"(?i)((?:access[_ ]?)?token\s*[=:]\s*)\S+", r"\1***", text
        )
        if not self.log_box.isVisible():
            self.log_box.setVisible(True)
        self.log_box.appendPlainText(text)
        bar = self.log_box.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _room_ready(
        self, worker: SakuraRoomWorker, payload, error: str
    ) -> None:
        if self._room_worker is not worker:
            return
        self._room_worker = None
        self._busy = False
        if error or not isinstance(payload, dict):
            self.progress.setVisible(False)
            self._set_status(
                self.host_status, error or "创建房间失败。", "error"
            )
            self._set_badge(self.host_badge, "已连接", "green")
            self._auto_room_flow = False
            self._set_badge(self.quick_badge, "失败", "red")
            self._set_quick_status(error or "创建房间失败。", "error")
            self.toast(error or "创建房间失败", "error")
            self._sync_controls()
            return

        self._room_payload = payload
        self.main.config.sakura_tunnel_id = int(payload.get("tunnel_id") or 0)
        self.main.config.sakura_node_id = int(payload.get("node_id") or 0)
        self.main.config.save()
        self.progress.setValue(100)
        self.progress.setVisible(False)
        self._set_status(
            self.host_status, "隧道已准备，正在启动内置 frpc…", "busy"
        )
        self._set_badge(self.host_badge, "连接中", "blue")
        self._start_tunnel(payload)

    def _start_tunnel(self, payload: dict) -> None:
        process = SakuraTunnelProcess(
            payload.get("frpc_path", ""),
            payload.get("config_path", ""),
            self,
        )
        self._tunnel_process = process
        process.log_line.connect(self._append_log)
        process.ready.connect(self._tunnel_ready)
        process.failed.connect(self._tunnel_failed)
        process.finished.connect(self._tunnel_finished)
        process.start()
        self._sync_controls()

    def _tunnel_ready(self, message: str) -> None:
        if self._closing or self._room_payload is None:
            return
        payload = self._room_payload
        self._set_badge(self.host_badge, "房间开启", "green")
        code = str(payload.get("room_code") or "")
        if code:
            self._set_status(
                self.host_status,
                f"房间已开启（{message}）。把房间号发给朋友即可。",
                "success",
            )
        else:
            self._set_status(
                self.host_status,
                "房间已开启，但房间号生成失败，请直接分享服务器地址。",
                "warning",
            )
        self._show_room_result(payload)
        self.progress.setVisible(False)
        if self._auto_room_flow or self.quick_save_combo.currentData():
            self._auto_room_flow = False
            self._lan_timer.stop()
            self._set_badge(self.quick_badge, "房间开启", "green")
            address = str(
                payload.get("room_code") or payload.get("address") or ""
            )
            if address:
                self._set_quick_status(
                    f"房间已创建，把房间号或地址发给朋友即可：{address}",
                    "success",
                )
            else:
                self._set_quick_status("房间已创建。", "success")
        self._sync_controls()

    def _show_room_result(self, payload: dict) -> None:
        code = str(payload.get("room_code") or "")
        address = str(payload.get("address") or "")
        share = str(payload.get("share_address") or address)
        self.room_code_label.setText(code or "房间号不可用")
        if code:
            self.room_code_label.setStyleSheet(
                "font-size: 24px; font-weight: 800; letter-spacing: 2px;"
            )
            self.copy_code_btn.setEnabled(True)
        else:
            self.room_code_label.setStyleSheet(
                "font-size: 14px; font-weight: 700;"
            )
            self.copy_code_btn.setEnabled(False)
        self.room_address_label.setText(f"服务器地址：{address}")
        detail = (
            f"隧道 #{payload.get('tunnel_id', '?')} · "
            f"{payload.get('node_name', '')} · "
            f"本地端口 {payload.get('local_port', '')} · "
            f"frpc {payload.get('frpc_version', '')}"
        )
        code_error = str(payload.get("code_error") or "")
        if code_error:
            detail += f"\n{code_error}"
        if share and share != address:
            detail += f"\n节点地址：{share}"
        self.room_detail_label.setText(detail)
        self.result_box.setVisible(True)
        self._sync_social_room(code or address)
        self._sync_controls()

    def _tunnel_failed(self, message: str) -> None:
        if self._closing:
            return
        process = self._tunnel_process
        if process is not None:
            try:
                process.blockSignals(True)
                process.stop()
            except Exception:
                pass
        self._fail_room(message)

    def _tunnel_finished(self, code: int) -> None:
        if self._closing or self._tunnel_process is None:
            return
        self._tunnel_process = None
        if self._room_payload is not None:
            self._fail_room(f"内置 frpc 已退出（代码 {code}），房间已关闭。")

    def _fail_room(self, message: str) -> None:
        payload = self._room_payload
        if payload:
            remove_tunnel_config(payload.get("config_path"))
            self._clear_social_room()
        self._room_payload = None
        self._tunnel_process = None
        self._busy = False
        self.progress.setVisible(False)
        self._set_badge(
            self.host_badge, "已连接" if self._user else "未连接",
            "green" if self._user else "gray",
        )
        self._set_status(self.host_status, message, "error")
        self.result_box.setVisible(False)
        self._auto_room_flow = False
        self._auto_create_pending = False
        self._lan_timer.stop()
        if hasattr(self, "quick_badge"):
            self._set_badge(self.quick_badge, "失败", "red")
            self._set_quick_status(message, "error")
        self.toast(message, "error")
        self._sync_controls()

    def close_room(self) -> None:
        if self._busy:
            worker = self._room_worker
            if worker:
                worker.cancel()
            self._room_worker = None
            self._busy = False
        process = self._tunnel_process
        self._closing = True
        self._tunnel_process = None
        if process is not None:
            process.blockSignals(True)
            process.stop()
        payload = self._room_payload
        if payload:
            remove_tunnel_config(payload.get("config_path"))
            self._clear_social_room()
        self._room_payload = None
        self.progress.setVisible(False)
        self._set_badge(
            self.host_badge, "已连接" if self._user else "未连接",
            "green" if self._user else "gray",
        )
        self._set_status(self.host_status, "房间已关闭。", "muted")
        self.result_box.setVisible(False)
        self._closing = False
        self._auto_room_flow = False
        self._auto_create_pending = False
        self._lan_timer.stop()
        if hasattr(self, "quick_badge"):
            self._set_badge(self.quick_badge, "待命", "gray")
            self._set_quick_status("房间已关闭，可以重新选存档建房。", "muted")
        self._sync_controls()

    def _copy_room_code(self) -> None:
        code = self.room_code_label.text()
        if not code or code == "房间号不可用":
            self.toast("当前没有可复制的房间号", "info")
            return
        self._copy_text(code, "房间号")

    def _copy_host_address(self) -> None:
        if not self._room_payload:
            return
        self._copy_text(
            str(self._room_payload.get("address") or ""), "服务器地址"
        )

    def _sync_social_room(self, room_code: str) -> None:
        if not room_code:
            return
        try:
            self.main.social_store.set_room(
                room_code, str(self.main.selected_version or "")
            )
        except Exception:
            pass

    def _clear_social_room(self) -> None:
        try:
            self.main.social_store.set_room("", "")
        except Exception:
            pass

    def _copy_invite_card(self) -> None:
        if self._invite_worker is not None:
            return
        payload = self._room_payload or {}
        code = str(payload.get("room_code") or payload.get("address") or "")
        if not code:
            self.toast("房间还没有准备好，稍等一下喵", "info")
            return
        try:
            profile = self.main.social_store.ensure_profile(
                self.main.display_name()
            )
        except Exception as exc:
            self.toast(f"生成邀请卡失败：{exc}", "error")
            return
        worker = RoomInviteWorker(
            profile,
            code,
            str(self.main.selected_version or ""),
            self.main.config,
            self.main.versions,
            self,
        )
        self._invite_worker = worker
        self.copy_invite_btn.setEnabled(False)
        self.copy_invite_btn.setText("整理 Mod 清单…")
        worker.progress.connect(self._on_invite_progress)
        worker.finished.connect(self._on_invite_ready)
        worker.start()

    def _on_invite_progress(self, percent: int, message: str) -> None:
        if self._invite_worker is None:
            return
        self.copy_invite_btn.setText(
            f"整理清单 {max(0, min(99, int(percent)))}%"
        )

    def _on_invite_ready(self, success: bool, message: str, text: str) -> None:
        self._invite_worker = None
        if self._closing:
            return
        self.copy_invite_btn.setEnabled(True)
        self.copy_invite_btn.setText("好友邀请卡")
        if not success:
            self.toast(message or "生成邀请卡失败", "error")
            return
        QApplication.clipboard().setText(text)
        self.toast(message or "好友邀请卡已复制", "success")

    def _open_mod_sync(self) -> None:
        version_id = str(self.version_combo.currentData() or "")
        ModSyncDialog(
            self.main, self._invite_manifest, version_id
        ).exec()

    def join_friend_room(self, room_code: str, version_id: str = "") -> None:
        """从好友簿进入房间：填好房间号和版本，直接走客人启动流程。"""
        if self.main.game_running and (
            not version_id or self.main.find_game_session(version_id)
        ):
            self._copy_text(room_code, "好友房间地址")
            return
        text = str(room_code or "").strip()
        if not text:
            self.toast("好友还没有分享房间号", "info")
            return
        self.code_edit.setText(text)
        self._format_code_field()
        self._update_code_preview()
        if version_id:
            index = self.version_combo.findData(version_id)
            if index < 0:
                self._set_status(
                    self.guest_status,
                    f"好友房间使用 {version_id}，你还没有安装这个版本。"
                    "请先安装相同版本再加入。",
                    "error",
                )
                self.toast(f"缺少版本 {version_id}", "error")
                return
            self.version_combo.setCurrentIndex(index)
        if not self._decoded_address:
            self._set_status(
                self.guest_status, "好友房间号无效，请让对方重新发一张邀请卡。", "error"
            )
            return
        self.join_room()

    # ------------------------------------------------------------------
    # 客机流程

    def _sync_versions(self) -> None:
        versions = list(self.main.game_version_summaries())
        current = self.version_combo.currentData() if self.version_combo.count() else ""
        preferred = str(current or self.main.selected_version or "")
        self.version_combo.blockSignals(True)
        self.version_combo.clear()
        for summary in versions:
            kind = summary.loader or summary.type_name or ""
            label = f"{summary.id} · {kind}" if kind else summary.id
            if summary.error:
                label += "（文件异常）"
            self.version_combo.addItem(label, summary.id)
        if versions:
            index = self.version_combo.findData(preferred)
            if index < 0:
                index = 0
            self.version_combo.setCurrentIndex(index)
        else:
            self.version_combo.addItem("未安装游戏版本", "")
        self.version_combo.blockSignals(False)
        self._sync_quick_versions()
        self._sync_controls()

    def _sync_selection(self, version_id: str) -> None:
        if not version_id:
            return
        index = self.version_combo.findData(version_id)
        if index >= 0 and index != self.version_combo.currentIndex():
            self.version_combo.blockSignals(True)
            self.version_combo.setCurrentIndex(index)
            self.version_combo.blockSignals(False)
        if hasattr(self, "quick_version_combo"):
            quick_index = self.quick_version_combo.findData(version_id)
            if (
                quick_index >= 0
                and quick_index != self.quick_version_combo.currentIndex()
            ):
                self.quick_version_combo.setCurrentIndex(quick_index)

    def _update_code_preview(self) -> None:
        text = self.code_edit.text().strip()
        if not text:
            self._decoded_address = ""
            self._clear_invite_manifest()
            self.code_hint.setText(
                "也可以直接粘贴 host:port 形式的服务器地址。"
            )
            self._set_status(
                self.guest_status, "房主创建房间后，把房间号发给你即可。", "muted"
            )
            self._sync_controls()
            return
        if self._handle_invite_text(text):
            return
        try:
            host, port = decode_room_input(text)
        except SakuraError as exc:
            self._decoded_address = ""
            if len(re.sub(r"[\s\-_]", "", text)) >= 8:
                self.code_hint.setText(str(exc))
                self._set_status(self.guest_status, str(exc), "error")
            else:
                self.code_hint.setText("继续输入完整的 13 位房间号…")
                self._set_status(self.guest_status, "正在读取房间号…", "muted")
            self._sync_controls()
            return
        self._decoded_address = f"{host}:{port}"
        hint = f"将连接 {self._decoded_address}"
        if self._invite_manifest is not None:
            hint += f" · 房主清单 {self._invite_manifest.mod_count} 个 Mod"
        self.code_hint.setText(hint)
        message = "房间号有效，选择版本后即可启动。"
        if self._invite_manifest is not None:
            message += " 也可以先同步房主 Mod。"
        self._set_status(self.guest_status, message, "success")
        self._sync_controls()

    def _handle_invite_text(self, text: str) -> bool:
        if text.startswith(INVITE_PREFIX):
            try:
                invite = parse_invite(text)
            except SocialError as exc:
                self._decoded_address = ""
                self.code_hint.setText(str(exc))
                self._set_status(self.guest_status, str(exc), "error")
                self._sync_controls()
                return True
            manifest = None
            manifest_error = ""
            if invite.mod_manifest:
                try:
                    manifest = decode_manifest(invite.mod_manifest)
                except RoomSyncError as exc:
                    manifest_error = str(exc)
            self._invite_manifest = manifest
            self._invite_room_code = invite.room_code
            self._update_sync_button()
            if invite.room_version:
                index = self.version_combo.findData(invite.room_version)
                if index >= 0:
                    self.version_combo.setCurrentIndex(index)
            if invite.room_code:
                self.code_edit.blockSignals(True)
                self.code_edit.setText(invite.room_code)
                self.code_edit.blockSignals(False)
                # _update_code_preview 已经会把房主清单数量拼进提示，避免重复追加。
                self._update_code_preview()
                return True
            self._decoded_address = ""
            if self.code_edit.text().strip() == text:
                self.code_edit.blockSignals(True)
                self.code_edit.clear()
                self.code_edit.blockSignals(False)
            if manifest_error:
                self.code_hint.setText(
                    f"邀请卡里的 Mod 清单无法读取：{manifest_error}"
                )
                self._set_status(self.guest_status, manifest_error, "error")
            elif manifest is not None and manifest.mods:
                self.code_hint.setText(
                    f"已读取房主 {manifest.name or '好友'} 的 "
                    f"{manifest.mod_count} 个 Mod 清单。"
                )
                self._set_status(
                    self.guest_status,
                    "清单已就绪，填写房间号后可以先同步 Mod 再加入。",
                    "success",
                )
            else:
                self.code_hint.setText(
                    "邀请卡里没有 Mod 清单，房主可能使用的是旧版本。"
                )
                self._set_status(
                    self.guest_status,
                    "请让房主用新版本重新复制邀请卡，或手动输入房间号。",
                    "warning",
                )
            self._sync_controls()
            return True
        if text.startswith("DKLM1:"):
            try:
                manifest = decode_manifest(text)
            except RoomSyncError as exc:
                self._decoded_address = ""
                self.code_hint.setText(str(exc))
                self._set_status(self.guest_status, str(exc), "error")
                self._sync_controls()
                return True
            self._invite_manifest = manifest
            self._invite_room_code = ""
            self._update_sync_button()
            self._decoded_address = ""
            if self.code_edit.text().strip() == text:
                self.code_edit.blockSignals(True)
                self.code_edit.clear()
                self.code_edit.blockSignals(False)
            self.code_hint.setText(
                f"已读取房主 {manifest.name or '好友'} 的 "
                f"{manifest.mod_count} 个 Mod 清单。请填写房间号。"
            )
            self._set_status(
                self.guest_status,
                "Mod 清单已就绪，可以点击“同步房主 Mod”补齐文件。",
                "success",
            )
            self._sync_controls()
            return True
        if (
            self._invite_manifest is not None
            and self._invite_room_code
            and text != self._invite_room_code
        ):
            self._clear_invite_manifest()
        return False

    def _update_sync_button(self) -> None:
        if not hasattr(self, "sync_mods_btn"):
            return
        count = self._invite_manifest.mod_count if self._invite_manifest else 0
        self.sync_mods_btn.setText(
            f"同步房主 Mod（{count}）" if count else "同步房主 Mod"
        )
        self.sync_mods_btn.setToolTip(
            f"邀请卡里包含 {count} 个 Mod，可以补齐当前版本缺少的文件"
            if count
            else "读取邀请卡里的 Mod 清单，补齐当前版本缺少的 Mod"
        )

    def _clear_invite_manifest(self) -> None:
        if self._invite_manifest is None and not self._invite_room_code:
            return
        self._invite_manifest = None
        self._invite_room_code = ""
        self._update_sync_button()

    def _format_code_field(self) -> None:
        text = self.code_edit.text().strip()
        if not text or ":" in text:
            return
        try:
            raw = normalize_room_code(text)
        except SakuraError:
            return
        formatted = f"{raw[:5]}-{raw[5:9]}-{raw[9:]}"
        if formatted != text:
            self.code_edit.setText(formatted)

    def _paste_code(self) -> None:
        text = QApplication.clipboard().text().strip()
        if not text:
            self.toast("剪贴板为空", "info")
            return
        self.code_edit.setText(text)
        self._format_code_field()
        self._update_code_preview()

    def _copy_guest_address(self) -> None:
        if not self._decoded_address:
            self._update_code_preview()
        if not self._decoded_address:
            self.toast("请先输入有效的房间号", "info")
            return
        self._copy_text(self._decoded_address, "服务器地址")

    def join_room(self) -> None:
        self._update_code_preview()
        if not self._decoded_address:
            self._set_status(
                self.guest_status, "请先输入有效的房间号。", "error"
            )
            return
        address = self._decoded_address
        if self.main.install_active:
            self.toast("正在安装游戏文件，请稍候", "info")
            return
        version_id = str(self.version_combo.currentData() or "")
        if not version_id:
            self.toast("请先安装一个游戏版本", "info")
            return
        existing = self.main.find_game_session(version_id)
        if existing is not None:
            self._copy_text(address, "服务器地址")
            self._set_status(
                self.guest_status,
                "这个版本已经在运行，地址已复制。请在多人游戏中添加服务器。",
                "warning",
            )
            return
        if version_id != self.main.selected_version:
            self.main.home_page.select_version(version_id)
        self._set_status(
            self.guest_status,
            f"正在启动 {version_id} 并连接 {address}…",
            "busy",
        )
        key = self.main.launch_selected(connect_address=address)
        if not key:
            self._set_status(
                self.guest_status,
                "启动没有完成，请查看启动器提示或运行日志。",
                "error",
            )

    def _copy_text(self, text: str, label: str) -> None:
        if not text:
            self.toast(f"没有可复制的{label}", "info")
            return
        QApplication.clipboard().setText(text)
        self.toast(f"{label}已复制", "success")

    # ------------------------------------------------------------------
    # 其他

    def _on_game_state(self, running: bool) -> None:
        if running:
            self.join_btn.setText("游戏运行中 · 复制地址")
        else:
            self.join_btn.setText("启动游戏并进入")
            self._lan_timer.stop()
            if self._auto_room_flow:
                self._auto_room_flow = False
                self._set_badge(self.quick_badge, "待命", "gray")
                self._set_quick_status(
                    "游戏没有运行，一键联机已停止。", "muted"
                )
            if self._tunnel_process is not None or self._room_payload is not None:
                self.close_room()
                self._set_quick_status(
                    "游戏已关闭，房间也随之关闭。", "muted"
                )
        self.detect_btn.setEnabled(running)
        if hasattr(self, "join_btn"):
            self.join_btn.setIcon(
                icons.icon("copy" if running else "play", "#FFFFFF", 16)
            )
        self._sync_controls()

    def _sync_controls(self) -> None:
        if not hasattr(self, "create_btn"):
            return
        room_active = self._tunnel_process is not None or self._room_payload is not None
        self.create_btn.setEnabled(
            bool(self._user) and not self._busy and not room_active
        )
        self.close_btn.setVisible(
            room_active or self._room_worker is not None
        )
        self.connect_btn.setEnabled(not self._busy and not room_active)
        self.token_edit.setEnabled(not room_active)
        self.node_combo.setEnabled(not room_active and bool(self._nodes))
        self.node_refresh.setEnabled(not self._busy and not room_active)
        self.port_spin.setEnabled(not room_active)
        self.detect_btn.setEnabled(not room_active and self.main.game_running)
        has_version = bool(self.version_combo.currentData())
        self.join_btn.setEnabled(has_version and not self._busy)
        self.copy_decode_btn.setEnabled(has_version)
        if hasattr(self, "sync_mods_btn"):
            self.sync_mods_btn.setEnabled(not self._busy)
        if hasattr(self, "quick_start_btn"):
            quick_ready = bool(
                self.quick_version_combo.currentData()
                and self.quick_save_combo.currentData()
            )
            self.quick_start_btn.setEnabled(
                quick_ready
                and not self._busy
                and not room_active
                and not self._auto_room_flow
                and not self.main.launch_active
            )
            idle = not room_active and not self._busy
            self.quick_version_combo.setEnabled(idle)
            self.quick_save_combo.setEnabled(idle)
            self.quick_refresh_btn.setEnabled(idle)
            if hasattr(self, "quick_mod_btn"):
                self.quick_mod_btn.setEnabled(not self._busy)
                self.quick_mod_help_btn.setEnabled(not self._busy)
                self.quick_mod_page_btn.setEnabled(not self._busy)

    def toast(self, text: str, kind: str = "info") -> None:
        self.main.toast(text, kind)

    def _open_url(self, url: str) -> None:
        QDesktopServices.openUrl(QUrl(url))

    def shutdown(self) -> None:
        self._closing = True
        self._lan_timer.stop()
        self._lan_worker = None
        self._auto_room_flow = False
        self._auto_create_pending = False
        if hasattr(self, "easytier_panel"):
            self.easytier_panel.shutdown()
        worker = self._room_worker
        if worker:
            worker.cancel()
            self._room_worker = None
        login = self._login_worker
        if login:
            self._login_worker = None
        invite = self._invite_worker
        if invite:
            invite.cancel()
            self._invite_worker = None
        process = self._tunnel_process
        self._tunnel_process = None
        if process is not None:
            process.blockSignals(True)
            process.stop()
        payload = self._room_payload
        if payload:
            remove_tunnel_config(payload.get("config_path"))
            self._clear_social_room()
        self._room_payload = None
