package com.mcdev.probe;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import net.minecraft.SharedConstants;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.registries.ForgeRegistries;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class ProbeServer {
    private static final Gson GSON = new Gson();
    private static HttpServer server;
    private static ExecutorService executor;
    private static MinecraftServer mc;
    private static String token = "mcdev";

    private ProbeServer() {
    }

    public static synchronized void start(MinecraftServer serverIn, int port, String tokenIn) {
        if (server != null) {
            return;
        }
        mc = serverIn;
        token = tokenIn == null ? "" : tokenIn;
        try {
            server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
            server.createContext("/status", ProbeServer::handleStatus);
            server.createContext("/log/tail", ProbeServer::handleLogTail);
            server.createContext("/command", ProbeServer::handleCommand);
            server.createContext("/world/block", ProbeServer::handleWorldBlock);
            server.createContext("/world/break", ProbeServer::handleWorldBreak);
            server.createContext("/world/mine", ProbeServer::handleWorldMine);
            server.createContext("/items", ProbeServer::handleItems);
            server.createContext("/recipe", ProbeServer::handleRecipe);
            server.createContext("/craft", ProbeServer::handleCraft);
            server.createContext("/loot", ProbeServer::handleLoot);
            server.createContext("/item", ProbeServer::handleItem);
            server.createContext("/run/dump", ProbeServer::handleRunDump);
            server.createContext("/bot/spawn", ProbeServer::handleBotSpawn);
            server.createContext("/bot/list", ProbeServer::handleBotList);
            server.createContext("/bot/remove", ProbeServer::handleBotRemove);
            server.createContext("/bot/state", ProbeServer::handleBotState);
            server.createContext("/bot/look", ProbeServer::handleBotLook);
            server.createContext("/bot/move", ProbeServer::handleBotMove);
            server.createContext("/bot/mine", ProbeServer::handleBotMine);
            server.createContext("/bot/place", ProbeServer::handleBotPlace);
            server.createContext("/bot/use", ProbeServer::handleBotUse);
            server.createContext("/bot/give", ProbeServer::handleBotGive);
            server.createContext("/bot/attack", ProbeServer::handleBotAttack);
            server.createContext("/bot/gamemode", ProbeServer::handleBotGameMode);
            server.createContext("/screenshot", ProbeServer::handleNotClient);
            server.createContext("/ui/snapshot", ProbeServer::handleNotClient);
            server.createContext("/ui/click", ProbeServer::handleNotClient);
            executor = Executors.newFixedThreadPool(2);
            server.setExecutor(executor);
            server.start();
            McdevProbe.LOGGER.info("Mcdev Probe listening on 127.0.0.1:{}", port);
        } catch (IOException e) {
            McdevProbe.LOGGER.error("Failed to start Mcdev Probe", e);
        }
    }

    public static synchronized void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }

    private static void handleStatus(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("side", "server");
        data.put("tick", mc.getTickCount());
        data.put("gameTime", mc.overworld().getGameTime());
        data.put("dayTime", mc.overworld().getDayTime());
        data.put("players", mc.getPlayerList().getPlayerCount());
        data.put("maxPlayers", mc.getPlayerList().getMaxPlayers());
        data.put("level", mc.getWorldData().getLevelName());
        data.put("version", SharedConstants.getCurrentVersion().getName());
        data.put("frozen", TickControl.isFrozen());
        data.put("stepBudget", TickControl.getStepBudget());
        data.put("bots", FakePlayers.names());
        ok(ex, data);
    }

    private static void handleLogTail(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int n = intQuery(ex, "n", 100);
        JsonObject data = new JsonObject();
        data.add("lines", ProbeLogs.tail(n));
        ok(ex, data);
    }

    private static void handleCommand(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            error(ex, 405, "POST required");
            return;
        }
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        final String cmd;
        try {
            JsonObject obj = JsonParser.parseString(body).getAsJsonObject();
            cmd = obj.get("cmd").getAsString();
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        CompletableFuture<Integer> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                future.complete(mc.getCommands()
                        .performPrefixedCommand(mc.createCommandSourceStack(), cmd));
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            int result = future.get(10, TimeUnit.SECONDS);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("cmd", cmd);
            data.put("result", result);
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "command failed: " + e.getMessage());
        }
    }

    private static void handleWorldBlock(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int x = intQuery(ex, "x", 0);
        int y = intQuery(ex, "y", 64);
        int z = intQuery(ex, "z", 0);
        String dim = strQuery(ex, "dim", "minecraft:overworld");
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                ResourceKey<Level> key = ResourceKey.create(
                        Registries.DIMENSION, new ResourceLocation(dim));
                ServerLevel level = mc.getLevel(key);
                if (level == null) {
                    level = mc.overworld();
                }
                BlockPos pos = new BlockPos(x, y, z);
                BlockState state = level.getBlockState(pos);
                BlockEntity be = level.getBlockEntity(pos);
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("dim", level.dimension().location().toString());
                data.put("pos", x + "," + y + "," + z);
                data.put("block", String.valueOf(ForgeRegistries.BLOCKS.getKey(state.getBlock())));
                data.put("state", state.toString());
                data.put("analog", state.getAnalogOutputSignal(level, pos));
                data.put("blockEntity", be == null ? null : be.saveWithoutMetadata().toString());
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "world query failed: " + e.getMessage());
        }
    }

    private static void handleWorldBreak(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int x = intQuery(ex, "x", 0);
        int y = intQuery(ex, "y", 64);
        int z = intQuery(ex, "z", 0);
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                ServerLevel level = mc.overworld();
                BlockPos pos = new BlockPos(x, y, z);
                BlockState state = level.getBlockState(pos);
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("pos", x + "," + y + "," + z);
                data.put("blockBefore", String.valueOf(ForgeRegistries.BLOCKS.getKey(state.getBlock())));
                data.put("removed", level.destroyBlock(pos, true));
                AABB box = new AABB(x - 3, y - 3, z - 3, x + 4, y + 4, z + 4);
                List<Map<String, Object>> drops = new ArrayList<>();
                int total = 0;
                for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, box)) {
                    ItemStack stack = entity.getItem();
                    Map<String, Object> drop = new LinkedHashMap<>();
                    drop.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem())));
                    drop.put("count", stack.getCount());
                    drops.add(drop);
                    total += stack.getCount();
                }
                data.put("drops", drops);
                data.put("total", total);
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "world break failed: " + e.getMessage());
        }
    }

    private static void handleWorldMine(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int x = intQuery(ex, "x", 0);
        int y = intQuery(ex, "y", 64);
        int z = intQuery(ex, "z", 0);
        String playerName = strQuery(ex, "player", "Dev");
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                ServerPlayer player = mc.getPlayerList().getPlayerByName(playerName);
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("pos", x + "," + y + "," + z);
                data.put("player", playerName);
                if (player == null) {
                    data.put("found", false);
                    data.put("error", "player not online");
                    future.complete(data);
                    return;
                }
                ServerLevel level = mc.overworld();
                BlockPos pos = new BlockPos(x, y, z);
                data.put("before", String.valueOf(ForgeRegistries.BLOCKS.getKey(level.getBlockState(pos).getBlock())));
                GameType oldMode = player.gameMode.getGameModeForPlayer();
                player.setGameMode(GameType.SURVIVAL);
                data.put("removed", player.gameMode.destroyBlock(pos));
                player.setGameMode(oldMode);
                AABB box = new AABB(x - 3, y - 3, z - 3, x + 4, y + 4, z + 4);
                List<Map<String, Object>> drops = new ArrayList<>();
                int total = 0;
                for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, box)) {
                    ItemStack stack = entity.getItem();
                    Map<String, Object> drop = new LinkedHashMap<>();
                    drop.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem())));
                    drop.put("count", stack.getCount());
                    drops.add(drop);
                    total += stack.getCount();
                }
                data.put("drops", drops);
                data.put("total", total);
                data.put("after", String.valueOf(ForgeRegistries.BLOCKS.getKey(level.getBlockState(pos).getBlock())));
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "world mine failed: " + e.getMessage());
        }
    }

    private static void handleItems(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int x = intQuery(ex, "x", 0);
        int y = intQuery(ex, "y", 64);
        int z = intQuery(ex, "z", 0);
        int r = Math.min(16, Math.max(1, intQuery(ex, "r", 4)));
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                ServerLevel level = mc.overworld();
                AABB box = new AABB(x - r, y - r, z - r, x + r + 1, y + r + 1, z + r + 1);
                List<Map<String, Object>> drops = new ArrayList<>();
                int total = 0;
                for (ItemEntity entity : level.getEntitiesOfClass(ItemEntity.class, box)) {
                    ItemStack stack = entity.getItem();
                    Map<String, Object> drop = new LinkedHashMap<>();
                    drop.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem())));
                    drop.put("count", stack.getCount());
                    drops.add(drop);
                    total += stack.getCount();
                }
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("pos", x + "," + y + "," + z);
                data.put("radius", r);
                data.put("drops", drops);
                data.put("total", total);
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "items query failed: " + e.getMessage());
        }
    }

    private static void handleCraft(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        String recipeId = strQuery(ex, "recipe", "");
        String playerName = strQuery(ex, "player", "Dev");
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("recipe", recipeId);
                data.put("player", playerName);
                ServerPlayer player = mc.getPlayerList().getPlayerByName(playerName);
                if (player == null) {
                    data.put("found", false);
                    data.put("crafted", false);
                    data.put("error", "player not online");
                    future.complete(data);
                    return;
                }
                ResourceLocation rl = ResourceLocation.tryParse(recipeId);
                if (rl == null) {
                    data.put("found", false);
                    data.put("crafted", false);
                    data.put("error", "invalid recipe id");
                    future.complete(data);
                    return;
                }
                var optional = mc.getRecipeManager().byKey(rl);
                if (optional.isEmpty()) {
                    data.put("found", false);
                    data.put("crafted", false);
                    data.put("error", "recipe not found");
                    future.complete(data);
                    return;
                }
                Recipe<?> recipe = optional.get();
                data.put("found", true);
                List<Map<String, Object>> consumed = new ArrayList<>();
                List<String> missing = new ArrayList<>();
                var inventory = player.getInventory().items;
                for (Ingredient ingredient : recipe.getIngredients()) {
                    boolean emptyIngredient = true;
                    for (ItemStack candidate : ingredient.getItems()) {
                        if (!candidate.isEmpty()) {
                            emptyIngredient = false;
                            break;
                        }
                    }
                    if (ingredient.isEmpty() || emptyIngredient) {
                        continue;
                    }
                    boolean matched = false;
                    for (ItemStack stack : inventory) {
                        if (!stack.isEmpty() && ingredient.test(stack)) {
                            Map<String, Object> entry = new LinkedHashMap<>();
                            entry.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem())));
                            entry.put("count", 1);
                            consumed.add(entry);
                            stack.shrink(1);
                            matched = true;
                            break;
                        }
                    }
                    if (!matched) {
                        missing.add(ingredient.toString());
                    }
                }
                data.put("consumed", consumed);
                data.put("missing", missing);
                if (!missing.isEmpty()) {
                    data.put("crafted", false);
                    future.complete(data);
                    return;
                }
                ItemStack result = recipe.getResultItem(mc.registryAccess()).copy();
                ItemStack output = result.copy();
                boolean added = player.getInventory().add(result);
                if (!added) {
                    player.drop(result, false);
                }
                Map<String, Object> out = new LinkedHashMap<>();
                out.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(output.getItem())));
                out.put("count", output.getCount());
                data.put("crafted", true);
                data.put("result", out);
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "craft failed: " + e.getMessage());
        }
    }

    private static void handleRecipe(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        String id = strQuery(ex, "id", "");
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("id", id);
                ResourceLocation rl = ResourceLocation.tryParse(id);
                if (rl == null) {
                    data.put("found", false);
                    data.put("error", "invalid recipe id");
                    future.complete(data);
                    return;
                }
                var optional = mc.getRecipeManager().byKey(rl);
                if (optional.isEmpty()) {
                    data.put("found", false);
                    future.complete(data);
                    return;
                }
                Recipe<?> recipe = optional.get();
                ItemStack result = recipe.getResultItem(mc.registryAccess());
                data.put("found", true);
                data.put("item", result.isEmpty() ? null
                        : String.valueOf(ForgeRegistries.ITEMS.getKey(result.getItem())));
                data.put("count", result.getCount());
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "recipe query failed: " + e.getMessage());
        }
    }

    private static void handleLoot(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        String blockId = strQuery(ex, "block", "");
        int x = intQuery(ex, "x", 0);
        int y = intQuery(ex, "y", 64);
        int z = intQuery(ex, "z", 0);
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("block", blockId);
                ResourceLocation rl = ResourceLocation.tryParse(blockId);
                Block block = rl == null ? null : ForgeRegistries.BLOCKS.getValue(rl);
                if (block == null) {
                    data.put("found", false);
                    future.complete(data);
                    return;
                }
                ServerLevel level = mc.overworld();
                List<ItemStack> drops = Block.getDrops(
                        block.defaultBlockState(), level, new BlockPos(x, y, z),
                        null, null, ItemStack.EMPTY);
                List<Map<String, Object>> list = new ArrayList<>();
                int total = 0;
                for (ItemStack stack : drops) {
                    Map<String, Object> drop = new LinkedHashMap<>();
                    drop.put("item", String.valueOf(ForgeRegistries.ITEMS.getKey(stack.getItem())));
                    drop.put("count", stack.getCount());
                    list.add(drop);
                    total += stack.getCount();
                }
                data.put("found", true);
                data.put("drops", list);
                data.put("total", total);
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "loot query failed: " + e.getMessage());
        }
    }

    private static void handleItem(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        String itemId = strQuery(ex, "item", "");
        String nbt = strQuery(ex, "nbt", "");
        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                Map<String, Object> data = new LinkedHashMap<>();
                data.put("item", itemId);
                ResourceLocation rl = ResourceLocation.tryParse(itemId);
                Item item = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
                if (item == null) {
                    data.put("found", false);
                    future.complete(data);
                    return;
                }
                ItemStack stack = new ItemStack(item);
                if (!nbt.isEmpty()) {
                    String snbt = nbt.startsWith("{") ? nbt : "{" + nbt + "}";
                    CompoundTag tag = TagParser.parseTag(snbt);
                    stack.setTag(tag);
                }
                data.put("found", true);
                data.put("visible", item.isBarVisible(stack));
                data.put("width", item.getBarWidth(stack));
                data.put("color", item.getBarColor(stack));
                future.complete(data);
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        try {
            ok(ex, future.get(10, TimeUnit.SECONDS));
        } catch (Exception e) {
            error(ex, 500, "item query failed: " + e.getMessage());
        }
    }

    private static void handleRunDump(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        int n = intQuery(ex, "n", 500);
        ok(ex, RunRecorder.dump(n));
    }

    // ------------------------------------------------------------------
    // 纯后台假玩家：不启动客户端，也能在服务端操作一个真实玩家实体。
    // ------------------------------------------------------------------
    private static void handleBotSpawn(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            error(ex, 405, "POST required");
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        final String name = optString(body, "name", "Dev");
        final String gameMode = optString(body, "gamemode", "creative");
        try {
            Map<String, Object> data = onServer(() -> {
                ServerLevel level = mc.overworld();
                double x;
                double y;
                double z;
                if (body.has("x") && body.has("y") && body.has("z")) {
                    x = optDouble(body, "x", 0.0D);
                    y = optDouble(body, "y", 64.0D);
                    z = optDouble(body, "z", 0.0D);
                } else {
                    BlockPos spawn = level.getSharedSpawnPos();
                    BlockPos top = level.getHeightmapPos(
                            Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn);
                    x = top.getX() + 0.5D;
                    y = top.getY();
                    z = top.getZ() + 0.5D;
                }
                BlockPos pos = BlockPos.containing(x, y, z);
                level.getChunk(pos);
                String message = FakePlayers.spawn(level, name, pos, gameMode);
                FakePlayer player = FakePlayers.get(name);
                Map<String, Object> d = new LinkedHashMap<>();
                d.put("message", message);
                d.put("name", name);
                d.put("state", player == null ? null : FakePlayers.state(player, 8.0D));
                return d;
            });
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot spawn failed: " + e.getMessage());
        }
    }

    private static void handleBotList(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        ok(ex, Map.of("bots", FakePlayers.names()));
    }

    private static void handleBotRemove(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "");
        ok(ex, Map.of("name", name, "removed", FakePlayers.remove(name)));
    }

    private static void handleBotState(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        String name = strQuery(ex, "name", "Dev");
        double radius = doubleQuery(ex, "radius", 8.0D);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null : FakePlayers.state(player, radius);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot state failed: " + e.getMessage());
        }
    }

    private static void handleBotLook(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        float yaw = (float) optDouble(body, "yaw", 0.0D);
        float pitch = (float) optDouble(body, "pitch", 0.0D);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                if (player == null) {
                    return null;
                }
                FakePlayers.look(player, yaw, pitch);
                return FakePlayers.state(player, 1.0D);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot look failed: " + e.getMessage());
        }
    }

    private static void handleBotMove(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        String mode = optString(body, "mode", "teleport").toLowerCase();
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                if (player == null) {
                    return null;
                }
                if ("walk".equals(mode) || "relative".equals(mode)) {
                    FakePlayers.walk(player,
                            optDouble(body, "dx", 0.0D),
                            optDouble(body, "dy", 0.0D),
                            optDouble(body, "dz", 0.0D),
                            optInt(body, "steps", 20));
                } else {
                    double x = body.has("x") ? optDouble(body, "x", player.getX()) : player.getX();
                    double y = body.has("y") ? optDouble(body, "y", player.getY()) : player.getY();
                    double z = body.has("z") ? optDouble(body, "z", player.getZ()) : player.getZ();
                    FakePlayers.teleport(player, x, y, z);
                }
                return FakePlayers.state(player, 8.0D);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot move failed: " + e.getMessage());
        }
    }

    private static void handleBotMine(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        int x = optInt(body, "x", 0);
        int y = optInt(body, "y", 64);
        int z = optInt(body, "z", 0);
        int timeout = optInt(body, "timeoutMs", 6000);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null
                        : FakePlayers.mine(player, new BlockPos(x, y, z), timeout);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot mine failed: " + e.getMessage());
        }
    }

    private static void handleBotPlace(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        BlockPos pos = new BlockPos(
                optInt(body, "x", 0), optInt(body, "y", 64), optInt(body, "z", 0));
        String face = optString(body, "face", "up");
        String item = optString(body, "item", "minecraft:stone");
        int count = optInt(body, "count", 1);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null
                        : FakePlayers.place(player, pos, face, item, count);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot place failed: " + e.getMessage());
        }
    }

    private static void handleBotUse(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null : FakePlayers.useItem(player);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot use failed: " + e.getMessage());
        }
    }

    private static void handleBotGive(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        String item = optString(body, "item", "minecraft:stone");
        int count = optInt(body, "count", 1);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null : FakePlayers.give(player, item, count);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot give failed: " + e.getMessage());
        }
    }

    private static void handleBotAttack(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        int entity = optInt(body, "entity", -1);
        String target = optString(body, "target", "");
        double radius = optDouble(body, "radius", 4.0D);
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                return player == null ? null
                        : FakePlayers.attack(player, entity, target, radius);
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot attack failed: " + e.getMessage());
        }
    }

    private static void handleBotGameMode(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        JsonObject body;
        try {
            body = jsonBody(ex);
        } catch (Exception e) {
            error(ex, 400, "invalid json: " + e.getMessage());
            return;
        }
        String name = optString(body, "name", "Dev");
        String mode = optString(body, "gamemode", "creative");
        try {
            Map<String, Object> data = onServer(() -> {
                FakePlayer player = FakePlayers.get(name);
                if (player == null) {
                    return null;
                }
                String applied = FakePlayers.setGameMode(player, mode);
                Map<String, Object> d = FakePlayers.state(player, 1.0D);
                d.put("applied", applied);
                return d;
            });
            if (data == null) {
                error(ex, 404, "no fake player " + name);
                return;
            }
            ok(ex, data);
        } catch (Exception e) {
            error(ex, 500, "bot gamemode failed: " + e.getMessage());
        }
    }

    private static void handleNotClient(HttpExchange ex) throws IOException {
        if (!authorized(ex)) {
            return;
        }
        error(ex, 501, "client-only endpoint; this probe is running on the server");
    }

    private static boolean authorized(HttpExchange ex) throws IOException {
        if (token.isEmpty()) {
            return true;
        }
        String got = ex.getRequestHeaders().getFirst("X-Mcdev-Token");
        if (token.equals(got)) {
            return true;
        }
        error(ex, 401, "invalid token");
        return false;
    }

    private static void ok(HttpExchange ex, Object data) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("ok", true);
        root.add("data", GSON.toJsonTree(data));
        send(ex, 200, root);
    }

    private static void error(HttpExchange ex, int code, String message) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("ok", false);
        JsonObject err = new JsonObject();
        err.addProperty("message", message);
        root.add("error", err);
        send(ex, code, root);
    }

    private static void send(HttpExchange ex, int code, JsonObject body) throws IOException {
        byte[] bytes = GSON.toJson(body).getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static <T> T onServer(Callable<T> task) throws Exception {
        CompletableFuture<T> future = new CompletableFuture<>();
        mc.execute(() -> {
            try {
                future.complete(task.call());
            } catch (Throwable t) {
                future.completeExceptionally(t);
            }
        });
        return future.get(30, TimeUnit.SECONDS);
    }

    private static JsonObject jsonBody(HttpExchange ex) throws Exception {
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        if (body.isBlank()) {
            return new JsonObject();
        }
        return JsonParser.parseString(body).getAsJsonObject();
    }

    private static String optString(JsonObject obj, String key, String def) {
        try {
            if (obj != null && obj.has(key) && !obj.get(key).isJsonNull()) {
                return obj.get(key).getAsString();
            }
        } catch (Exception ignored) {
            // 类型不对时回退默认值，让接口保持可诊断而不是直接 500。
        }
        return def;
    }

    private static int optInt(JsonObject obj, String key, int def) {
        try {
            if (obj != null && obj.has(key) && !obj.get(key).isJsonNull()) {
                return obj.get(key).getAsInt();
            }
        } catch (Exception ignored) {
            // 同上。
        }
        return def;
    }

    private static double optDouble(JsonObject obj, String key, double def) {
        try {
            if (obj != null && obj.has(key) && !obj.get(key).isJsonNull()) {
                return obj.get(key).getAsDouble();
            }
        } catch (Exception ignored) {
            // 同上。
        }
        return def;
    }

    private static double doubleQuery(HttpExchange ex, String key, double def) {
        String raw = strQuery(ex, key, null);
        if (raw == null) {
            return def;
        }
        try {
            return Double.parseDouble(raw);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static int intQuery(HttpExchange ex, String key, int def) {
        String raw = strQuery(ex, key, null);
        if (raw == null) {
            return def;
        }
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static String strQuery(HttpExchange ex, String key, String def) {
        String query = ex.getRequestURI().getQuery();
        if (query == null || query.isEmpty()) {
            return def;
        }
        for (String part : query.split("&")) {
            int eq = part.indexOf('=');
            if (eq < 0) {
                continue;
            }
            String k = URLDecoder.decode(part.substring(0, eq), StandardCharsets.UTF_8);
            if (k.equals(key)) {
                return URLDecoder.decode(part.substring(eq + 1), StandardCharsets.UTF_8);
            }
        }
        return def;
    }
}
