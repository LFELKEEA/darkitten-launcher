from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import zipfile
from datetime import date, datetime
from pathlib import Path

SITE = Path(__file__).resolve().parent
PUBLIC = SITE / "public"
DOWNLOADS = PUBLIC / "downloads"
PET_RELEASE = SITE / "pet_release.json"
DEFAULT_SOURCE = Path(os.environ.get("DKL_SOURCE", str(SITE.parent / "launcher")))
MOD_AGENT_SOURCE = Path(os.environ.get("DMA_SOURCE", str(SITE.parent / "mod_agent")))
MOD_AGENT_ASSETS = MOD_AGENT_SOURCE / "assets"
MOD_AGENT_DIST = MOD_AGENT_SOURCE / "dist"
DELIVERY = Path(os.environ.get("DKL_DELIVERY", str(Path.home() / "Tianxi")))
DEFAULT_REPO = "darkitten-launcher"
# GitHub Git Blob API 对单次请求体积有限制，超过这个大小的发布包必须走 Release 资源。
MAX_PAGES_FILE_BYTES = 30 * 1024 * 1024

EXCLUDED_NAMES = {
    "config.json",
    "social.json",
    "assistant.json",
    "frpc.exe",
}
EXCLUDED_PARTS = {
    "__pycache__",
    ".writing",
    "cache",
    # EasyTier 联机组件由启动器首次开房时按需下载，不随包分发。
    "easytier",
    "logs",
    "minecraft",
    "servers",
    "rooms",
    "runtime",
    "pyruntime",
    "skins",
    "test_game",
    "updates",
    ".git",
    ".idea",
    ".vscode",
    ".ai-memory",
    "node_modules",
    "reports",
    ".deploy",
    "downloads",
}
TEXT_SUFFIXES = {
    ".py", ".txt", ".json", ".md", ".bat", ".cmd", ".ps1", ".sh",
    ".html", ".css", ".js", ".svg", ".yml", ".yaml", ".toml", ".ini",
    ".cfg", ".properties", ".xml", ".java", ".gradle", ".kts", ".csv",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_version(source: Path) -> str:
    text = (source / "darkitten" / "config.py").read_text(encoding="utf-8")
    match = re.search(r'APP_VERSION\s*=\s*"([^"]+)"', text)
    if not match:
        raise SystemExit("无法从 darkitten/config.py 读取 APP_VERSION")
    return match.group(1)


def source_include(relative: Path) -> bool:
    if any(part in EXCLUDED_PARTS for part in relative.parts):
        return False
    if relative.name in EXCLUDED_NAMES:
        return False
    if relative.suffix.lower() in (".pyc", ".pyo", ".log"):
        return False
    if relative.parts and relative.parts[0] == "qa" and relative.suffix.lower() == ".png":
        return False
    return True


def website_include(relative: Path) -> bool:
    if any(part in EXCLUDED_PARTS for part in relative.parts):
        return False
    if relative.parts and relative.parts[0] == "qa":
        return False
    if "downloads" in relative.parts:
        return False
    if relative.suffix.lower() in (".pyc", ".pyo", ".log"):
        return False
    return True


def write_zip(target: Path, entries: list[tuple[Path, str]]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source, arcname in entries:
            archive.write(source, arcname)


def source_files(source: Path) -> list[Path]:
    return sorted(
        path.relative_to(source)
        for path in source.rglob("*")
        if path.is_file() and source_include(path.relative_to(source))
    )


PACKAGE_EXCLUDED_PARTS = {"qa"}


def package_files(source: Path) -> list[Path]:
    """发布包只带启动器运行所需的代码与资源，不带测试、工具和网站源码。"""
    return [
        relative
        for relative in source_files(source)
        if not (relative.parts and relative.parts[0] in PACKAGE_EXCLUDED_PARTS)
    ]


def website_files() -> list[Path]:
    return sorted(
        path.relative_to(SITE)
        for path in SITE.rglob("*")
        if path.is_file() and website_include(path.relative_to(SITE))
    )


def decode_text(path: Path) -> str:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def text_entries(source: Path) -> list[tuple[str, Path]]:
    entries: list[tuple[str, Path]] = []
    for relative in package_files(source):
        if relative.suffix.lower() in TEXT_SUFFIXES:
            entries.append((relative.as_posix(), source / relative))
    return entries


def write_source_txt(target: Path, source: Path, version: str) -> None:
    entries = text_entries(source)
    lines = [
        f"Darkitten Launcher {version} 完整源代码",
        f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"文本文件：{len(entries)}",
        "=" * 80,
        "目录",
        "=" * 80,
    ]
    lines.extend(f"  {name}" for name, _ in entries)
    lines.extend(["", "=" * 80, ""])
    for name, path in entries:
        lines.append("#" * 80)
        lines.append(f"# FILE: {name}")
        lines.append("#" * 80)
        lines.append(decode_text(path).rstrip())
        lines.append("")
        lines.append("")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


LEGACY_SHIM_UPDATER = '''from __future__ import annotations

import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


def _legacy_version(install_dir: Path) -> str:
    try:
        text = (install_dir / "stellar" / "config.py").read_text(encoding="utf-8")
    except Exception:
        return ""
    match = re.search(r'APP_VERSION\\s*=\\s*"([^"]+)"', text)
    return match.group(1) if match else ""


def apply_update_code(payload_root: Path, install_dir: Path) -> Path:
    """1.9.14 及更早版本只有 stellar 包，这里转交给新的 darkitten 实现。"""
    payload_root = Path(payload_root).resolve()
    install_dir = Path(install_dir).resolve()
    legacy_version = _legacy_version(install_dir)
    if str(payload_root) not in sys.path:
        sys.path.insert(0, str(payload_root))
    from darkitten.updater import apply_update_code as apply_new

    backup = apply_new(payload_root, install_dir)
    if legacy_version and backup.name.startswith("backup-unknown-"):
        renamed = backup.with_name(
            backup.name.replace("backup-unknown-", f"backup-{legacy_version}-", 1)
        )
        try:
            backup.rename(renamed)
            backup = renamed
        except Exception:
            pass

    legacy = install_dir / "stellar"
    if legacy.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        target = install_dir / "updates" / f"legacy-stellar-{stamp}"
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(legacy), str(target))
        except Exception:
            shutil.rmtree(legacy, ignore_errors=True)
    return backup
'''


def legacy_shim_entries(
    directory: Path, version: str, update_root: str
) -> list[tuple[Path, str]]:
    shim = directory / "stellar"
    shim.mkdir(parents=True, exist_ok=True)
    (shim / "__init__.py").write_text("", encoding="utf-8")
    (shim / "config.py").write_text(
        f'APP_VERSION = "{version}"\n', encoding="utf-8"
    )
    (shim / "updater.py").write_text(LEGACY_SHIM_UPDATER, encoding="utf-8")
    return [
        (path, f"{update_root}/stellar/{path.relative_to(shim).as_posix()}")
        for path in sorted(shim.rglob("*"))
        if path.is_file()
    ]


def load_pet_release() -> dict | None:
    """桌宠体积超过 GitHub Pages 单文件上限，走 Release 资源，清单里只放元数据。"""
    if not PET_RELEASE.is_file():
        return None
    try:
        data = json.loads(PET_RELEASE.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SystemExit(f"pet_release.json 读取失败：{exc}") from exc
    if not isinstance(data, dict):
        raise SystemExit("pet_release.json 必须是一个 JSON 对象")
    version = str(data.get("version") or "").strip()
    url = str(data.get("download_url") or "").strip()
    digest = str(data.get("sha256") or "").strip().lower()
    try:
        size = int(data.get("size") or 0)
    except Exception:
        size = 0
    if not version:
        raise SystemExit("pet_release.json 缺少 version")
    if not url.startswith(("http://", "https://")):
        raise SystemExit("pet_release.json 的 download_url 必须是完整地址")
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise SystemExit("pet_release.json 的 sha256 不是有效的 64 位十六进制")
    if size <= 0:
        raise SystemExit("pet_release.json 的 size 无效")
    return {
        "name": str(data.get("name") or "LFELKEEA 桌宠"),
        "version": version,
        "released": str(data.get("released") or ""),
        "size": size,
        "sha256": digest,
        "download_url": url,
        "notes": [str(item) for item in (data.get("notes") or []) if str(item).strip()],
    }


def load_mod_agent_release() -> dict | None:
    """模组工坊的发布包较小，直接跟随下载站发布；dist 有产物时自动同步。"""
    source = MOD_AGENT_DIST / "mod_agent_release.json"
    target = PUBLIC / "mod_agent_release.json"
    if not source.is_file():
        if not target.is_file():
            print("mod agent: 没有找到发布清单，跳过", flush=True)
            return None
        source = target
    try:
        data = json.loads(source.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise SystemExit(f"mod_agent_release.json 读取失败：{exc}") from exc
    if not isinstance(data, dict):
        raise SystemExit("mod_agent_release.json 必须是一个 JSON 对象")
    version = str(data.get("version") or "").strip()
    url = str(data.get("download_url") or "").strip()
    digest = str(data.get("sha256") or "").strip().lower()
    try:
        size = int(data.get("size") or 0)
    except Exception:
        size = 0
    if not version:
        raise SystemExit("mod_agent_release.json 缺少 version")
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise SystemExit("mod_agent_release.json 的 sha256 不是有效的 64 位十六进制")
    if size <= 0:
        raise SystemExit("mod_agent_release.json 的 size 无效")
    if url.startswith(("http://", "https://")):
        package = None
    else:
        name = Path(url).name
        package = MOD_AGENT_DIST / name
        if not package.is_file():
            package = (PUBLIC / url).resolve()
        if PUBLIC.resolve() not in package.parents and MOD_AGENT_DIST.resolve() not in package.parents:
            raise SystemExit("mod_agent_release.json 的 download_url 越出网站目录")
        if not package.is_file():
            raise SystemExit(f"找不到模组工坊发布包：{url}")

    if package is not None:
        actual_sha = sha256(package)
        actual_size = package.stat().st_size
        if actual_sha != digest:
            raise SystemExit(
                f"模组工坊发布包 SHA-256 不匹配：清单 {digest}，实际 {actual_sha}"
            )
        if actual_size != size:
            raise SystemExit(
                f"模组工坊发布包大小不匹配：清单 {size}，实际 {actual_size}"
            )
        if package.parent != DOWNLOADS:
            DOWNLOADS.mkdir(parents=True, exist_ok=True)
            shutil.copy2(package, DOWNLOADS / package.name)
        if str(data.get("download_url", "")).startswith(("http://", "https://")):
            data["download_url"] = f"downloads/{package.name}"
    elif size >= 95 * 1024 * 1024:
        raise SystemExit(
            "模组工坊发布包超过 GitHub Pages 单文件建议上限，请改走 GitHub Releases。"
        )

    icon = MOD_AGENT_ASSETS / "dma.png"
    if icon.is_file():
        (PUBLIC / "assets").mkdir(parents=True, exist_ok=True)
        shutil.copy2(icon, PUBLIC / "assets" / "dma.png")

    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return {
        "version": version,
        "size": size,
        "download_url": str(data.get("download_url") or ""),
    }


def sync_site_version(version: str) -> None:
    index = PUBLIC / "index.html"
    text = index.read_text(encoding="utf-8")
    previous = ""
    try:
        manifest = json.loads((PUBLIC / "update.json").read_text(encoding="utf-8"))
        previous = str(manifest.get("version") or "")
    except (OSError, ValueError):
        pass
    if previous and previous != version:
        # 精确替换上一版版本号，避免误伤页面里的 Minecraft 版本号。
        text = text.replace(previous, version)
    else:
        text = re.sub(r"1\.(?:9|10)\.\d+", version, text)
    index.write_text(text, encoding="utf-8")

    script = PUBLIC / "app.js"
    text = script.read_text(encoding="utf-8")
    text = re.sub(r'(\|\| ")\d+\.\d+\.\d+(")', rf"\g<1>{version}\g<2>", text)
    text = re.sub(
        r'(FEEDBACK_VERSION_FALLBACK\s*=\s*")\d+\.\d+\.\d+(")',
        rf"\g<1>{version}\g<2>",
        text,
    )
    script.write_text(text, encoding="utf-8")


def find_gh() -> str:
    for candidate in (shutil.which("gh"), r"C:\Program Files\GitHub CLI\gh.exe"):
        if candidate and Path(candidate).is_file():
            return candidate
    raise SystemExit("未找到 GitHub CLI（gh），请先安装并登录。")


def run_gh(gh: str, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(
        [gh, *args], text=True, encoding="utf-8", errors="replace", capture_output=True
    )
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise SystemExit(f"GitHub 命令失败：gh {' '.join(args)}\n{detail}")
    return result


def gh_api(
    gh: str,
    endpoint: str,
    method: str | None = None,
    payload: dict | None = None,
    check: bool = True,
) -> dict:
    args = ["api"]
    if method:
        args.extend(["-X", method])
    args.append(endpoint)
    input_text = None
    if payload is not None:
        args.extend(["--input", "-"])
        input_text = json.dumps(payload, ensure_ascii=False)
    result = subprocess.run(
        [gh, *args],
        input=input_text,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
    )
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise SystemExit(f"GitHub API 调用失败：{endpoint}\n{detail}")
    if result.returncode != 0:
        return {}
    text = result.stdout.strip()
    if not text:
        if check:
            raise SystemExit(f"GitHub API 返回空响应：{endpoint}")
        return {}
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        if check:
            raise SystemExit(f"GitHub API 返回无效 JSON：{endpoint}\n{text[:400]}") from exc
        return {}


def ensure_repo(gh: str, repo: str) -> str:
    if "/" in repo:
        target = repo
    else:
        probe = run_gh(gh, "repo", "view", repo, "--json", "nameWithOwner", "--jq", ".nameWithOwner", check=False)
        if probe.returncode == 0:
            return probe.stdout.strip()
        user = run_gh(gh, "api", "user", "--jq", ".login").stdout.strip()
        target = f"{user}/{repo}"

    probe = run_gh(gh, "repo", "view", target, "--json", "nameWithOwner", "--jq", ".nameWithOwner", check=False)
    if probe.returncode == 0:
        return probe.stdout.strip()

    created = run_gh(
        gh, "repo", "create", target, "--public",
        "--description", "Darkitten Launcher 下载站与完整源码",
        check=False,
    )
    if created.returncode != 0:
        detail = (created.stderr or created.stdout).strip()
        raise SystemExit(f"创建 GitHub 仓库失败：{detail}")
    return target


def repo_is_empty(gh: str, full: str) -> bool:
    return not bool(gh_api(gh, f"repos/{full}/git/refs", check=False))


def upload_tree(
    gh: str,
    full: str,
    branch: str,
    files: list[tuple[str, Path]],
    message: str,
    *,
    base_tree: bool = False,
) -> None:
    if repo_is_empty(gh, full):
        # Git Data API 在完全空的仓库上会返回 409，先用 Contents API 建立首个提交。
        gh_api(
            gh, f"repos/{full}/contents/.nojekyll", "PUT",
            {
                "message": "chore: initialize repository",
                "content": base64.b64encode(b"\n").decode("ascii"),
            },
        )

    ref = gh_api(gh, f"repos/{full}/git/ref/heads/{branch}", check=False)
    parent = str(ref.get("object", {}).get("sha") or "") or None

    entries: list[dict] = []
    for relative, path in files:
        content = base64.b64encode(path.read_bytes()).decode("ascii")
        blob: dict = {}
        for attempt in range(3):
            try:
                blob = gh_api(
                    gh, f"repos/{full}/git/blobs", "POST",
                    {"content": content, "encoding": "base64"},
                )
                break
            except SystemExit:
                if attempt == 2:
                    raise
                time.sleep(2)
        entries.append(
            {"path": relative, "mode": "100644", "type": "blob", "sha": blob["sha"]}
        )

    payload: dict = {"tree": entries}
    if base_tree and parent:
        # 增量覆盖：保留远端已有文件（例如历史下载包），只替换本次上传的路径。
        # 读不到父提交的 tree 时必须中止，否则会把整个分支覆盖成本次文件。
        parent_commit = gh_api(gh, f"repos/{full}/git/commits/{parent}", check=False)
        base_sha = str(parent_commit.get("tree", {}).get("sha") or "")
        if not base_sha:
            raise SystemExit(
                "base_tree 失败：读不到父提交的 tree，已中止上传以避免覆盖远端文件。"
            )
        payload["base_tree"] = base_sha
    tree = gh_api(gh, f"repos/{full}/git/trees", "POST", payload)
    print(f"upload {branch}: {len(entries)} files, tree {tree['sha']}", flush=True)
    # 新建 tree 后立刻提交偶尔会触发 GitHub 的复制延迟（Tree SHA does not exist），短暂等待后重试。
    commit: dict = {}
    for attempt in range(4):
        try:
            commit = gh_api(
                gh, f"repos/{full}/git/commits", "POST",
                {
                    "message": message,
                    "tree": tree["sha"],
                    "parents": [parent] if parent else [],
                },
            )
            break
        except SystemExit:
            if attempt == 3:
                raise
            time.sleep(2 * (attempt + 1))
    if parent:
        gh_api(
            gh, f"repos/{full}/git/refs/heads/{branch}", "PATCH",
            {"sha": commit["sha"], "force": False},
        )
    else:
        gh_api(
            gh, f"repos/{full}/git/refs", "POST",
            {"ref": f"refs/heads/{branch}", "sha": commit["sha"]},
        )


def deploy_github(version: str, repo: str, source: Path) -> str:
    gh = find_gh()
    auth = run_gh(gh, "auth", "status", check=False)
    if auth.returncode != 0:
        raise SystemExit("GitHub CLI 尚未登录，请先运行 gh auth login 完成授权。")

    full = ensure_repo(gh, repo)
    (PUBLIC / ".nojekyll").write_text("", encoding="utf-8")

    public_files = []
    for path in sorted(PUBLIC.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(PUBLIC)
        if ".git" in relative.parts or ".sync-part" in path.name:
            continue
        if path.stat().st_size > MAX_PAGES_FILE_BYTES:
            print(
                f"skip pages upload: {relative.as_posix()} "
                f"({path.stat().st_size} bytes) 请使用 Release 资源",
                flush=True,
            )
            continue
        public_files.append((relative.as_posix(), path))
    # 增量覆盖 gh-pages：以远端现有 tree 为基底，历史版本的下载包不会被删除。
    upload_tree(
        gh, full, "gh-pages", public_files,
        f"deploy: Darkitten Launcher {version}", base_tree=True,
    )

    source_repo_files = [
        (relative.as_posix(), source / relative) for relative in source_files(source)
    ]
    source_repo_files.extend(
        (f"website/{relative.as_posix()}", SITE / relative)
        for relative in website_files()
    )
    upload_tree(gh, full, "main", source_repo_files, f"source: Darkitten Launcher {version}")

    pages_payload = {"source": {"branch": "gh-pages", "path": "/"}}
    pages = gh_api(gh, f"repos/{full}/pages", check=False)
    if not pages:
        # 仓库首次推送 gh-pages 时 GitHub 可能已经自动启用 Pages，409 视为成功。
        gh_api(gh, f"repos/{full}/pages", "POST", pages_payload, check=False)
    gh_api(gh, f"repos/{full}/pages", "PUT", pages_payload, check=False)

    info = gh_api(gh, f"repos/{full}/pages", check=False)
    owner, name = full.split("/", 1)
    return str(info.get("html_url") or f"https://{owner.lower()}.github.io/{name}/")


def build(source: Path, version: str, deploy: bool, repo: str) -> int:
    notes_map = json.loads((SITE / "release_notes.json").read_text(encoding="utf-8"))
    if version not in notes_map:
        raise SystemExit(f"release_notes.json 缺少 {version} 的更新说明，请先补充。")

    sync_site_version(version)
    source_entries: list[tuple[Path, str]] = []
    root = f"DarkittenLauncher-{version}-source"
    for relative in package_files(source):
        source_entries.append((source / relative, f"{root}/{relative.as_posix()}"))

    update_entries: list[tuple[Path, str]] = []
    update_root = f"DKL-{version}"
    for name in (
        "app.py",
        "requirements.txt",
        "launch.bat",
        "启动.bat",
        "bootstrap_runtime.ps1",
    ):
        path = source / name
        if path.is_file():
            update_entries.append((path, f"{update_root}/{name}"))
    for name in ("darkitten", "assets", "tools/enchcracker"):
        folder = source / name
        if not folder.is_dir():
            continue
        for path in sorted(folder.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(source)
            if any(part == "__pycache__" for part in relative.parts):
                continue
            if path.suffix.lower() in (".pyc", ".pyo", ".log"):
                continue
            update_entries.append((path, f"{update_root}/{relative.as_posix()}"))

    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    source_zip = DOWNLOADS / f"DarkittenLauncher-{version}-source.zip"
    update_zip = DOWNLOADS / f"DKL-{version}-update.zip"
    source_txt = DOWNLOADS / f"DarkittenLauncher-{version}-source.txt"
    write_zip(source_zip, source_entries)
    # 更新包额外带一份 stellar 兼容垫片：1.9.14 的旧更新器只认 stellar/config.py
    # 和 stellar.updater，用它把更新转交给 darkitten 后再清理旧包。
    with tempfile.TemporaryDirectory(prefix="dkl-legacy-shim-") as shim_tmp:
        update_entries.extend(
            legacy_shim_entries(Path(shim_tmp), version, update_root)
        )
        write_zip(update_zip, update_entries)
    write_source_txt(source_txt, source, version)

    manifest = {
        "version": version,
        "released": date.today().isoformat(),
        "notes": notes_map[version],
        "download_url": f"downloads/{update_zip.name}",
        "page_url": "https://lfelkeea.github.io/darkitten-launcher/",
        "source_url": f"downloads/{source_zip.name}",
        "source_txt_url": f"downloads/{source_txt.name}",
        "sha256": sha256(update_zip),
        "size": update_zip.stat().st_size,
        "source_sha256": sha256(source_zip),
        "source_size": source_zip.stat().st_size,
        "source_txt_sha256": sha256(source_txt),
        "source_txt_size": source_txt.stat().st_size,
    }
    pet_meta = load_pet_release()
    if pet_meta:
        manifest["pet"] = pet_meta
    mod_agent_meta = load_mod_agent_release()
    (PUBLIC / "update.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    DELIVERY.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_zip, DELIVERY / source_zip.name)
    shutil.copy2(source_txt, DELIVERY / source_txt.name)

    for archive_path in (source_zip, update_zip):
        with zipfile.ZipFile(archive_path) as archive:
            bad = archive.testzip()
            if bad:
                raise SystemExit(f"{archive_path.name} 校验失败：{bad}")

    print("version:", version)
    print("source zip:", len(source_entries), "entries,", source_zip.stat().st_size, "bytes")
    print("update zip:", len(update_entries), "entries,", update_zip.stat().st_size, "bytes")
    print("source txt:", len(text_entries(source)), "files,", source_txt.stat().st_size, "bytes")
    print("update sha256:", manifest["sha256"])
    print("source sha256:", manifest["source_sha256"])
    print("source txt sha256:", manifest["source_txt_sha256"])
    if pet_meta:
        print(
            "pet:",
            pet_meta["version"],
            pet_meta["size"],
            "bytes",
            pet_meta["download_url"],
        )
    if mod_agent_meta:
        print(
            "mod agent:",
            mod_agent_meta["version"],
            mod_agent_meta["size"],
            "bytes",
            mod_agent_meta["download_url"],
        )

    if deploy:
        pages_url = deploy_github(version, repo, source)
        print("pages url:", pages_url)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="构建并发布 Darkitten Launcher")
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE, help="启动器源码目录")
    parser.add_argument("--version", default="", help="默认读取 darkitten/config.py")
    parser.add_argument("--deploy", action="store_true", help="构建后部署到 GitHub Pages")
    parser.add_argument("--repo", default=DEFAULT_REPO, help="GitHub 仓库名或 owner/repo")
    args = parser.parse_args()
    source = args.source.resolve()
    version = args.version or read_version(source)
    return build(source, version, args.deploy, args.repo)


if __name__ == "__main__":
    raise SystemExit(main())
