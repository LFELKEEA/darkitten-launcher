from __future__ import annotations

import shutil
import struct
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

"""Switch 游戏镜像（XCI / NSP）识别与解包。

网上流传的 .sfxv 大多是改了扩展名的 Switch 卡带镜像，文件头仍是 XCI 的
``HEAD`` 标记，第 0x130 字节记录根 HFS0 分区偏移。这里只做无损解包：
把分区里的原始文件（通常是 .nca）导出到文件夹，不依赖主机密钥，也不修改源文件。
"""

XCI_MAGIC = b"HEAD"
HFS0_MAGIC = b"HFS0"
PFS0_MAGIC = b"PFS0"
XCI_ROOT_OFFSET_POS = 0x130
MAX_ENTRIES = 200_000
MAX_STRING_TABLE = 16 * 1024 * 1024
_COPY_CHUNK = 4 * 1024 * 1024

ProgressCallback = Callable[[int, str], None]
CancelCheck = Callable[[], bool]


class SwitchImageError(Exception):
    pass


class SwitchImageCancelled(SwitchImageError):
    pass


@dataclass(frozen=True)
class SwitchFile:
    name: str
    offset: int
    size: int


@dataclass(frozen=True)
class SwitchPartition:
    name: str
    offset: int
    size: int
    kind: str = "raw"
    files: tuple[SwitchFile, ...] = ()


@dataclass(frozen=True)
class SwitchImageInfo:
    path: Path
    format: str
    partitions: tuple[SwitchPartition, ...]
    total_bytes: int
    file_count: int

    @property
    def format_label(self) -> str:
        if self.format == "xci":
            return "Switch 卡带镜像（XCI）"
        if self.format == "nsp":
            return "Switch 数字版安装包（NSP）"
        return "Switch 游戏镜像"

    @property
    def partition_label(self) -> str:
        names = "、".join(part.name for part in self.partitions if part.name) or "无"
        return names


def _u32(buffer: bytes, offset: int) -> int:
    return struct.unpack_from("<I", buffer, offset)[0]


def _u64(buffer: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", buffer, offset)[0]


def _align(value: int, alignment: int = 0x200) -> int:
    remainder = value % alignment
    return value if remainder == 0 else value + alignment - remainder


def _safe_name(name: str, fallback: str) -> str:
    cleaned = name.replace("\\", "/").rsplit("/", 1)[-1].strip()
    cleaned = cleaned.replace("\x00", "")
    if cleaned in ("", ".", ".."):
        cleaned = fallback
    if len(cleaned) > 180:
        cleaned = cleaned[:180]
    return cleaned


def _parse_string_table(table: bytes) -> list[tuple[int, str]]:
    entries: list[tuple[int, str]] = []
    start = 0
    while start < len(table):
        end = table.find(b"\x00", start)
        if end < 0:
            end = len(table)
        raw = table[start:end]
        if raw:
            entries.append((start, raw.decode("utf-8", "replace")))
        start = end + 1
    return entries


def _name_at(entries: list[tuple[int, str]], offset: int, fallback: str) -> str:
    for position, text in entries:
        if position == offset:
            return text
    return fallback


def _read_filesystem(
    handle,
    base: int,
    limit: int,
    prefix: str,
) -> tuple[str, list[SwitchFile]]:
    if base < 0 or base + 0x10 > limit:
        return "raw", []
    handle.seek(base)
    header = handle.read(0x10)
    if len(header) < 0x10:
        return "raw", []
    magic = header[:4]
    if magic not in (HFS0_MAGIC, PFS0_MAGIC):
        return "raw", []

    count = _u32(header, 4)
    string_size = _u32(header, 8)
    if count > MAX_ENTRIES or string_size > MAX_STRING_TABLE:
        raise SwitchImageError("分区表异常，文件可能已损坏")

    entry_size = 0x40 if magic == HFS0_MAGIC else 0x18
    table_end = base + 0x10 + count * entry_size
    if table_end + string_size > limit:
        raise SwitchImageError("分区表越界，文件可能已损坏")

    entries: list[tuple[int, int, int]] = []
    for index in range(count):
        handle.seek(base + 0x10 + index * entry_size)
        raw = handle.read(entry_size)
        if len(raw) < 0x18:
            raise SwitchImageError("分区条目不完整")
        offset = _u64(raw, 0)
        size = _u64(raw, 8)
        string_offset = _u32(raw, 16)
        entries.append((offset, size, string_offset))

    handle.seek(table_end)
    names = _parse_string_table(handle.read(string_size))
    data_start = _align(table_end + string_size) if magic == HFS0_MAGIC else table_end + string_size

    files: list[SwitchFile] = []
    for index, (offset, size, string_offset) in enumerate(entries):
        absolute = data_start + offset
        if size <= 0:
            continue
        if absolute < 0 or absolute + size > limit:
            raise SwitchImageError("文件数据越界，文件可能已损坏")
        name = _safe_name(
            _name_at(names, string_offset, f"{prefix}{index:03d}.bin"),
            f"{prefix}{index:03d}.bin",
        )
        files.append(SwitchFile(name=name, offset=absolute, size=size))
    return ("hfs0" if magic == HFS0_MAGIC else "pfs0"), files


def looks_like_switch_image(path: Path | str) -> bool:
    source = Path(path)
    try:
        size = source.stat().st_size
        if size < 0x10:
            return False
        with source.open("rb") as handle:
            head = handle.read(0x200)
    except OSError:
        return False
    if head[:4] == PFS0_MAGIC:
        return True
    if len(head) < 0x200:
        return False
    if head[0x100:0x104] != XCI_MAGIC:
        return False
    root = _u32(head, XCI_ROOT_OFFSET_POS)
    return 0 < root < size


def inspect_switch_image(path: Path | str) -> SwitchImageInfo:
    source = Path(path)
    if not source.is_file():
        raise SwitchImageError("找不到这个游戏镜像文件")
    size = source.stat().st_size
    if size < 0x10:
        raise SwitchImageError("文件太小，不像 Switch 游戏镜像")

    with source.open("rb") as handle:
        head = handle.read(0x200)
        if head[:4] == PFS0_MAGIC:
            kind, files = _read_filesystem(handle, 0, size, "file")
            if kind == "raw":
                raise SwitchImageError("PFS0 分区表读取失败")
            partition = SwitchPartition(
                name="内容",
                offset=0,
                size=size,
                kind=kind,
                files=tuple(files),
            )
            return _build_info(source, "nsp", (partition,))

        if head[0x100:0x104] != XCI_MAGIC:
            raise SwitchImageError("这个文件不是 Switch 的 XCI / NSP 镜像")
        root_offset = _u32(head, XCI_ROOT_OFFSET_POS)
        if not 0 < root_offset < size:
            raise SwitchImageError("XCI 根分区偏移无效，文件可能已损坏")

        root_kind, root_files = _read_filesystem(handle, root_offset, size, "partition")
        if root_kind == "raw" or not root_files:
            raise SwitchImageError("没有找到 XCI 分区表")

        partitions: list[SwitchPartition] = []
        for entry in root_files:
            name = entry.name or f"partition-{len(partitions)}"
            nested_kind, nested_files = _read_filesystem(
                handle, entry.offset, entry.offset + entry.size, "file"
            )
            partitions.append(
                SwitchPartition(
                    name=name,
                    offset=entry.offset,
                    size=entry.size,
                    kind=nested_kind,
                    files=tuple(nested_files),
                )
            )
    return _build_info(source, "xci", tuple(partitions))


def _build_info(
    path: Path, image_format: str, partitions: tuple[SwitchPartition, ...]
) -> SwitchImageInfo:
    total = 0
    count = 0
    for part in partitions:
        if part.files:
            total += sum(item.size for item in part.files)
            count += len(part.files)
        elif part.kind == "raw":
            total += part.size
            count += 1
    return SwitchImageInfo(
        path=path,
        format=image_format,
        partitions=partitions,
        total_bytes=total,
        file_count=count,
    )


def _copy_range(
    source: Path,
    offset: int,
    size: int,
    target: Path,
    on_bytes: Callable[[int], None],
    cancel: CancelCheck | None,
) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    remaining = size
    with source.open("rb") as src, target.open("wb") as dst:
        src.seek(offset)
        while remaining > 0:
            if cancel and cancel():
                raise SwitchImageCancelled("已取消解包")
            chunk = src.read(min(_COPY_CHUNK, remaining))
            if not chunk:
                raise SwitchImageError("读取源文件时意外结束")
            dst.write(chunk)
            remaining -= len(chunk)
            on_bytes(len(chunk))


def _unique_target(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    for index in range(2, 1000):
        candidate = path.with_name(f"{stem} ({index}){suffix}")
        if not candidate.exists():
            return candidate
    return path


def extract_switch_image(
    path: Path | str,
    destination: Path | str,
    progress: ProgressCallback | None = None,
    cancel: CancelCheck | None = None,
) -> tuple[Path, int]:
    """把镜像里的原始文件解包到 destination，返回 (输出目录, 文件数)。"""
    info = inspect_switch_image(path)
    source = info.path
    target_root = Path(destination)
    try:
        target_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise SwitchImageError(f"无法创建输出目录：{exc}") from exc

    total = max(info.total_bytes, 1)
    done = 0
    written = 0
    last_report = 0.0

    def tick(chunk: int) -> None:
        nonlocal done, last_report
        done += chunk
        now = time.monotonic()
        if progress and now - last_report >= 0.1:
            last_report = now
            progress(min(100, int(done * 100 / total)), "正在解包")

    for part in info.partitions:
        part_dir = target_root / _safe_name(part.name, "partition")
        if not part.files and part.kind != "raw":
            continue
        if not part.files:
            target = _unique_target(part_dir.with_suffix(".bin"))
            _copy_range(source, part.offset, part.size, target, tick, cancel)
            written += 1
            continue
        for item in part.files:
            target = _unique_target(part_dir / item.name)
            _copy_range(source, item.offset, item.size, target, tick, cancel)
            written += 1

    if progress:
        progress(100, "解包完成")
    return target_root, written


def export_switch_image(
    path: Path | str,
    target: Path | str,
    progress: ProgressCallback | None = None,
    cancel: CancelCheck | None = None,
) -> Path:
    """把镜像原样另存为指定文件名（例如 .xci），方便模拟器直接识别。"""
    source = Path(path)
    destination = Path(target)
    if source.resolve() == destination.resolve():
        return destination
    size = source.stat().st_size
    destination.parent.mkdir(parents=True, exist_ok=True)
    done = 0
    last_report = 0.0
    try:
        with source.open("rb") as src, destination.open("wb") as dst:
            while True:
                if cancel and cancel():
                    raise SwitchImageCancelled("已取消保存")
                chunk = src.read(_COPY_CHUNK)
                if not chunk:
                    break
                dst.write(chunk)
                done += len(chunk)
                now = time.monotonic()
                if progress and now - last_report >= 0.1:
                    last_report = now
                    progress(min(99, int(done * 100 / max(size, 1))), "正在保存镜像")
    except OSError as exc:
        raise SwitchImageError(f"保存镜像失败：{exc}") from exc
    if progress:
        progress(100, "保存完成")
    return destination
