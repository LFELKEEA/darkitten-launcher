from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)

from ..packs import human_size
from ..switch_image import SwitchImageError, inspect_switch_image
from ..workers import SwitchImageWorker
from .dialogs import StyledDialog
from .widgets import badge, colors


class SwitchImageDialog(StyledDialog):
    """识别 .sfxv / .xci / .nsp，并导出其中的原始文件。"""

    def __init__(self, main, path: Path | str) -> None:
        super().__init__(main, "Switch 游戏镜像", "package", colors()["accent"], width=620)
        self.main = main
        self.source = Path(path)
        self._task: DownloadTask | None = None
        self._busy = False
        self._result = ""

        self.info = None
        error = ""
        try:
            self.info = inspect_switch_image(self.source)
        except SwitchImageError as exc:
            error = str(exc)

        intro = QLabel(
            "这个文件是 Switch 的 XCI / NSP 镜像。启动器可以无损导出里面的分区文件，"
            "也可以原样另存为 .xci，交给支持 Switch 的模拟器直接加载。"
        )
        intro.setObjectName("DialogText")
        intro.setWordWrap(True)
        self.body.addWidget(intro)

        card = QFrame()
        card.setObjectName("SoftCard")
        card.setAttribute(Qt.WA_StyledBackground, True)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(14, 12, 14, 12)
        card_layout.setSpacing(7)

        head = QHBoxLayout()
        head.setSpacing(8)
        self.name_label = QLabel(self.source.stem)
        self.name_label.setStyleSheet("font-size: 15px; font-weight: 800;")
        self.badge = badge("Switch 镜像", "blue")
        head.addWidget(self.name_label)
        head.addWidget(self.badge)
        head.addStretch(1)
        card_layout.addLayout(head)

        self.meta_label = QLabel("")
        self.meta_label.setObjectName("Tiny")
        self.meta_label.setWordWrap(True)
        card_layout.addWidget(self.meta_label)

        self.parts_label = QLabel("")
        self.parts_label.setObjectName("Tiny")
        self.parts_label.setWordWrap(True)
        card_layout.addWidget(self.parts_label)

        self.note_label = QLabel(
            "说明：卡带镜像里的 .nca 内容受主机密钥保护，解包得到的是原始文件；"
            "要直接玩，请选「另存为 .xci」后交给模拟器。源文件不会被修改。"
        )
        self.note_label.setObjectName("Tiny")
        self.note_label.setWordWrap(True)
        card_layout.addWidget(self.note_label)
        self.body.addWidget(card)

        if error:
            self.meta_label.setText(error)
            self.badge.setText("无法识别")
            self.badge.setProperty("tone", "red")
        else:
            info = self.info
            self.badge.setText("XCI" if info.format == "xci" else "NSP")
            self.meta_label.setText(
                f"{info.format_label} · {len(info.partitions)} 个分区 · "
                f"{info.file_count} 个文件 · {human_size(info.total_bytes)}"
            )
            self.parts_label.setText(f"分区：{info.partition_label}")

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(False)
        self.body.addWidget(self.progress)
        self.status_label = QLabel("")
        self.status_label.setObjectName("Tiny")
        self.status_label.setWordWrap(True)
        self.status_label.setVisible(False)
        self.body.addWidget(self.status_label)

        self.extract_btn = self.add_button("导出到文件夹", "Primary", self._extract)
        self.save_btn = self.add_button("另存为 .xci", "Secondary", self._save_as)
        self.add_button("关闭", "Secondary", self.reject)
        if error:
            self.extract_btn.setEnabled(False)
            self.save_btn.setEnabled(False)

    # ------------------------------------------------------------------
    def _default_folder(self) -> Path:
        return self.source.parent / f"{self.source.stem}-解包"

    def _extract(self) -> None:
        if self._busy or self.info is None:
            return
        folder = QFileDialog.getExistingDirectory(
            self, "选择解包输出文件夹", str(self._default_folder())
        )
        if not folder:
            return
        self._start(SwitchImageWorker(self.source, Path(folder)), "解包 Switch 镜像")

    def _save_as(self) -> None:
        if self._busy:
            return
        target, _ = QFileDialog.getSaveFileName(
            self,
            "另存为 Switch 镜像",
            str(self.source.with_suffix(".xci")),
            "Switch 卡带镜像 (*.xci);;所有文件 (*)",
        )
        if not target:
            return
        self._start(
            SwitchImageWorker(self.source, Path(target), export_only=True),
            "保存 Switch 镜像",
        )

    def _start(self, worker: SwitchImageWorker, title: str) -> None:
        self._busy = True
        self._set_buttons(False)
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.status_label.setText("准备中…")
        self.status_label.setVisible(True)
        worker.progress.connect(self._on_progress)
        worker.finished.connect(self._on_finished)
        self._task = self.main.download_center.start_worker(
            worker,
            title=title,
            content_type="local-import",
            target=self.source.parent,
            cancel_cb=worker.cancel,
        )

    def _set_buttons(self, enabled: bool) -> None:
        self.extract_btn.setEnabled(enabled and self.info is not None)
        self.save_btn.setEnabled(enabled)

    def _on_progress(self, percent: int, message: str) -> None:
        self.progress.setValue(percent)
        self.status_label.setText(f"{message} {percent}%")

    def _on_finished(self, success: bool, message: str, location: str) -> None:
        self._busy = False
        self._set_buttons(True)
        self.progress.setVisible(not success)
        if success:
            self.progress.setValue(100)
            self._result = location
            self.status_label.setText(message)
            self.main.toast(message, "success")
        else:
            self.status_label.setText(message)
            self.main.toast(message, "error")

    @property
    def result_path(self) -> str:
        return self._result

    def reject(self) -> None:
        if self._busy and self._task is not None and self._task.cancel_cb:
            self._task.cancel_cb()
        super().reject()
