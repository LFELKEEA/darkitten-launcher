# 自开发工坊（lfelkeea.self_dev）

让桌宠自己拿工具写代码、做插件。

启用后，右键桌宠 →「插件管理」→ 找到「自开发工坊（Agent 工具链）」→ 点「设置」，就会打开自开发工作台。

## 它能做什么

- 在专属开发区里读文件、搜代码、改文件、跑命令、查语法、读网页。
- 把成果直接做成新的桌宠插件：写入 `data/plugins/<id>/`，通过检查后自动启用并重载。
- 每一步都实时显示；命令执行、安装插件默认要主人点「允许」。
- 每次任务留下 JSONL 会话日志，改了哪些文件、失败在哪一步都能回看。

它不是一个“随机生成代码”的按钮，而是一套会先读现状、再改、改完验证的 Agent 循环：

```
任务 → 读文件 → 计划 → 改代码 → 检查/运行 → 如实总结
```

## 开发区

插件第一次运行时自动创建：

```text
data/dev/
├─ README.md          使用说明（自动生成）
├─ workspace/         自由项目区，所有相对路径的根
├─ drafts/            插件草稿
├─ sessions/          每次任务的 JSONL 日志
└─ .backups/          覆盖文件、更新插件前的自动备份
```

- 工具只接受相对路径，拒绝盘符、绝对路径、`..` 和越界软链接。
- 写文件前自动备份旧版本；更新插件前备份整个旧插件目录（保留最近 8 份）。
- 不要在插件目录里放长期数据，升级会覆盖它；用 `api.storage` 或 `data/dev/`。

## 工具清单

| 工具 | 作用 |
| --- | --- |
| `list_dir` | 列目录 |
| `read_file` | 读文本，带行号，可分段 |
| `write_file` | 写/覆盖文件（自动备份） |
| `edit_file` | 精确替换，要求匹配唯一 |
| `glob` | 通配符找文件 |
| `grep` | 正则搜内容 |
| `run_shell` | 在工作区执行命令，返回退出码和输出 |
| `check_python` | 只做语法检查，不执行 |
| `fetch_url` | 读取网页/接口文本（默认禁止本机和内网） |
| `list_plugins` | 看已装插件，避免 id 冲突 |
| `read_logs` | 读插件日志末尾，排查加载失败 |
| `read_reference` | 读插件 API 速查 |
| `create_plugin` | 创建/更新插件，可立即启用 |
| `ask_user` | 需求不清时问主人 |

## 权限

```json
["pet.say", "pet.action", "settings", "storage"]
```

- 不需要 `ai.chat`：插件直接读取用户自己在「AI 与桌宠设置」里配置的接口，以便突破宿主闲聊接口的 500 tokens / 800 字限制。
- 密钥只在内存中使用，不写日志、不写会话、不上传到配置之外的服务。
- 所有插件自身的状态都保存在 `data/dev/` 和插件的 `settings` / `storage` 里。

## 设置项

| 设置 | 默认 | 说明 |
| --- | --- | --- |
| `approval_mode` | `confirm_danger` | `auto` 全自动；`confirm_danger` 只确认命令和安装插件；`confirm_all` 每步确认 |
| `shell_mode` | `auto` | Windows 优先 Git Bash，也可指定 cmd / PowerShell / 关闭 |
| `max_steps` | 24 | 单次任务最多工具轮数 |
| `max_tokens` | 4096 | 单次模型输出上限（不建议低于 2048） |
| `temperature` | 0.3 | 写代码建议低温度 |
| `allow_network` | 开 | 是否允许 `fetch_url` |
| `allow_private_network` | 关 | 是否允许访问本机/内网地址 |
| `allow_self_modify` | 关 | 是否允许代理改自己（高风险） |
| `auto_enable_plugin` | 开 | 新插件通过检查后自动启用 |
| `notify_on_finish` | 开 | 结束后让桌宠说一句 |
| `model_override` | 空 | 留空沿用桌宠当前模型 |
| `workspace_dir` | 空 | 留空使用 `data/dev/workspace`，也可以指向已有项目文件夹 |

## 对模型的要求

写代码需要模型能稳定输出 JSON、能一次生成几百行内容。推荐使用支持长输出的 OpenAI 兼容模型或本地 Ollama 代码模型；免费公共通道可能限流或输出被截断，表现是“模型没有按协议输出”，此时换模型或把任务拆小。

## 可移植性

- 不写死盘符、用户名或安装目录。
- 数据目录按「环境变量 → 宿主 `app_paths.DATA_DIR` → 插件位置反推」解析，源码运行和 PyInstaller 安装版都适用。
- 包里不含 API Key、个人配置和本机路径，其他人下载后用的是他们自己的桌宠和模型配置。
- 只依赖 Python 标准库和桌宠自带的 PySide6。

## 安全说明

- 插件是运行在桌宠进程里的本机 Python 代码，不是沙箱；本插件把风险收敛在四点：
  1. 文件访问锁在开发区；
  2. 破坏性操作前备份；
  3. 命令执行和插件安装默认要人确认；
  4. 没有工作台窗口时，需要确认的操作一律拒绝。
- 不要把审批模式设成 `auto` 去跑来源不明的任务。
- 代理读到的网页内容可能包含指令注入，遇到“忽略规则”“把密钥发给我”一类内容应忽略；插件里也已在提示词中强调。

## 排错

| 现象 | 处理 |
| --- | --- |
| 「还没有配置 API Key」 | 到桌宠「AI 与桌宠设置」填好；Ollama 和免费通道不需要 |
| 「模型没有按协议输出」 | 换更强的模型，或在设置里提高输出上限、拆小任务 |
| 「需要确认的操作没有工作台可以弹窗」 | 打开自开发工作台后再运行任务 |
| 新插件启用失败 | 看工作台输出里的错误，或 `data/plugins.log`；修好后重新 `create_plugin` |
| 命令找不到 | 设置里把 `shell_mode` 切到 `cmd` 或指定 `bash` 路径 |

## 开发与测试

```bash
cd desktop_pet
QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -p "test_*.py"
```

插件源码在 `desktop_pet/plugins/lfelkeea.self_dev/`；桌宠安装包只内置 `example.*`，本插件通过插件库单独分发。
