# QQ 桥接（SnowLuma）

把 QQ 私聊和群聊接进桌宠：人格卡、长期记忆、黑话库、白名单、按聊天习惯回复、表情和 QQ 空间。

插件本身不包含 SnowLuma，也不代替 QQ 登录。它通过 SnowLuma 的 OneBot 11 HTTP 接口收发消息。

## 需要什么

- Windows 桌面版 QQ（NT 架构）
- SnowLuma **2.2.1 或更高版本**，官方 Releases：
  [https://github.com/SnowLuma/SnowLuma/releases](https://github.com/SnowLuma/SnowLuma/releases)
- Windows 部署说明：
  [https://snowluma.github.io/zh/docs/guide/deploy/windows](https://snowluma.github.io/zh/docs/guide/deploy/windows)
- 桌宠 1.1.0 或更高版本

SnowLuma 的许可允许个人使用，但不允许把它的原生组件打包进第三方安装包。所以这里只给官方下载链接，不附带 SnowLuma 文件。

## 安装

1. 从插件库下载 `lfelkeea.qq_bridge-1.1.0.zip`。
2. 解压得到 `lfelkeea.qq_bridge` 文件夹，整个放进桌宠的插件目录。
   - 右键桌宠 →「插件管理」→「打开插件目录」，或手动放到 `data/plugins/`。
3. 回到插件管理，点「重新扫描」，勾选「QQ 桥接（SnowLuma）」启用。
4. 启用后桌宠会说一句「QQ 桥接已启动」，插件卡片上出现「设置」按钮。

> 可视化设置面板需要桌宠 **1.1.1 或更高版本**。旧版桌宠没有插件设置按钮，只能手动改 `data/config.json`。

## 配置 SnowLuma

1. 解压并运行 SnowLuma，按它的提示登录 QQ。
2. 打开 WebUI（默认 `http://127.0.0.1:5099`）。
3. 确认 OneBot HTTP 服务在 `127.0.0.1:3000` 上开启，记下它的 `accessToken`。
4. 新建一个 **HTTP 事件上报（httpClients）**，地址填：
   `http://127.0.0.1:8766/onebot`
   - `messageFormat` 选 `array`（插件也兼容 `string`）。
   - `reportSelfMessage` 保持关闭，避免机器人回复自己。
   - 如果给这个上报项设置了 `accessToken`，把同样的值填到插件的 `event_secret`；SnowLuma 会用 HMAC-SHA1 给请求签名。
   - 如果上报项不设令牌，插件的 `event_secret` 留空即可（服务只监听 `127.0.0.1`）。
5. 在 SnowLuma 里重新加载 OneBot 配置，或在 WebUI 里点保存。

对应的 `onebot_<QQ号>.json` 片段大致是这样（键名以你当前 SnowLuma 版本为准）：

```json
{
  "networks": {
    "httpServers": [
      {
        "name": "http-default",
        "host": "127.0.0.1",
        "port": 3000,
        "path": "/",
        "enableWebSocket": false,
        "accessToken": "HTTP_TOKEN",
        "messageFormat": "array",
        "reportSelfMessage": false
      }
    ],
    "httpClients": [
      {
        "name": "darkitten",
        "enabled": true,
        "url": "http://127.0.0.1:8766/onebot",
        "accessToken": "EVENT_SECRET",
        "timeoutMs": 5000,
        "messageFormat": "array",
        "reportSelfMessage": false
      }
    ]
  }
}
```

HTTP 服务和 WebSocket 服务的令牌是分别生成的，不要混用。插件只走 HTTP，不需要 WebSocket。

## 插件设置

桌宠 1.1.1 起，插件管理里点「设置」即可打开可视化面板：

| 页签 | 内容 |
| --- | --- |
| 连接 | SnowLuma 地址、accessToken、主人 QQ、本机监听端口和事件路径；可一键检测连接、复制事件地址 |
| 白名单 | 好友和群的放行名单增删，主人自动放行 |
| 人格 | 编辑人格卡、查看字数、恢复默认 |
| 记忆 | 查看/添加/删除长期记忆，手动触发整理 |
| 黑话 | 查看/添加/删除词条和出现次数 |
| 习惯 | 各会话的消息数、短句率、问句、表情和最后活跃时间 |
| QQ 空间 | 开关、可见范围、指定好友、发布、读取和删除说说 |
| 高级 | 机器人名字、触发方式、回复概率、字数、表情、记忆/黑话上限等 |
| 诊断 | 运行状态、测试发送、插件日志 |

点「保存并应用」后，连接类字段变化会自动重建客户端和事件监听；白名单、人格、记忆、黑话是点按钮立即生效。

设置最终保存在桌宠的 `data/config.json`：

`plugins.settings.lfelkeea.qq_bridge`

也可以手动编辑，改完在插件管理里点「重载」或重启桌宠。

| 设置 | 默认 | 说明 |
| --- | --- | --- |
| `snowluma_http` | `http://127.0.0.1:3000` | SnowLuma 的 OneBot HTTP 地址 |
| `access_token` | 空 | 对应 httpServers 的 `accessToken` |
| `owner_qq` | 空 | 主人 QQ，只有这个号能用指令 |
| `allow_private` | `[]` | 允许私聊的好友 QQ |
| `allow_groups` | `[]` | 允许回复的群号 |
| `http_host` | `127.0.0.1` | 事件服务监听地址，建议不要改成 `0.0.0.0` |
| `http_port` | `8766` | 事件服务端口；被占用时会自动往后试 5 个端口 |
| `event_path` | `/onebot` | 事件上报路径 |
| `event_secret` | 空 | 对应 httpClients 的 `accessToken`，用于校验 `X-Signature` |
| `bot_name` | `小猫` | 群聊里叫这个名字也会触发回复 |
| `command_prefix` | `/` | 指令前缀 |
| `group_trigger` | `at` | `at`：只有 @ 或叫名字才回；`all`：按 `reply_chance` 随机接话 |
| `reply_chance` | `0.15` | `group_trigger=all` 时的接话概率 |
| `max_replies_per_minute` | `6` | 每分钟最多回几条，防止刷屏 |
| `max_reply_chars` | `300` | 单条回复最大字数 |
| `auto_face` | `true` | 按习惯附带 QQ 表情 |
| `face_ids` | `["14","13","178","179"]` | 可随机使用的 QQ 表情 id |
| `face_probability` | `0.03` | 自动补表情的基础概率 |
| `sticker_paths` | `[]` | 表情包图片路径列表，路径要能被 SnowLuma 读到 |
| `sticker_probability` | `0.03` | 发一条回复时附表情包的概率 |
| `memory_enabled` | `true` | 开启长期记忆整理 |
| `memory_interval_minutes` | `30` | 两次自动整理的最小间隔 |
| `memory_min_batch` | `8` | 至少积累多少条消息才整理 |
| `memory_batch_size` | `40` | 每次最多整理多少条 |
| `memory_max_items` | `80` | 长期记忆上限 |
| `slang_enabled` | `true` | 开启黑话学习 |
| `slang_max_terms` | `200` | 黑话库上限 |
| `habit_enabled` | `true` | 统计对方的消息长度、问句、表情和活跃时间 |
| `local_echo` | `false` | 发出 QQ 消息时让桌宠也念一遍 |
| `announce` | `false` | 启动时额外说一句上线提示 |
| `qzone_enabled` | `false` | 是否允许发 QQ 空间 |
| `qzone_permission` | `friends` | `public` / `friends` / `some` / `private` / `hide` |
| `qzone_target_uins` | `[]` | 仅 `some` 权限时可见的 QQ 号 |

## 第一次使用

1. 在插件管理里点「设置」→「连接」，填好 SnowLuma 地址、accessToken 和主人 QQ，点「保存并应用」。
2. 点「检测连接」，看到「已连接：昵称（QQ号）」就说明打通了。
3. 到「白名单」页添加要回复的好友和群；主人 QQ 自动放行。
4. 在 QQ 里私聊机器人，发 `/status`，确认运行状态。
5. 私聊里直接说话即可；群里默认要 @ 机器人，或者消息以 `小猫` 开头。
6. 不想要某个对象时，在「白名单」页删掉，或发 `/allow del ...`。

白名单为空时插件不会主动回复任何人（主人私聊除外）。群聊仍要显式加进群白名单。

## 指令

默认前缀 `/`。只有 `owner_qq` 发的指令会被执行。

| 指令 | 作用 |
| --- | --- |
| `/help` | 显示指令 |
| `/status` | 查看连接、端口、白名单、记忆和黑话数量 |
| `/check` | 立刻测试 SnowLuma 连接 |
| `/persona` | 查看人格卡 |
| `/persona set 文字` | 修改人格卡 |
| `/persona reset` | 恢复插件自带的人格卡 |
| `/memory list` | 查看长期记忆 |
| `/memory add 内容` | 手动记一条 |
| `/memory del 关键词` | 删除匹配的记忆 |
| `/slang list` | 查看黑话库 |
| `/slang add 词=含义` | 手动加一条黑话 |
| `/slang del 词` | 删除黑话 |
| `/allow list` | 查看白名单 |
| `/allow add 123456` | 加好友 |
| `/allow add group:123456` | 加群 |
| `/allow del 123456` | 移出白名单 |
| `/say group:123456 内容` | 手动往白名单群发一条 |
| `/say private:123456 内容` | 手动往白名单好友发一条 |
| `/qzone 内容` | 发一条说说（需先开启） |
| `/qzone on` / `/qzone off` | 开关 QQ 空间发送 |
| `/qzone list` | 查看最近的说说 |
| `/qzone del tid` | 删除一条说说 |
| `/compact` | 立刻整理记忆和黑话 |

`/say` 和 `/qzone` 只接受白名单里的对象；`/qzone` 还要求 `qzone_enabled` 为 `true`。

## 人格卡、记忆和黑话

- **人格卡**：`data/plugins/.state/lfelkeea.qq_bridge/persona.md`，也可以直接用 `/persona set` 改。默认是一只说话简短的桌面小猫。
- **长期记忆**：插件把聊天记录攒到一定数量后，交给桌宠当前配置的 AI 整理成短句，存进 `memory.json`。只记稳定的事实、偏好、称呼和约定，不记寒暄。
- **黑话库**：整理时顺带收集有特殊含义的 2 到 8 字词，存进 `slang.json`；也可以手动 `/slang add`。
- **聊天习惯**：`habits.json` 记录每个会话的消息长度、问句比例、感叹号、省略号、表情数量和活跃小时。回复时会把摘要写进提示词，并按习惯决定要不要补表情。
- **最近对话**：`runtime.json` 只保留最近几条，用于接上下文；不会无限增长。

所有数据都在本机 `data/plugins/.state/lfelkeea.qq_bridge/`，不上传。删除这个目录等于清空人格卡、记忆、黑话和习惯。

## 表情和表情包

- QQ 表情用 `face_ids` 里的 id，例如 `14` 是微笑。模型偶尔也会自己输出 `[face:14]`，插件会解析成真正的表情段。
- 表情包用 `sticker_paths`，填本机图片路径，例如 `C:/Users/你/Pictures/sticker.png`。路径必须能被 SnowLuma 读取；如果发出去是裂图，先确认 SnowLuma 有权限访问该文件。
- 自动补表情的概率取 `face_probability` 和「对方历史表情比例的一半」中的较大值，最高 0.5，不会每条都带。

## QQ 空间

QQ 空间默认关闭。开启方式：

- 在设置里把 `qzone_enabled` 改成 `true`，或在 QQ 里发 `/qzone on`。
- 用 `qzone_permission` 控制可见范围，默认 `friends`。
- 只有白名单里的主人能触发，普通聊天不会自动发说说。

发说说依赖 SnowLuma 的 QZone 动作。如果报「QQ 空间操作失败」，先确认 SnowLuma 版本支持 `send_qzone_msg`，并查看 SnowLuma 日志；QQ 空间接口受腾讯风控影响，失败时不要连续重试。

## 安全边界

- 插件以你的 Windows 账户权限运行，能执行 Python 代码本身能做到的事。只启用你信得过的插件。
- 强烈建议保持 `http_host=127.0.0.1`，不要把事件端口暴露到局域网或公网。
- 白名单是唯一的外发闸门；不要把不认识的群加进去。
- 插件通过桌宠的 `api.chat` 调用 AI，读不到明文 API Key，也不会把 Key 写进日志或数据文件。
- 插件不会自动同意好友、不会自动进群、不会代替你发好友申请。

## 限制

- 只支持 OneBot 11 HTTP，不支持 WebSocket；这是为了不依赖额外 Python 包。
- SnowLuma 的原生 hook 与 QQ 版本绑定。QQ 自动升级后如果 hook 失效，先看 SnowLuma 的版本兼容说明。
- 一个 SnowLuma 实例对应一个 QQ 号；多账号需要分别配置。
- 群聊默认只响应 @ 或叫名字；想让它随机接话，把 `group_trigger` 改成 `all` 并调低 `reply_chance`。
- 记忆整理依赖 AI，AI 不可用时只会记录聊天，不会自动总结。
- 插件不包含 SnowLuma；请从官方 Releases 下载，并遵守它的许可。
