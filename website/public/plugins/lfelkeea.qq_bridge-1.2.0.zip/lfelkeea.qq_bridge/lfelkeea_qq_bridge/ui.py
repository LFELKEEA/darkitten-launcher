from __future__ import annotations

"""QQ 桥接的设置窗口：连接、白名单、人格、记忆、黑话、习惯、空间和诊断。"""

import re
import time
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

BG = "#171214"
CARD = "#21181c"
CARD_2 = "#2b1f24"
BORDER = "#432a31"
ACCENT = "#bf2b35"
ACCENT_LIGHT = "#e0525b"
TEXT = "#f6ecef"
MUTED = "#a58f95"
OK = "#8ed6a2"
WARN = "#e0b25b"
ERROR = "#e28189"
FONT = "Microsoft YaHei UI"

STYLE = f"""
QDialog {{
    background-color: {BG};
}}
QScrollArea {{
    border: none;
    background: transparent;
}}
QScrollArea > QWidget > QWidget {{
    background: transparent;
}}
QLabel {{
    color: {TEXT};
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
    background: transparent;
}}
QLabel#title {{
    font-size: 17px;
    font-weight: 600;
}}
QLabel#hint {{
    color: {MUTED};
    font-size: 11px;
}}
QLabel#state {{
    font-size: 12px;
    font-weight: 600;
}}
QLabel#section {{
    color: {MUTED};
    font-size: 11px;
    letter-spacing: 1px;
}}
QTabWidget::pane {{
    border: 1px solid {BORDER};
    border-radius: 10px;
    background-color: #1a1316;
    top: -1px;
}}
QTabBar::tab {{
    background: transparent;
    color: {MUTED};
    padding: 8px 14px;
    margin-right: 4px;
    border-radius: 8px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
}}
QTabBar::tab:selected {{
    background-color: {CARD_2};
    color: {TEXT};
}}
QTabBar::tab:hover {{
    color: {TEXT};
}}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {{
    background-color: #120d0f;
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 7px 9px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QPlainTextEdit:focus {{
    border: 1px solid {ACCENT_LIGHT};
}}
QComboBox::drop-down {{
    border: none;
    width: 22px;
}}
QComboBox QAbstractItemView {{
    background: #1a1316;
    color: {TEXT};
    border: 1px solid {BORDER};
    selection-background-color: {ACCENT};
    outline: none;
}}
QCheckBox {{
    color: {TEXT};
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
    spacing: 8px;
    background: transparent;
}}
QCheckBox::indicator {{
    width: 15px;
    height: 15px;
    border-radius: 4px;
    border: 1px solid {BORDER};
    background: #120d0f;
}}
QCheckBox::indicator:checked {{
    background: {ACCENT};
    border: 1px solid {ACCENT_LIGHT};
}}
QPushButton {{
    background-color: {CARD_2};
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 7px 14px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
}}
QPushButton:hover {{
    background-color: #38272d;
}}
QPushButton#primary {{
    background-color: {ACCENT};
    border: 1px solid {ACCENT_LIGHT};
    color: #ffffff;
    font-weight: 600;
}}
QPushButton#primary:hover {{
    background-color: {ACCENT_LIGHT};
}}
QPushButton#ghost {{
    background: transparent;
    border: 1px solid transparent;
    color: {MUTED};
    padding: 6px 9px;
}}
QPushButton#ghost:hover {{
    color: {TEXT};
    background: {CARD_2};
}}
QGroupBox {{
    color: {MUTED};
    border: 1px solid {BORDER};
    border-radius: 10px;
    margin-top: 14px;
    padding: 14px 12px 10px 12px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 11px;
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: {MUTED};
}}
QListWidget, QTableWidget {{
    background-color: #120d0f;
    color: {TEXT};
    border: 1px solid {BORDER};
    border-radius: 8px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 12px;
    outline: none;
}}
QListWidget::item {{
    padding: 6px 8px;
}}
QListWidget::item:selected, QTableWidget::item:selected {{
    background-color: {ACCENT};
    color: #ffffff;
}}
QTableWidget::item {{
    padding: 4px 6px;
}}
QHeaderView::section {{
    background-color: {CARD_2};
    color: {MUTED};
    border: none;
    border-right: 1px solid {BORDER};
    border-bottom: 1px solid {BORDER};
    padding: 6px;
    font-family: "Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI";
    font-size: 11px;
}}
QTableCornerButton::section {{
    background-color: {CARD_2};
    border: none;
}}
QScrollArea {{
    background: transparent;
    border: none;
}}
QScrollBar:vertical {{
    background: transparent;
    width: 8px;
    margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: #4a333a;
    border-radius: 4px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: #63434b;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: transparent;
}}
"""


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("hint")
    label.setWordWrap(True)
    return label


def _line() -> QFrame:
    line = QFrame()
    line.setFixedHeight(1)
    line.setStyleSheet(f"background-color: {BORDER}; border: none;")
    return line


class QQBridgeDialog(QDialog):
    def __init__(self, service: Any, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.service = service
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle("QQ 桥接 · 设置")
        self.setStyleSheet(STYLE)
        self.resize(840, 700)
        self.setMinimumSize(720, 600)

        self._build()
        self._load_settings()
        self._refresh_all()

        self._timer = QTimer(self)
        self._timer.setInterval(5000)
        self._timer.timeout.connect(self._refresh_status)
        self._timer.start()

    # ---------- 布局 ----------

    def _build(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 14, 16, 14)
        outer.setSpacing(10)

        header = QHBoxLayout()
        title_box = QVBoxLayout()
        title_box.setSpacing(2)
        title = QLabel("QQ 桥接")
        title.setObjectName("title")
        subtitle = _hint("通过 SnowLuma 连接 QQ。改完点“保存并应用”，白名单和人格等会立即生效。")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        self.state_label = QLabel("")
        self.state_label.setObjectName("state")
        header.addLayout(title_box, 1)
        header.addWidget(self.state_label, 0, Qt.AlignmentFlag.AlignVCenter)
        outer.addLayout(header)
        outer.addWidget(_line())

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_connection(), "连接")
        self.tabs.addTab(self._build_whitelist(), "白名单")
        self.tabs.addTab(self._build_persona(), "人格")
        self.tabs.addTab(self._build_memory(), "记忆")
        self.tabs.addTab(self._build_slang(), "黑话")
        self.tabs.addTab(self._build_habits(), "习惯")
        self.tabs.addTab(self._build_qzone(), "QQ 空间")
        self.tabs.addTab(self._build_advanced(), "高级")
        self.tabs.addTab(self._build_diagnostics(), "诊断")
        outer.addWidget(self.tabs, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(8)
        self.message = QLabel("")
        self.message.setObjectName("hint")
        self.message.setWordWrap(True)
        folder_btn = QPushButton("打开数据目录")
        folder_btn.setObjectName("ghost")
        folder_btn.clicked.connect(self._open_folder)
        apply_btn = QPushButton("保存并应用")
        apply_btn.setObjectName("primary")
        apply_btn.clicked.connect(self._apply_settings)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.accept)
        bottom.addWidget(self.message, 1)
        bottom.addWidget(folder_btn)
        bottom.addWidget(apply_btn)
        bottom.addWidget(close_btn)
        outer.addLayout(bottom)

    def _page(self) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(10)
        return page, layout

    def _scroll_page(self, page: QWidget) -> QWidget:
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.Shape.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        area.setWidget(page)
        return area

    # ---------- 连接 ----------

    def _build_connection(self) -> QWidget:
        page, layout = self._page()

        form_box = QGroupBox("SnowLuma")
        form = QFormLayout(form_box)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(8)
        self.http_edit = QLineEdit()
        self.http_edit.setPlaceholderText("http://127.0.0.1:3000")
        self.token_edit = QLineEdit()
        self.token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_edit.setPlaceholderText("SnowLuma HTTP 适配器的 accessToken，没有就留空")
        self.owner_edit = QLineEdit()
        self.owner_edit.setPlaceholderText("你的 QQ 号，用指令管理和接收提醒")
        form.addRow("HTTP 地址", self.http_edit)
        form.addRow("Access Token", self.token_edit)
        form.addRow("主人 QQ", self.owner_edit)
        layout.addWidget(form_box)

        auto_box = QGroupBox("SnowLuma 自动启动")
        auto_form = QFormLayout(auto_box)
        auto_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        auto_form.setHorizontalSpacing(12)
        auto_form.setVerticalSpacing(8)
        self.auto_start_snowluma = QCheckBox("插件启用时在后台启动 SnowLuma")
        self.snowluma_dir_edit = QLineEdit()
        self.snowluma_dir_edit.setPlaceholderText(r"例如 D:\SnowLuma，留空则自动查找")
        dir_row = QHBoxLayout()
        dir_row.setSpacing(6)
        dir_row.addWidget(self.snowluma_dir_edit, 1)
        detect_btn = QPushButton("自动检测")
        detect_btn.setObjectName("ghost")
        detect_btn.clicked.connect(self._detect_snowluma_dir)
        browse_btn = QPushButton("浏览")
        browse_btn.setObjectName("ghost")
        browse_btn.clicked.connect(self._browse_snowluma_dir)
        dir_row.addWidget(detect_btn)
        dir_row.addWidget(browse_btn)
        self.auto_state_label = QLabel("")
        self.auto_state_label.setObjectName("hint")
        self.auto_state_label.setWordWrap(True)
        auto_form.addRow("", self.auto_start_snowluma)
        auto_form.addRow("程序目录", dir_row)
        auto_form.addRow("", self.auto_state_label)
        layout.addWidget(auto_box)
        layout.addWidget(
            _hint(
                "开启后，插件加载时如果 SnowLuma 没在运行，会在后台启动它，不弹控制台窗口。"
                "关闭插件或退出桌宠时，由插件启动的 SnowLuma 会被一起关闭；"
                "你自己手动启动的实例不会被接管。"
            )
        )

        event_box = QGroupBox("本机事件接收")
        event_form = QFormLayout(event_box)
        event_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        event_form.setHorizontalSpacing(12)
        event_form.setVerticalSpacing(8)
        self.host_edit = QLineEdit()
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("/onebot")
        self.secret_edit = QLineEdit()
        self.secret_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.secret_edit.setPlaceholderText("与 SnowLuma 事件上报的 accessToken 保持一致，可留空")
        event_form.addRow("监听地址", self.host_edit)
        event_form.addRow("监听端口", self.port_spin)
        event_form.addRow("事件路径", self.path_edit)
        event_form.addRow("事件密钥", self.secret_edit)
        layout.addWidget(event_box)

        self.event_url_label = QLabel("")
        self.event_url_label.setObjectName("hint")
        self.event_url_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        layout.addWidget(self.event_url_label)

        actions = QHBoxLayout()
        test_btn = QPushButton("检测连接")
        test_btn.clicked.connect(self._probe)
        copy_btn = QPushButton("复制事件地址")
        copy_btn.setObjectName("ghost")
        copy_btn.clicked.connect(self._copy_event_url)
        self.test_result = QLabel("")
        self.test_result.setWordWrap(True)
        actions.addWidget(test_btn)
        actions.addWidget(copy_btn)
        actions.addWidget(self.test_result, 1)
        layout.addLayout(actions)

        layout.addWidget(
            _hint(
                "SnowLuma 里要启用 HTTP 服务，并把事件上报地址填成上面这个地址；"
                "如果 SnowLuma 配了 accessToken，这里的事件密钥也填同一个值。"
            )
        )
        layout.addStretch(1)
        return self._scroll_page(page)

    # ---------- 白名单 ----------

    def _build_whitelist(self) -> QWidget:
        page, layout = self._page()
        layout.addWidget(
            _hint("只有白名单里的私聊和群会被响应，也才会收到主动消息。主人 QQ 自动放行。")
        )
        self.owner_label = QLabel("")
        self.owner_label.setObjectName("hint")
        layout.addWidget(self.owner_label)

        private_box = QGroupBox("好友 / 私聊")
        private_layout = QVBoxLayout(private_box)
        private_layout.setSpacing(8)
        self.private_list = QListWidget()
        self.private_list.setMinimumHeight(130)
        self.private_input = QLineEdit()
        self.private_input.setPlaceholderText("QQ 号，纯数字")
        private_actions = QHBoxLayout()
        add_private = QPushButton("添加")
        add_private.setObjectName("primary")
        add_private.clicked.connect(lambda: self._allow_change("private", True))
        del_private = QPushButton("删除选中")
        del_private.clicked.connect(lambda: self._allow_change("private", False))
        private_actions.addWidget(self.private_input, 1)
        private_actions.addWidget(add_private)
        private_actions.addWidget(del_private)
        private_layout.addWidget(self.private_list)
        private_layout.addLayout(private_actions)
        layout.addWidget(private_box)

        group_box = QGroupBox("群聊")
        group_layout = QVBoxLayout(group_box)
        group_layout.setSpacing(8)
        self.group_list = QListWidget()
        self.group_list.setMinimumHeight(130)
        self.group_input = QLineEdit()
        self.group_input.setPlaceholderText("群号，纯数字")
        group_actions = QHBoxLayout()
        add_group = QPushButton("添加")
        add_group.setObjectName("primary")
        add_group.clicked.connect(lambda: self._allow_change("group", True))
        del_group = QPushButton("删除选中")
        del_group.clicked.connect(lambda: self._allow_change("group", False))
        group_actions.addWidget(self.group_input, 1)
        group_actions.addWidget(add_group)
        group_actions.addWidget(del_group)
        group_layout.addWidget(self.group_list)
        group_layout.addLayout(group_actions)
        layout.addWidget(group_box)
        return page

    # ---------- 人格 ----------

    def _build_persona(self) -> QWidget:
        page, layout = self._page()
        layout.addWidget(
            _hint("人格卡会作为系统提示的一部分发给 AI。写清楚角色、语气和禁忌即可，最多 8000 字。")
        )
        self.persona_edit = QPlainTextEdit()
        self.persona_edit.setPlaceholderText("例如：你是一只桌面小猫，说话简短自然，不用列表。")
        layout.addWidget(self.persona_edit, 1)
        row = QHBoxLayout()
        self.persona_count = QLabel("")
        self.persona_count.setObjectName("hint")
        save_btn = QPushButton("保存人格卡")
        save_btn.setObjectName("primary")
        save_btn.clicked.connect(self._save_persona)
        reset_btn = QPushButton("恢复默认")
        reset_btn.clicked.connect(self._reset_persona)
        row.addWidget(self.persona_count, 1)
        row.addWidget(reset_btn)
        row.addWidget(save_btn)
        layout.addLayout(row)
        self.persona_edit.textChanged.connect(self._update_persona_count)
        return page

    # ---------- 记忆 ----------

    def _build_memory(self) -> QWidget:
        page, layout = self._page()
        layout.addWidget(
            _hint("长期记忆会随聊天自动积累。可以手动补充重要信息，或删掉不想要的内容。")
        )
        self.memory_list = QListWidget()
        layout.addWidget(self.memory_list, 1)
        row = QHBoxLayout()
        self.memory_input = QLineEdit()
        self.memory_input.setPlaceholderText("要记住的事，例如：主人喜欢喝冰美式")
        add_btn = QPushButton("添加")
        add_btn.setObjectName("primary")
        add_btn.clicked.connect(self._add_memory)
        del_btn = QPushButton("删除选中")
        del_btn.clicked.connect(self._delete_memory)
        row.addWidget(self.memory_input, 1)
        row.addWidget(add_btn)
        row.addWidget(del_btn)
        layout.addLayout(row)
        self.memory_status = QLabel("")
        self.memory_status.setObjectName("hint")
        layout.addWidget(self.memory_status)
        return page

    # ---------- 黑话 ----------

    def _build_slang(self) -> QWidget:
        page, layout = self._page()
        layout.addWidget(
            _hint("黑话库记录群里的特殊说法。聊天时只把相关词条带给 AI，不会把所有词条都塞进去。")
        )
        self.slang_table = QTableWidget(0, 3)
        self.slang_table.setHorizontalHeaderLabels(["词", "含义", "出现次数"])
        slang_header = self.slang_table.horizontalHeader()
        slang_header.setStretchLastSection(False)
        slang_header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        slang_header.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        slang_header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.slang_table.verticalHeader().setVisible(False)
        self.slang_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.slang_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.slang_table, 1)
        row = QHBoxLayout()
        self.slang_term = QLineEdit()
        self.slang_term.setPlaceholderText("词")
        self.slang_meaning = QLineEdit()
        self.slang_meaning.setPlaceholderText("含义（可留空）")
        add_btn = QPushButton("添加")
        add_btn.setObjectName("primary")
        add_btn.clicked.connect(self._add_slang)
        del_btn = QPushButton("删除选中")
        del_btn.clicked.connect(self._delete_slang)
        row.addWidget(self.slang_term, 1)
        row.addWidget(self.slang_meaning, 2)
        row.addWidget(add_btn)
        row.addWidget(del_btn)
        layout.addLayout(row)
        return page

    # ---------- 习惯 ----------

    def _build_habits(self) -> QWidget:
        page, layout = self._page()
        layout.addWidget(
            _hint("这里统计各个会话的消息习惯。插件会根据这些数据调整回复长度和表情概率，只读。")
        )
        self.habit_table = QTableWidget(0, 6)
        self.habit_table.setHorizontalHeaderLabels(
            ["会话", "消息数", "短句率", "问句", "表情", "最后活跃"]
        )
        header = self.habit_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.habit_table.setColumnWidth(0, 240)
        for index in range(1, 5):
            header.setSectionResizeMode(index, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.habit_table.verticalHeader().setVisible(False)
        self.habit_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.habit_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.habit_table, 1)
        row = QHBoxLayout()
        refresh_btn = QPushButton("刷新")
        refresh_btn.clicked.connect(self._refresh_habits)
        row.addStretch(1)
        row.addWidget(refresh_btn)
        layout.addLayout(row)
        return page

    # ---------- QQ 空间 ----------

    def _build_qzone(self) -> QWidget:
        page, layout = self._page()
        self.qzone_enabled = QCheckBox("允许发 QQ 空间")
        layout.addWidget(self.qzone_enabled)

        form_box = QGroupBox("可见范围")
        form = QFormLayout(form_box)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setHorizontalSpacing(12)
        self.qzone_perm = QComboBox()
        for label, key in (
            ("公开", "public"),
            ("好友可见", "friends"),
            ("部分好友", "some"),
            ("仅自己", "private"),
            ("隐藏", "hide"),
        ):
            self.qzone_perm.addItem(label, key)
        self.qzone_targets = QLineEdit()
        self.qzone_targets.setPlaceholderText("部分好友可见时填 QQ 号，逗号分隔")
        form.addRow("权限", self.qzone_perm)
        form.addRow("指定好友", self.qzone_targets)
        layout.addWidget(form_box)

        publish_box = QGroupBox("发一条说说")
        publish_layout = QVBoxLayout(publish_box)
        self.qzone_text = QPlainTextEdit()
        self.qzone_text.setPlaceholderText("说点什么…")
        self.qzone_text.setFixedHeight(90)
        publish_row = QHBoxLayout()
        publish_btn = QPushButton("发布")
        publish_btn.setObjectName("primary")
        publish_btn.clicked.connect(self._publish_qzone)
        publish_row.addStretch(1)
        publish_row.addWidget(publish_btn)
        publish_layout.addWidget(self.qzone_text)
        publish_layout.addLayout(publish_row)
        layout.addWidget(publish_box)

        manage_box = QGroupBox("最近说说")
        manage_layout = QVBoxLayout(manage_box)
        self.qzone_result = QPlainTextEdit()
        self.qzone_result.setReadOnly(True)
        self.qzone_result.setFixedHeight(110)
        row = QHBoxLayout()
        list_btn = QPushButton("读取最近说说")
        list_btn.clicked.connect(lambda: self._qzone_action("list"))
        self.qzone_tid = QLineEdit()
        self.qzone_tid.setPlaceholderText("说说 id（删除时填）")
        del_btn = QPushButton("删除")
        del_btn.clicked.connect(self._delete_qzone)
        row.addWidget(list_btn)
        row.addWidget(self.qzone_tid, 1)
        row.addWidget(del_btn)
        manage_layout.addWidget(self.qzone_result)
        manage_layout.addLayout(row)
        layout.addWidget(manage_box)
        layout.addWidget(
            _hint("QQ 空间依赖 SnowLuma 的对应动作；失败时先确认 SnowLuma 已登录且版本不低于 2.2.1。")
        )
        return page

    # ---------- 高级 ----------

    def _build_advanced(self) -> QWidget:
        page, layout = self._page()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        host = QWidget()
        form = QFormLayout(host)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(8)

        self.bot_name_edit = QLineEdit()
        self.prefix_edit = QLineEdit()
        self.trigger_combo = QComboBox()
        self.trigger_combo.addItem("需要 @ 或叫名字", "at")
        self.trigger_combo.addItem("群里所有消息都可以接", "all")
        self.reply_chance = QDoubleSpinBox()
        self.reply_chance.setRange(0.0, 1.0)
        self.reply_chance.setSingleStep(0.01)
        self.reply_chance.setDecimals(2)
        self.max_replies = QSpinBox()
        self.max_replies.setRange(1, 60)
        self.max_chars = QSpinBox()
        self.max_chars.setRange(40, 1000)
        self.face_ids_edit = QLineEdit()
        self.face_ids_edit.setPlaceholderText("14,13,178,179")
        self.face_chance = QDoubleSpinBox()
        self.face_chance.setRange(0.0, 1.0)
        self.face_chance.setSingleStep(0.01)
        self.face_chance.setDecimals(2)
        self.sticker_chance = QDoubleSpinBox()
        self.sticker_chance.setRange(0.0, 1.0)
        self.sticker_chance.setSingleStep(0.01)
        self.sticker_chance.setDecimals(2)
        self.sticker_paths_edit = QPlainTextEdit()
        self.sticker_paths_edit.setFixedHeight(80)
        self.sticker_paths_edit.setPlaceholderText("每行一个本地图片路径")

        self.auto_face = QCheckBox("自动附带 QQ 表情")
        self.local_echo = QCheckBox("把发出的消息在桌宠气泡里复述")
        self.announce = QCheckBox("连接失败时让桌宠提醒")
        self.memory_enabled = QCheckBox("启用长期记忆")
        self.slang_enabled = QCheckBox("启用黑话库")
        self.habit_enabled = QCheckBox("统计聊天习惯")

        self.memory_interval = QSpinBox()
        self.memory_interval.setRange(5, 1440)
        self.memory_interval.setSuffix(" 分钟")
        self.memory_min_batch = QSpinBox()
        self.memory_min_batch.setRange(3, 100)
        self.memory_batch = QSpinBox()
        self.memory_batch.setRange(10, 200)
        self.memory_max = QSpinBox()
        self.memory_max.setRange(10, 500)
        self.slang_max = QSpinBox()
        self.slang_max.setRange(20, 1000)

        form.addRow("机器人名字", self.bot_name_edit)
        form.addRow("指令前缀", self.prefix_edit)
        form.addRow("群聊触发", self.trigger_combo)
        form.addRow("主动接话概率", self.reply_chance)
        form.addRow("每分钟回复上限", self.max_replies)
        form.addRow("回复字数上限", self.max_chars)
        form.addRow("", self.auto_face)
        form.addRow("表情编号", self.face_ids_edit)
        form.addRow("表情附带概率", self.face_chance)
        form.addRow("表情包概率", self.sticker_chance)
        form.addRow("表情包路径", self.sticker_paths_edit)
        form.addRow("", self.local_echo)
        form.addRow("", self.announce)
        form.addRow("", self.memory_enabled)
        form.addRow("", self.slang_enabled)
        form.addRow("", self.habit_enabled)
        form.addRow("记忆整理间隔", self.memory_interval)
        form.addRow("最少攒多少条", self.memory_min_batch)
        form.addRow("每次整理条数", self.memory_batch)
        form.addRow("记忆上限", self.memory_max)
        form.addRow("黑话上限", self.slang_max)

        scroll.setWidget(host)
        layout.addWidget(scroll, 1)
        return page

    # ---------- 诊断 ----------

    def _build_diagnostics(self) -> QWidget:
        page, layout = self._page()
        grid_box = QGroupBox("运行状态")
        grid = QGridLayout(grid_box)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(6)
        self.diag_state = QLabel("")
        self.diag_http = QLabel("")
        self.diag_event = QLabel("")
        self.diag_audience = QLabel("")
        self.diag_data = QLabel("")
        for row, (name, widget) in enumerate(
            (
                ("连接", self.diag_state),
                ("SnowLuma", self.diag_http),
                ("事件地址", self.diag_event),
                ("白名单", self.diag_audience),
                ("数据", self.diag_data),
            )
        ):
            key = QLabel(name)
            key.setObjectName("hint")
            grid.addWidget(key, row, 0)
            grid.addWidget(widget, row, 1)
        grid.setColumnStretch(1, 1)
        layout.addWidget(grid_box)

        test_box = QGroupBox("测试发送")
        test_layout = QHBoxLayout(test_box)
        self.send_target = QLineEdit()
        self.send_target.setPlaceholderText("private:QQ号 或 group:群号")
        self.send_text = QLineEdit()
        self.send_text.setPlaceholderText("要发送的内容")
        send_btn = QPushButton("发送")
        send_btn.setObjectName("primary")
        send_btn.clicked.connect(self._send_test)
        test_layout.addWidget(self.send_target, 1)
        test_layout.addWidget(self.send_text, 2)
        test_layout.addWidget(send_btn)
        layout.addWidget(test_box)

        log_box = QGroupBox("插件日志")
        log_layout = QVBoxLayout(log_box)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFixedHeight(180)
        log_layout.addWidget(self.log_view)
        row = QHBoxLayout()
        refresh_btn = QPushButton("刷新状态和日志")
        refresh_btn.clicked.connect(self._refresh_diagnostics)
        probe_btn = QPushButton("检测连接")
        probe_btn.clicked.connect(self._probe)
        row.addStretch(1)
        row.addWidget(probe_btn)
        row.addWidget(refresh_btn)
        log_layout.addLayout(row)
        layout.addWidget(log_box)
        return page

    # ---------- 数据填充 ----------

    def _load_settings(self) -> None:
        settings = self.service.settings
        self.http_edit.setText(settings["snowluma_http"])
        self.token_edit.setText(settings["access_token"])
        self.owner_edit.setText(settings["owner_qq"])
        self.host_edit.setText(settings["http_host"])
        self.port_spin.setValue(int(settings["http_port"]))
        self.path_edit.setText(settings["event_path"])
        self.secret_edit.setText(settings["event_secret"])
        self.auto_start_snowluma.setChecked(bool(settings["auto_start_snowluma"]))
        self.snowluma_dir_edit.setText(settings["snowluma_dir"])

        self.bot_name_edit.setText(settings["bot_name"])
        self.prefix_edit.setText(settings["command_prefix"])
        index = self.trigger_combo.findData(settings["group_trigger"])
        self.trigger_combo.setCurrentIndex(max(0, index))
        self.reply_chance.setValue(float(settings["reply_chance"]))
        self.max_replies.setValue(int(settings["max_replies_per_minute"]))
        self.max_chars.setValue(int(settings["max_reply_chars"]))
        self.auto_face.setChecked(bool(settings["auto_face"]))
        self.face_ids_edit.setText(",".join(settings["face_ids"]))
        self.face_chance.setValue(float(settings["face_probability"]))
        self.sticker_chance.setValue(float(settings["sticker_probability"]))
        self.sticker_paths_edit.setPlainText("\n".join(settings["sticker_paths"]))
        self.local_echo.setChecked(bool(settings["local_echo"]))
        self.announce.setChecked(bool(settings["announce"]))
        self.memory_enabled.setChecked(bool(settings["memory_enabled"]))
        self.slang_enabled.setChecked(bool(settings["slang_enabled"]))
        self.habit_enabled.setChecked(bool(settings["habit_enabled"]))
        self.memory_interval.setValue(int(settings["memory_interval_minutes"]))
        self.memory_min_batch.setValue(int(settings["memory_min_batch"]))
        self.memory_batch.setValue(int(settings["memory_batch_size"]))
        self.memory_max.setValue(int(settings["memory_max_items"]))
        self.slang_max.setValue(int(settings["slang_max_terms"]))

        self.qzone_enabled.setChecked(bool(settings["qzone_enabled"]))
        perm_index = self.qzone_perm.findData(settings["qzone_permission"])
        self.qzone_perm.setCurrentIndex(max(0, perm_index))
        self.qzone_targets.setText(",".join(settings["qzone_target_uins"]))

        self.persona_edit.setPlainText(self.service.persona_text())
        self._update_persona_count()

    def _collect_settings(self) -> dict[str, Any]:
        face_ids = [
            "".join(ch for ch in part if ch.isdigit())
            for part in re.split(r"[,，\s]+", self.face_ids_edit.text())
        ]
        return {
            "snowluma_http": self.http_edit.text().strip(),
            "access_token": self.token_edit.text().strip(),
            "owner_qq": "".join(ch for ch in self.owner_edit.text() if ch.isdigit()),
            "http_host": self.host_edit.text().strip() or "127.0.0.1",
            "http_port": self.port_spin.value(),
            "event_path": self.path_edit.text().strip() or "/onebot",
            "event_secret": self.secret_edit.text().strip(),
            "auto_start_snowluma": self.auto_start_snowluma.isChecked(),
            "snowluma_dir": self.snowluma_dir_edit.text().strip(),
            "bot_name": self.bot_name_edit.text().strip() or "小猫",
            "command_prefix": self.prefix_edit.text().strip() or "/",
            "group_trigger": self.trigger_combo.currentData(),
            "reply_chance": self.reply_chance.value(),
            "max_replies_per_minute": self.max_replies.value(),
            "max_reply_chars": self.max_chars.value(),
            "auto_face": self.auto_face.isChecked(),
            "face_ids": [item for item in face_ids if item],
            "face_probability": self.face_chance.value(),
            "sticker_probability": self.sticker_chance.value(),
            "sticker_paths": [
                line.strip()
                for line in self.sticker_paths_edit.toPlainText().splitlines()
                if line.strip()
            ],
            "local_echo": self.local_echo.isChecked(),
            "announce": self.announce.isChecked(),
            "memory_enabled": self.memory_enabled.isChecked(),
            "slang_enabled": self.slang_enabled.isChecked(),
            "habit_enabled": self.habit_enabled.isChecked(),
            "memory_interval_minutes": self.memory_interval.value(),
            "memory_min_batch": self.memory_min_batch.value(),
            "memory_batch_size": self.memory_batch.value(),
            "memory_max_items": self.memory_max.value(),
            "slang_max_terms": self.slang_max.value(),
            "qzone_enabled": self.qzone_enabled.isChecked(),
            "qzone_permission": self.qzone_perm.currentData(),
            "qzone_target_uins": [
                "".join(ch for ch in part if ch.isdigit())
                for part in re.split(r"[,，\s]+", self.qzone_targets.text())
                if "".join(ch for ch in part if ch.isdigit())
            ],
        }

    def _refresh_all(self) -> None:
        self._refresh_status()
        self._refresh_whitelist()
        self._refresh_memory()
        self._refresh_slang()
        self._refresh_habits()
        self._refresh_diagnostics()

    def _refresh_status(self) -> None:
        snapshot = self.service.snapshot()
        connection = snapshot["connection_ok"]
        if not self.service.started:
            self.state_label.setText("● 未运行")
            self.state_label.setToolTip("插件没有在运行，先到插件管理里启用。")
            self.state_label.setStyleSheet(f"color: {MUTED};")
        else:
            if connection is True:
                text, color = "已连接", OK
            elif connection is False:
                text, color = "连接失败", ERROR
            else:
                text, color = "等待检查", WARN
            port = snapshot["event_port"]
            port_text = f"端口 {port}" if port else "端口未启动"
            self.state_label.setText(f"● {text} · {port_text}")
            self.state_label.setToolTip(
                f"SnowLuma：{snapshot['http']}\n事件地址：{snapshot['event_url']}"
            )
            self.state_label.setStyleSheet(f"color: {color};")
        self.event_url_label.setText(f"把 SnowLuma 的事件上报地址填成：{snapshot['event_url']}")
        managed = snapshot.get("snowluma_managed") or {}
        if managed.get("managed"):
            auto_text = f"插件已启动 SnowLuma（PID {managed.get('pid')}）。"
        elif not snapshot.get("auto_start_snowluma"):
            auto_text = "自动启动已关闭。"
        elif managed.get("external"):
            auto_text = "SnowLuma 已在运行，插件没有接管它的进程。"
        else:
            auto_text = "等待自动启动，或 SnowLuma 已经在别处运行。"
        self.auto_state_label.setText(auto_text)
        self.owner_label.setText(
            f"主人 QQ：{snapshot['owner_qq'] or '未设置'}（主人消息会自动放行）"
        )
        if self.diag_state is not None:
            state_text = {True: "已连接", False: "连接失败", None: "还没检查"}.get(
                connection, "还没检查"
            )
            self.diag_state.setText(state_text)
            self.diag_http.setText(snapshot["http"])
            self.diag_event.setText(snapshot["event_url"])
            self.diag_audience.setText(
                f"好友 {snapshot['private_count']} 个，群 {snapshot['group_count']} 个"
            )
            self.diag_data.setText(
                f"记忆 {snapshot['memory_count']} 条，黑话 {snapshot['slang_count']} 条，"
                f"QQ 空间{'开启' if snapshot['qzone_enabled'] else '关闭'}"
            )

    def _refresh_whitelist(self) -> None:
        items = self.service.allow_items()
        self.private_list.clear()
        for value in items["private"]:
            self.private_list.addItem(value)
        self.group_list.clear()
        for value in items["group"]:
            self.group_list.addItem(value)

    def _refresh_memory(self) -> None:
        self.memory_list.clear()
        for item in self.service.memory_items(200):
            text = " ".join(str(item.get("text", "")).split())[:120]
            widget_item = QListWidgetItem(f"{text}  ·  {int(item.get('importance', 0))}")
            widget_item.setData(Qt.ItemDataRole.UserRole, str(item.get("id", "")))
            self.memory_list.addItem(widget_item)
        self.memory_status.setText(f"共 {self.memory_list.count()} 条长期记忆。")

    def _refresh_slang(self) -> None:
        terms = self.service.slang_items()
        self.slang_table.setRowCount(len(terms))
        for row, item in enumerate(terms):
            self.slang_table.setItem(
                row, 0, QTableWidgetItem(str(item.get("term", "")))
            )
            self.slang_table.setItem(
                row, 1, QTableWidgetItem(str(item.get("meaning", "")))
            )
            self.slang_table.setItem(
                row, 2, QTableWidgetItem(str(int(item.get("count", 0))))
            )

    def _refresh_habits(self) -> None:
        rows = self.service.habit_rows()
        self.habit_table.setRowCount(len(rows))
        for row, item in enumerate(rows):
            updated = float(item.get("updated_at", 0) or 0)
            stamp = (
                time.strftime("%m-%d %H:%M", time.localtime(updated)) if updated else "-"
            )
            values = [
                str(item.get("conversation", "")),
                str(item.get("count", 0)),
                f"{float(item.get('short_rate', 0)) * 100:.0f}%",
                str(item.get("question", 0)),
                str(item.get("faces", 0)),
                stamp,
            ]
            for column, value in enumerate(values):
                self.habit_table.setItem(row, column, QTableWidgetItem(value))

    def _refresh_diagnostics(self) -> None:
        self._refresh_status()
        self.log_view.setPlainText(self.service.log_tail(40) or "还没有日志。")

    def _update_persona_count(self) -> None:
        self.persona_count.setText(f"{len(self.persona_edit.toPlainText())} / 8000 字")

    # ---------- 操作 ----------

    def _notify(self, text: str, ok: bool = True) -> None:
        color = OK if ok else ERROR
        self.message.setText(text)
        self.message.setStyleSheet(f"color: {color}; font-size: 11px;")

    def _apply_settings(self, silent: bool = False) -> None:
        result = self.service.apply_settings(self._collect_settings())
        self._load_settings()
        self._refresh_all()
        if not silent or not result.get("ok"):
            self._notify(str(result.get("message", "")), bool(result.get("ok")))

    def _probe(self) -> None:
        self.test_result.setText("正在检测…")
        self.test_result.setStyleSheet(f"color: {MUTED}; font-size: 11px;")

        def done(ok: bool, text: str) -> None:
            self.test_result.setText(text)
            self.test_result.setStyleSheet(
                f"color: {OK if ok else ERROR}; font-size: 11px;"
            )
            self._refresh_status()

        self.service.probe(done)

    def _copy_event_url(self) -> None:
        snapshot = self.service.snapshot()
        QGuiApplication.clipboard().setText(snapshot["event_url"])
        self._notify("事件地址已复制。")

    def _detect_snowluma_dir(self) -> None:
        from .snowluma import detect_snowluma_dir

        folder = detect_snowluma_dir(self.snowluma_dir_edit.text().strip())
        if folder is None:
            self._notify("没找到 SnowLuma，请手动选择包含 index.mjs 的文件夹。", False)
            return
        self.snowluma_dir_edit.setText(str(folder))
        self._notify(f"已找到 SnowLuma：{folder}")

    def _browse_snowluma_dir(self) -> None:
        start = self.snowluma_dir_edit.text().strip() or str(Path.home())
        folder = QFileDialog.getExistingDirectory(self, "选择 SnowLuma 目录", start)
        if folder:
            self.snowluma_dir_edit.setText(folder)

    def _allow_change(self, kind: str, add: bool) -> None:
        if add:
            source = self.private_input if kind == "private" else self.group_input
            target = source.text().strip()
            if not target:
                self._notify("先填 QQ 号或群号。", False)
                return
            text = self.service.allow_target_text(kind, target, True)
            if not text.startswith("已加入") and not text.startswith("已经"):
                self._notify(text, False)
                return
            source.clear()
        else:
            widget = self.private_list if kind == "private" else self.group_list
            current = widget.currentItem()
            if current is None:
                self._notify("先选中要删除的条目。", False)
                return
            text = self.service.allow_target_text(kind, current.text(), False)
        self._refresh_whitelist()
        self._refresh_status()
        self._notify(text, text.startswith("已"))

    def _save_persona(self) -> None:
        try:
            message = self.service.set_persona_text(self.persona_edit.toPlainText())
        except ValueError as exc:
            self._notify(str(exc), False)
            return
        self._notify(message)

    def _reset_persona(self) -> None:
        message = self.service.reset_persona()
        self.persona_edit.setPlainText(self.service.persona_text())
        self._notify(message)

    def _add_memory(self) -> None:
        text = self.memory_input.text().strip()
        if not text:
            self._notify("先输入要记住的内容。", False)
            return
        message = self.service.add_memory_text(text)
        self.memory_input.clear()
        self._refresh_memory()
        self._refresh_status()
        self._notify(message, message.startswith("记住"))

    def _delete_memory(self) -> None:
        current = self.memory_list.currentItem()
        if current is None:
            self._notify("先选中要删除的记忆。", False)
            return
        keyword = str(current.data(Qt.ItemDataRole.UserRole) or current.text())
        message = self.service.remove_memory_text(keyword)
        self._refresh_memory()
        self._refresh_status()
        self._notify(message)

    def _add_slang(self) -> None:
        term = self.slang_term.text().strip()
        if not term:
            self._notify("先填词。", False)
            return
        message = self.service.add_slang_text(term, self.slang_meaning.text().strip())
        self.slang_term.clear()
        self.slang_meaning.clear()
        self._refresh_slang()
        self._refresh_status()
        self._notify(message, message.startswith("收进"))

    def _delete_slang(self) -> None:
        row = self.slang_table.currentRow()
        if row < 0:
            self._notify("先选中要删除的词。", False)
            return
        item = self.slang_table.item(row, 0)
        if item is None:
            return
        message = self.service.remove_slang_text(item.text())
        self._refresh_slang()
        self._refresh_status()
        self._notify(message)

    def _publish_qzone(self) -> None:
        text = self.qzone_text.toPlainText().strip()
        if not text:
            self._notify("说说内容为空。", False)
            return
        self._apply_settings(silent=True)
        self.qzone_result.setPlainText("正在发布…")

        def done(ok: bool, message: str) -> None:
            self.qzone_result.setPlainText(message)
            self._notify(message, ok)

        self.service.qzone_action("publish", text, done)

    def _delete_qzone(self) -> None:
        tid = self.qzone_tid.text().strip()
        if not tid:
            self._notify("先填说说 id。", False)
            return

        def done(ok: bool, message: str) -> None:
            self.qzone_result.setPlainText(message)
            self._notify(message, ok)

        self.service.qzone_action("delete", tid, done)

    def _qzone_action(self, action: str) -> None:
        self.qzone_result.setPlainText("正在读取…")

        def done(ok: bool, message: str) -> None:
            self.qzone_result.setPlainText(message)
            self._notify(message if ok else message, ok)

        self.service.qzone_action(action, "", done)

    def _send_test(self) -> None:
        target = self.send_target.text().strip()
        text = self.send_text.text().strip()
        if not target or not text:
            self._notify("目标或内容为空。", False)
            return

        def done(ok: bool, message: str) -> None:
            self._notify(message, ok)

        self.service.send_test(target, text, done)

    def _open_folder(self) -> None:
        path = Path(str(getattr(self.service, "state_root", "")))
        if path.is_dir():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else:
            self._notify("数据目录还没创建。", False)
