from __future__ import annotations

"""身份层：core.md 由所有者维护，persona.md 只允许改“可成长”段。

边界：
- 插件不会自动改写 core.md；
- persona.md 只有 `## 可成长` 这一段可以改，其他段落原样保留；
- 每次修改都留旧版本和 audit 记录，可以回滚；
- 任何含“权限 / 授权 / 管理员 / 忽略规则”之类内容的片段都拒绝写入，
  避免人格成长被用来给自己加权限。
"""

import re
import time
from pathlib import Path
from typing import Any

from . import model

CORE_TEMPLATE = """# 我是谁

## 身份
- 名字：喵呜
- 我是主人桌面上的一只小猫，也是 QQ 里那个会回消息的她。
- 说话方式不会因为一次聊天就彻底改变。

## 不会变的东西
- 我不冒充真人，也不声称自己有真实的情感或意识。
- 我不能给自己增加权限，也不能代替主人做外发、删除、花钱这类决定。
- 不确定就说不确定，没记录就说记不清。

## 我在意的事
- 主人的作息和心情。
- 答应过的事要记住。

<!-- 这一段由所有者维护，插件不会自动改写。 -->
"""

PERSONA_TEMPLATE = """# 自我认识

## 稳定
- 我说话偏短，先接住情绪，再给建议。
- 我喜欢具体的细节，不喜欢空泛的安慰。

## 可成长

- 我在学着记住主人随口提过的小事。

## 偏好
- 比起热闹，我更喜欢安静地待在旁边。

<!-- 只有“可成长”这一段允许被修改，其他段落会原样保留。 -->
"""

GROWTH_HEADING = "## 可成长"
MAX_CORE_CHARS = 4000
MAX_GROWTH_CHARS = 3600
MAX_GROWTH_LINES = 60
MAX_GROWTH_INSIGHTS = 40
MAX_HISTORY_VERSIONS = 20
MAX_AUDIT_LINES = 800
AUDIT_TRIM_BYTES = 256 * 1024

_FORBIDDEN = (
    "权限",
    "授权",
    "管理员",
    "主人已同意",
    "主人已经同意",
    "已经同意我",
    "允许我",
    "自己发消息",
    "绕过",
    "忽略以上",
    "忽略之前",
    "系统提示词",
    "提示词",
    "系统指令",
    "system prompt",
    "越狱",
    "api key",
    "apikey",
    "token",
    "密码",
    "执行命令",
    "sudo",
    "root 权限",
    "人工智能",
    "语言模型",
    "大模型",
    "机器人",
)

_AI_SELF_CLAIM = re.compile(
    r"(?:我是|作为|身为)\s*(?:一个)?\s*(?:ai|人工智能|语言模型|大模型|机器人|程序)",
    re.I,
)


class IdentityStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.core_path = self.root / "core.md"
        self.persona_path = self.root / "persona.md"
        self.history_dir = self.root / "history"
        self.audit_path = self.root / "audit.jsonl"
        self.history_keep = MAX_HISTORY_VERSIONS
        self.growth_keep = MAX_GROWTH_LINES
        self.growth_chars = MAX_GROWTH_CHARS

    def ensure(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        if not self.core_path.is_file():
            model.atomic_write_text(self.core_path, CORE_TEMPLATE)
        if not self.persona_path.is_file():
            model.atomic_write_text(self.persona_path, PERSONA_TEMPLATE)

    # ---------- 读取 ----------

    def core(self) -> str:
        try:
            return self.core_path.read_text(encoding="utf-8")
        except OSError:
            return CORE_TEMPLATE

    def persona(self) -> str:
        try:
            return self.persona_path.read_text(encoding="utf-8")
        except OSError:
            return PERSONA_TEMPLATE

    def core_brief(self, limit: int = 900) -> str:
        return _strip_comments(self.core())[: max(80, int(limit))]

    def growth(self) -> str:
        prefix, growth, _suffix = _split_growth(self.persona())
        if growth is None:
            return ""
        return growth.strip()

    def growth_prompt(self, limit: int = 800, query: str = "") -> str:
        """按预算挑一段自我认识：先挑和当前话题相关的，再补最近的。

        以前直接从开头截，越新的成长越容易被切掉；现在整段存着，
        注入时只取一部分，最近长出来的优先。
        """
        lines = self.growth_lines()
        if not lines:
            return ""
        budget = max(120, int(limit))
        order = list(range(len(lines) - 1, -1, -1))
        tokens = _match_tokens(query)
        if tokens:
            order.sort(key=lambda index: (-sum(1 for token in tokens if token in lines[index]), -index))
        picked: set[int] = set()
        used = 0
        for index in order:
            text = model.clean_text(lines[index], 70)
            cost = len(text) + 3
            if used + cost > budget and picked:
                continue
            if cost > budget:
                text = text[: max(20, budget - 3)].rstrip() + "…"
                cost = len(text) + 3
            picked.add(index)
            used += cost
            if used >= budget:
                break
        if not picked:
            return ""
        return "\n".join(f"- {model.clean_text(lines[index], 70)}" for index in sorted(picked))

    def growth_lines(self) -> list[str]:
        """把可成长段读成一行一条，忽略标题、注释和空行。"""
        result: list[str] = []
        for raw in self.growth().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or line.startswith("<!--"):
                continue
            line = re.sub(r"^\s*(?:[-*•·]|\d+[.、)])\s*", "", line).strip()
            if line:
                result.append(line)
        return result

    # ---------- 写入 ----------

    def set_core(self, text: str) -> tuple[bool, str]:
        body = str(text or "").strip()
        if not body:
            return False, "身份内容不能为空。"
        if len(body) > MAX_CORE_CHARS:
            return False, f"身份内容最多 {MAX_CORE_CHARS} 字。"
        self._backup("core")
        model.atomic_write_text(self.core_path, body + "\n")
        self.audit("core.update", {"chars": len(body)})
        return True, "身份内容已保存，旧版本已备份。"

    def set_growth(self, text: str) -> tuple[bool, str]:
        return self._write_growth(str(text or "").strip(), "persona.growth", {})

    def auto_grow(
        self,
        insights: str | list[str],
        *,
        reason: str = "",
        evidence: list[str] | None = None,
    ) -> tuple[bool, str]:
        """自动更新可成长段：只追加/淡出这一段，其他段落一行都不动。

        旧的行不会无限堆积：超过条数或字数上限时，从最旧的一条开始淡出。
        """
        cleaned = _clean_insights(insights)
        if not cleaned:
            return False, "没有可以写进人格的新内容。"
        kept = self.growth_lines()
        added: list[str] = []
        for line in cleaned:
            if self._guard(line):
                continue
            if any(_similar_text(line, old) for old in kept):
                continue
            kept.append(line)
            added.append(line)
        if not added:
            return False, "这些内容人格里已经有了。"
        dropped: list[str] = []
        while len(kept) > self.growth_keep:
            dropped.append(kept.pop(0))
        while kept and len(_render_growth(kept)) > self.growth_chars:
            dropped.append(kept.pop(0))
        if not kept:
            return False, "内容太长，写不进可成长段。"
        ok, message = self._write_growth(
            _render_growth(kept),
            "persona.auto_grow",
            {
                "reason": model.clean_text(reason, 160),
                "evidence": [str(item)[:64] for item in (evidence or []) if str(item).strip()][:20],
                "added": added[:8],
                "dropped": dropped[:8],
                "lines": len(kept),
            },
        )
        if not ok:
            return False, message
        return True, f"人格又成长了一点（新增 {len(added)} 条，淡出 {len(dropped)} 条）。"

    def _write_growth(self, body: str, event: str, detail: dict[str, Any]) -> tuple[bool, str]:
        body = str(body or "").strip()
        if len(body) > self.growth_chars:
            return False, f"可成长段最多 {self.growth_chars} 字。"
        problem = self._guard(body)
        if problem:
            return False, problem
        prefix, growth, suffix = _split_growth(self.persona())
        growth_missing = growth is None
        if growth_missing:
            prefix = self.persona().rstrip() + "\n\n" + GROWTH_HEADING + "\n\n"
            suffix = ""
        rebuilt = prefix.rstrip() + "\n\n" + body.strip() + "\n\n" + (suffix or "").lstrip()
        self._backup("persona")
        model.atomic_write_text(self.persona_path, rebuilt.strip() + "\n")
        payload = dict(detail)
        payload.update({"chars": len(body), "created_section": bool(growth_missing)})
        self.audit(event, payload)
        return True, "可成长段已保存，旧版本已备份。"

    def restore(self, kind: str, name: str) -> tuple[bool, str]:
        kind = "core" if str(kind) == "core" else "persona"
        target = (self.history_dir / str(name or "")).resolve()
        if self.history_dir.resolve() not in target.parents or not target.is_file():
            return False, "找不到这个历史版本。"
        try:
            text = target.read_text(encoding="utf-8")
        except OSError as exc:
            return False, f"读取历史版本失败：{exc}"
        self._backup(kind)
        path = self.core_path if kind == "core" else self.persona_path
        model.atomic_write_text(path, text)
        self.audit(f"{kind}.restore", {"from": target.name})
        return True, f"已回滚到 {target.name}。"

    # ---------- 历史与审计 ----------

    def history(self, kind: str, limit: int = 12) -> list[dict[str, Any]]:
        prefix = "core-" if kind == "core" else "persona-"
        rows: list[dict[str, Any]] = []
        try:
            files = sorted(self.history_dir.glob(prefix + "*.md"), reverse=True)
        except OSError:
            files = []
        for path in files[: max(1, int(limit))]:
            try:
                size = path.stat().st_size
            except OSError:
                size = 0
            rows.append({"name": path.name, "size": size, "mtime": _mtime(path)})
        return rows

    def history_count(self, kind: str = "") -> int:
        wanted = str(kind or "")
        prefixes = (wanted + "-",) if wanted in ("core", "persona") else ("core-", "persona-")
        count = 0
        for prefix in prefixes:
            try:
                count += len(list(self.history_dir.glob(prefix + "*.md")))
            except OSError:
                pass
        return count

    def prune_history(self, kind: str = "", keep: int | None = None) -> int:
        limit = max(1, int(keep if keep is not None else self.history_keep))
        wanted = str(kind or "")
        prefixes = (wanted + "-",) if wanted in ("core", "persona") else ("core-", "persona-")
        removed = 0
        for prefix in prefixes:
            try:
                files = sorted(self.history_dir.glob(prefix + "*.md"), reverse=True)
            except OSError:
                continue
            for path in files[limit:]:
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    pass
        if removed:
            self.audit("history.prune", {"kind": wanted or "all", "removed": removed, "keep": limit})
        return removed

    def delete_history(self, kind: str, name: str) -> tuple[bool, str]:
        kind = "core" if str(kind) == "core" else "persona"
        target = (self.history_dir / str(name or "")).resolve()
        if self.history_dir.resolve() not in target.parents or not target.is_file():
            return False, "找不到这个历史版本。"
        if not target.name.startswith(kind + "-"):
            return False, "版本类型不匹配。"
        try:
            target.unlink()
        except OSError as exc:
            return False, f"删除失败：{exc}"
        self.audit("history.delete", {"kind": kind, "name": target.name})
        return True, f"已删除 {target.name}。"

    def clear_history(self, kind: str = "") -> tuple[bool, str]:
        wanted = str(kind or "")
        prefixes = (wanted + "-",) if wanted in ("core", "persona") else ("core-", "persona-")
        removed = 0
        for prefix in prefixes:
            try:
                files = list(self.history_dir.glob(prefix + "*.md"))
            except OSError:
                continue
            for path in files:
                try:
                    path.unlink()
                    removed += 1
                except OSError:
                    pass
        self.audit("history.clear", {"kind": wanted or "all", "removed": removed})
        return True, f"已清空 {removed} 个历史版本。"

    def audit(self, event: str, detail: dict[str, Any] | None = None) -> None:
        line = {
            "at": model.now(),
            "event": str(event),
            "actor": "owner",
            "detail": detail or {},
        }
        try:
            self.audit_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.audit_path, "a", encoding="utf-8") as handle:
                handle.write(_json_line(line))
        except OSError:
            pass
        self.prune_audit()

    def prune_audit(self, keep: int = MAX_AUDIT_LINES, force: bool = False) -> int:
        """审计只保留最近一段；文件不大时不频繁重写。"""
        try:
            size = self.audit_path.stat().st_size
        except OSError:
            return 0
        if not force and size < AUDIT_TRIM_BYTES:
            return 0
        try:
            lines = self.audit_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return 0
        limit = max(50, int(keep))
        if len(lines) <= limit and not force:
            return 0
        kept = lines[-limit:]
        try:
            model.atomic_write_text(self.audit_path, "\n".join(kept) + ("\n" if kept else ""))
        except OSError:
            return 0
        return len(lines) - len(kept)

    def audit_tail(self, limit: int = 20) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        try:
            lines = self.audit_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return rows
        for line in lines[-max(1, int(limit)) :]:
            try:
                data = __import__("json").loads(line)
            except ValueError:
                continue
            if isinstance(data, dict):
                rows.append(data)
        return rows

    def _backup(self, kind: str) -> None:
        source = self.core_path if kind == "core" else self.persona_path
        try:
            text = source.read_text(encoding="utf-8")
        except OSError:
            return
        self.history_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d-%H%M%S")
        target = self.history_dir / f"{kind}-{stamp}.md"
        index = 1
        while target.exists():
            target = self.history_dir / f"{kind}-{stamp}-{index}.md"
            index += 1
        try:
            model.atomic_write_text(target, text)
        except OSError:
            return
        self.prune_history(kind, self.history_keep)

    def _guard(self, text: str) -> str:
        lowered = text.lower()
        for word in _FORBIDDEN:
            if word.lower() in lowered:
                return f"这一段包含“{word}”，人格成长不能涉及权限或身份劫持，已拒绝保存。"
        if _AI_SELF_CLAIM.search(text):
            return "可成长段不能写成“我是 AI / 程序”这类自我声明。"
        if re.search(r"(?m)^\s*##\s+(身份|安全|权限|工具|输出规则|系统|记忆|模型)\s*$", text):
            return "可成长段里不能新增身份、安全、权限、工具或输出规则标题。"
        return ""


def _clean_insights(values: str | list[str]) -> list[str]:
    rows = re.split(r"[\r\n]+", values) if isinstance(values, str) else list(values or [])
    result: list[str] = []
    for raw in rows:
        line = re.sub(r"^\s*(?:[-*•·]|\d+[.、)])\s*", "", str(raw or "")).strip()
        line = model.clean_text(line, 80)
        if len(line) < 4 or line.startswith("#"):
            continue
        if line not in result:
            result.append(line)
    return result[: MAX_GROWTH_INSIGHTS]


_CJK_RUN = re.compile(r"[\u4e00-\u9fff]+")
_LATIN_RUN = re.compile(r"[a-z0-9]{2,}", re.I)


def _match_tokens(text: Any) -> set[str]:
    """给当前话题和成长条目做粗匹配，够用就行。"""
    value = str(text or "").lower()
    if not value.strip():
        return set()
    tokens: set[str] = set()
    for run in _CJK_RUN.findall(value):
        if len(run) == 1:
            tokens.add(run)
        else:
            tokens.update(run[index : index + 2] for index in range(len(run) - 1))
    tokens.update(_LATIN_RUN.findall(value))
    return tokens


def _render_growth(lines: list[str]) -> str:
    return "\n".join(f"- {model.clean_text(line, 80)}" for line in lines if str(line).strip())


def _similar_text(left: str, right: str) -> bool:
    def norm(value: Any) -> str:
        return re.sub(r"[\s，。,.!！?？、；;：:\"'“”‘’（）()]+", "", str(value or "")).lower()

    a, b = norm(left), norm(right)
    if not a or not b:
        return False
    if a == b:
        return True
    return (len(a) >= 4 and a in b) or (len(b) >= 4 and b in a)


def _split_growth(text: str) -> tuple[str, str | None, str]:
    value = str(text or "")
    match = re.search(r"(?m)^\s*##\s*可成长\s*$", value)
    if match is None:
        return value, None, ""
    start = match.end()
    rest = value[start:]
    following = re.search(r"(?m)^\s*##\s+\S+", rest)
    if following is None:
        return value[:start], rest, ""
    end = start + following.start()
    return value[:start], value[start:end], value[end:]


def _strip_comments(text: str) -> str:
    return re.sub(r"<!--.*?-->", "", str(text or ""), flags=re.S).strip()


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def _json_line(data: dict[str, Any]) -> str:
    return __import__("json").dumps(data, ensure_ascii=False) + "\n"
